<?php
header('Content-Type: application/json');
session_start();

require_once 'config.php';

// Создаем или получаем уникальный идентификатор сессии для отслеживания заказов
if (!isset($_SESSION['order_session_id'])) {
    $_SESSION['order_session_id'] = uniqid('order_', true);
}
$sessionId = $_SESSION['order_session_id'];

// Проверяем, был ли этот запрос уже обработан (защита от двойной отправки)
if (isset($_SESSION['last_processed_request']) && isset($_POST['request_id']) && 
    $_SESSION['last_processed_request'] === $_POST['request_id']) {
    echo json_encode([
        'success' => false, 
        'message' => 'Этот заказ уже был обработан. Пожалуйста, обновите страницу, если хотите сделать новый заказ.'
    ]);
    exit;
}

// Функция для валидации данных
function validateOrderData($data) {
    $errors = [];
    
    // Проверка обязательных полей
    $requiredFields = ['fuel_id', 'quantity', 'delivery_date', 'delivery_time', 'delivery_address'];
    
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            $errors[] = "Поле " . $field . " обязательно для заполнения";
        }
    }
    
    // Проверка количества
    if (isset($data['quantity']) && (!is_numeric($data['quantity']) || $data['quantity'] < 100)) {
        $errors[] = "Минимальное количество для заказа - 100 литров";
    }
    
    // Проверка даты доставки (должна быть не раньше завтрашнего дня)
    if (isset($data['delivery_date'])) {
        $deliveryDate = new DateTime($data['delivery_date']);
        $tomorrow = new DateTime('tomorrow');
        
        if ($deliveryDate < $tomorrow) {
            $errors[] = "Дата доставки должна быть не раньше завтрашнего дня";
        }
    }
    
    return $errors;
}

// Функция для проверки дублирования заказа
function checkDuplicateOrder($data, $userId) {
    global $pdo;
    
    try {
        // Проверяем, есть ли похожий заказ, созданный в последние 5 минут
        $stmt = $pdo->prepare("SELECT id FROM orders 
                              WHERE user_id = :user_id 
                              AND fuel_id = :fuel_id 
                              AND quantity = :quantity 
                              AND delivery_date = :delivery_date 
                              AND delivery_time = :delivery_time 
                              AND order_date >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
        
        $stmt->execute([
            'user_id' => $userId,
            'fuel_id' => $data['fuel_id'],
            'quantity' => $data['quantity'],
            'delivery_date' => $data['delivery_date'],
            'delivery_time' => $data['delivery_time']
        ]);
        
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        // Если произошла ошибка (например, колонка created_at не существует), 
        // просто возвращаем false и позволяем заказу быть созданным
        return false;
    }
}

// Функция для добавления заказа в базу данных
function addOrder($data) {
    global $pdo, $sessionId;
    
    try {
        // Получаем информацию о топливе
        $stmt = $pdo->prepare("SELECT name, pastPrice, newPrice FROM fuels WHERE id = ?");
        $stmt->execute([$data['fuel_id']]);
        $fuel = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$fuel) {
            return ['success' => false, 'message' => 'Выбранное топливо не найдено'];
        }
        
        // Определяем актуальную цену
        $price = ($fuel['newPrice'] && $fuel['pastPrice'] > $fuel['newPrice']) ? $fuel['newPrice'] : $fuel['pastPrice'];
        
        // Рассчитываем общую стоимость
        $totalPrice = $price * $data['quantity'];
        
        // Получаем ID пользователя из сессии, если он авторизован
        $userId = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null;
        
        // Проверяем, существует ли колонка session_id в таблице orders
        $hasSessionIdColumn = false;
        try {
            $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'session_id'");
            $hasSessionIdColumn = $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            // Если произошла ошибка, предполагаем, что колонки нет
        }
        
        // Если колонки нет, добавляем ее
        if (!$hasSessionIdColumn) {
            try {
                $pdo->exec("ALTER TABLE orders ADD COLUMN session_id VARCHAR(100) AFTER user_id");
            } catch (PDOException $e) {
                // Игнорируем ошибку, если не удалось добавить колонку
            }
        }
        
        // Подготавливаем SQL запрос с учетом наличия колонки session_id
        $sql = "INSERT INTO orders (
            user_id, " . ($hasSessionIdColumn ? "session_id, " : "") . "
            fuel_id, fuel_name, price_per_liter, quantity, total_price, 
            delivery_date, delivery_time, delivery_address, comments,
            is_paid
        ) VALUES (
            :user_id, " . ($hasSessionIdColumn ? ":session_id, " : "") . "
            :fuel_id, :fuel_name, :price_per_liter, :quantity, :total_price,
            :delivery_date, :delivery_time, :delivery_address, :comments,
            :is_paid
        )";
        
        $stmt = $pdo->prepare($sql);
        
        // Подготавливаем параметры
        $params = [
            'user_id' => $userId,
            'fuel_id' => $data['fuel_id'],
            'fuel_name' => $fuel['name'],
            'price_per_liter' => $price,
            'quantity' => $data['quantity'],
            'total_price' => $totalPrice,
            'delivery_date' => $data['delivery_date'],
            'delivery_time' => $data['delivery_time'],
            'delivery_address' => $data['delivery_address'],
            'comments' => $data['comments'] ?? null,
            'is_paid' => false
        ];
        
        // Добавляем session_id, если колонка существует
        if ($hasSessionIdColumn) {
            $params['session_id'] = $sessionId;
        }
        
        $stmt->execute($params);
        
        // Получаем ID вставленной записи
        $orderId = $pdo->lastInsertId();
        
        // Проверяем, что ID получен корректно
        if (!$orderId || $orderId == 0) {
            // Если ID не получен, пробуем получить его через запрос
            $checkStmt = $pdo->prepare("SELECT id FROM orders WHERE 
                user_id = :user_id AND 
                fuel_id = :fuel_id AND 
                quantity = :quantity AND 
                delivery_date = :delivery_date AND 
                delivery_time = :delivery_time 
                ORDER BY order_date DESC LIMIT 1");
                
            $checkStmt->execute([
                'user_id' => $userId,
                'fuel_id' => $data['fuel_id'],
                'quantity' => $data['quantity'],
                'delivery_date' => $data['delivery_date'],
                'delivery_time' => $data['delivery_time']
            ]);
            
            $result = $checkStmt->fetch(PDO::FETCH_ASSOC);
            if ($result && isset($result['id'])) {
                $orderId = $result['id'];
            }
        }
        
        // Сохраняем ID заказа в сессии для дальнейшего использования
        $_SESSION['last_order_id'] = $orderId;
        
        return [
            'success' => true, 
            'message' => 'Заказ успешно оформлен! Мы свяжемся с вами в ближайшее время.',
            'order_id' => $orderId
        ];
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return ['success' => false, 'message' => 'Произошла ошибка при оформлении заказа: ' . $e->getMessage()];
    }
}

// Обработка запроса
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Сохраняем идентификатор запроса для предотвращения повторной обработки
    if (isset($_POST['request_id'])) {
        $_SESSION['last_processed_request'] = $_POST['request_id'];
    }
    
    // Получаем данные из формы
    $orderData = [
        'fuel_id' => $_POST['fuel_id'] ?? null,
        'quantity' => $_POST['quantity'] ?? null,
        'delivery_date' => $_POST['delivery_date'] ?? null,
        'delivery_time' => $_POST['delivery_time'] ?? null,
        'delivery_address' => $_POST['delivery_address'] ?? null,
        'comments' => $_POST['comments'] ?? null
    ];
    
    // Валидируем данные
    $errors = validateOrderData($orderData);
    
    if (!empty($errors)) {
        echo json_encode(['success' => false, 'message' => implode('. ', $errors)]);
    } else {
        // Получаем ID пользователя из сессии
        $userId = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null;
        
        // Проверяем на дублирование заказа
        if ($userId && checkDuplicateOrder($orderData, $userId)) {
            echo json_encode(['success' => false, 'message' => 'Похожий заказ уже был оформлен недавно. Пожалуйста, проверьте список ваших заказов.']);
        } else {
            // Добавляем заказ в базу данных
            $result = addOrder($orderData);
            echo json_encode($result);
        }
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
}
?>
