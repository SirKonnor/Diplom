<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

try {
    // Сначала ищем пользователя с ролью helper
    $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'helper' LIMIT 1");
    $stmt->execute();
    $helper = $stmt->fetch();
    
    // Если helper найден, возвращаем его ID
    if ($helper) {
        echo json_encode([
            'success' => true,
            'adminId' => $helper['id'],
            'role' => 'helper'
        ]);
    } else {
        // Если helper не найден, возвращаем ID администратора
        $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'admin' LIMIT 1");
        $stmt->execute();
        $admin = $stmt->fetch();
        
        echo json_encode([
            'success' => true,
            'adminId' => $admin ? $admin['id'] : null,
            'role' => 'admin'
        ]);
    }
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
