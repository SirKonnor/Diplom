/**
 * Обработка уведомлений на странице профиля
 */
document.addEventListener("DOMContentLoaded", () => {
    // Проверяем авторизацию
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    if (!authData.isAuthenticated || !authData.user || !authData.user.id) {
      return
    }
  
    // Сбрасываем уведомление о заказе при просмотре страницы заказов
    if (window.location.pathname.includes("orders.html") && window.notificationSystem) {
      window.notificationSystem.clearOrderNotification()
    }
  
    // Сбрасываем уведомления о сообщениях при просмотре страницы сообщений
    if (window.location.pathname.includes("messages.html") && window.notificationSystem) {
      // Отмечаем сообщения как прочитанные
      markMessagesAsRead(authData.user.id)
    }
  
    // Функция для отметки сообщений как прочитанных
    async function markMessagesAsRead(userId) {
      try {
        // Получаем ID отправителя из URL или другого источника
        // Здесь предполагается, что ID отправителя можно получить из URL или sessionStorage
        const urlParams = new URLSearchParams(window.location.search)
        const senderId = urlParams.get("senderId") || sessionStorage.getItem("currentChatSenderId")
  
        if (!senderId) {
          console.warn("ID отправителя не найден, невозможно отметить сообщения как прочитанные")
          return
        }
  
        const response = await fetch("mark-messages-read.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            receiverId: userId,
            senderId: senderId,
          }),
        })
  
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`)
        }
  
        const data = await response.json()
  
        if (data.success) {
          // Обновляем счетчик непрочитанных сообщений
          if (window.notificationSystem) {
            window.notificationSystem.fetchUnreadMessagesCount(userId)
          }
        } else {
          console.error("Ошибка при отметке сообщений как прочитанных:", data.error)
        }
      } catch (error) {
        console.error("Ошибка при отметке сообщений как прочитанных:", error)
      }
    }
  })
  