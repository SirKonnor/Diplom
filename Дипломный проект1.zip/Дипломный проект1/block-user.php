<?php
header("Content-Type: application/json");
require_once 'config.php';

// Получение данных из запроса
$data = json_decode(file_get_contents('php://input'), true);
$userId = isset($data['userId']) ? $data['userId'] : null;
$userEmail = isset($data['userEmail']) ? $data['userEmail'] : null;
$reason = isset($data['reason']) ? $data['reason'] : null;
$adminId = isset($data['adminId']) ? $data['adminId'] : null;

// Проверка наличия необходимых данных
if (!$userId || !$userEmail || !$reason || !$adminId) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Отсутствуют необходимые данные'
    ]);
    exit;
}

try {
    // Начинаем транзакцию
    $pdo->beginTransaction();

    // Проверяем, не заблокирован ли уже пользователь
    $stmt = $pdo->prepare("SELECT * FROM blacklist WHERE email = ?");
    $stmt->execute([$userEmail]);
    $existingBlock = $stmt->fetch();

    if ($existingBlock) {
        // Если пользователь уже заблокирован, обновляем причину
        $stmt = $pdo->prepare("UPDATE blacklist SET reason = ?, blocked_at = NOW(), blocked_by = ? WHERE email = ?");
        $stmt->execute([$reason, $adminId, $userEmail]);
    } else {
        // Если пользователь не заблокирован, добавляем его в черный список
        $stmt = $pdo->prepare("INSERT INTO blacklist (email, reason, blocked_by) VALUES (?, ?, ?)");
        $stmt->execute([$userEmail, $reason, $adminId]);
    }

    // Завершаем транзакцию
    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Пользователь успешно заблокирован'
    ]);

} catch (PDOException $e) {
    // Откатываем транзакцию в случае ошибки
    $pdo->rollBack();
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных: ' . $e->getMessage()
    ]);
}
?>
