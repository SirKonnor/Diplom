document.addEventListener('DOMContentLoaded', function() {
    // Проверка доступа к странице статистики
    checkAccess();
    
    // Обработчик изменения периода
    const dateRangeSelect = document.getElementById('date-range');
    if (dateRangeSelect) {
        dateRangeSelect.addEventListener('change', function() {
            const days = this.value;
            loadStatisticsData(days);
        });
    }
    
    // Обработчик для кнопки обновления
    const refreshBtn = document.getElementById('refresh-stats');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            const days = document.getElementById('date-range')?.value || 30;
            loadStatisticsData(days);
        });
    }
    
    // Обработчик для кнопки экспорта
    const exportBtn = document.getElementById('export-stats');
    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            exportStatistics();
        });
    }
});

// Глобальная переменная для хранения данных статистики
let statsData = {
    visitors: [],
    orders: [],
    revenue: [],
    fuelTypes: [],
    recentOrders: []
};

// Проверка доступа к странице статистики
function checkAccess() {
    fetch('check-stats-access.php')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.hasAccess) {
                // Если доступ разрешен, загружаем данные статистики
                const days = document.getElementById('date-range')?.value || 30;
                loadStatisticsData(days);
            } else {
                // Если доступ запрещен, показываем сообщение
                const mainContent = document.querySelector('.main-content');
                if (mainContent) {
                    mainContent.innerHTML = `
                        <div class="access-denied">
                            <i class="fas fa-lock"></i>
                            <h2>Доступ запрещен</h2>
                            <p>У вас нет прав для просмотра статистики.</p>
                            <p>Обратитесь к администратору сайта.</p>
                        </div>
                    `;
                }
                
                // Скрываем индикатор загрузки, если он существует
                const loadingIndicator = document.getElementById('loading-indicator');
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
            }
        })
        .catch(error => {
            console.error('Ошибка при проверке доступа:', error);
            
            const mainContent = document.querySelector('.main-content');
            if (mainContent) {
                mainContent.innerHTML = `
                    <div class="error-message">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h2>Ошибка</h2>
                        <p>Не удалось проверить права доступа. Пожалуйста, попробуйте позже.</p>
                        <p>Подробности: ${error.message}</p>
                    </div>
                `;
            }
            
            // Скрываем индикатор загрузки, если он существует
            const loadingIndicator = document.getElementById('loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.style.display = 'none';
            }
        });
}

// Загрузка данных статистики
function loadStatisticsData(days) {
    // Показываем индикатор загрузки, если он существует
    const loadingIndicator = document.getElementById('loading-indicator');
    if (loadingIndicator) {
        loadingIndicator.style.display = 'flex';
    }
    
    // Показываем индикаторы загрузки в карточках
    showLoadingState();
    
    fetch(`get-statistics-data.php?days=${days}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Сохраняем данные в глобальную переменную
                statsData = {
                    visitors: data.visitors || [],
                    orders: data.orders || [],
                    revenue: data.revenue || [],
                    fuelTypes: data.fuelTypes || [],
                    recentOrders: data.recentOrders || []
                };
                
                // Обновляем данные на странице
                updateVisitorsData(data.visitors);
                updateOrdersData(data.orders);
                updateRevenueData(data.revenue);
                updateFuelTypesData(data.fuelTypes);
                updateRecentOrdersTable(data.recentOrders);
                
                // Скрываем индикатор загрузки, если он существует
                if (loadingIndicator) {
                    loadingIndicator.style.display = 'none';
                }
            } else {
                throw new Error(data.error || 'Неизвестная ошибка при загрузке данных');
            }
        })
        .catch(error => {
            console.error('Ошибка при загрузке данных:', error);
            showErrorMessage(error.message);
            
            // Скрываем индикатор загрузки, если он существует
            if (loadingIndicator) {
                loadingIndicator.style.display = 'none';
            }
        });
}

// Показать состояние загрузки
function showLoadingState() {
    // Безопасное обновление текстового содержимого элемента
    const safeUpdateText = (id, text) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = text;
        }
    };
    
    safeUpdateText('visitors-count', 'Загрузка...');
    safeUpdateText('orders-count', 'Загрузка...');
    safeUpdateText('revenue-count', 'Загрузка...');
    safeUpdateText('fuel-count', 'Загрузка...');
    
    const recentOrdersTableBody = document.querySelector('#recent-orders-table tbody');
    if (recentOrdersTableBody) {
        recentOrdersTableBody.innerHTML = `
            <tr>
                <td colspan="7" class="loading-message">Загрузка данных...</td>
            </tr>
        `;
    }
}

// Показать сообщение об ошибке
function showErrorMessage(message) {
    const errorHtml = `
        <tr>
            <td colspan="7" class="error-message">
                <p>Ошибка при загрузке данных:</p>
                <p>${message}</p>
                <button onclick="retryLoadData()" class="btn">Повторить</button>
            </td>
        </tr>
    `;
    
    const recentOrdersTableBody = document.querySelector('#recent-orders-table tbody');
    if (recentOrdersTableBody) {
        recentOrdersTableBody.innerHTML = errorHtml;
    }
    
    // Безопасное обновление текстового содержимого элемента
    const safeUpdateText = (id, text) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = text;
        }
    };
    
    safeUpdateText('visitors-count', 'Ошибка');
    safeUpdateText('orders-count', 'Ошибка');
    safeUpdateText('revenue-count', 'Ошибка');
    safeUpdateText('fuel-count', 'Ошибка');
    
    // Сбрасываем индикаторы изменений
    const safeUpdateHTML = (id, html) => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = html;
        }
    };
    
    safeUpdateHTML('visitors-change', '');
    safeUpdateHTML('orders-change', '');
    safeUpdateHTML('revenue-change', '');
    safeUpdateHTML('fuel-change', '');
}

// Повторная загрузка данных
function retryLoadData() {
    const days = document.getElementById('date-range')?.value || 30;
    loadStatisticsData(days);
}

// Обновление данных о посетителях
function updateVisitorsData(visitorsData) {
    // Если данных нет, показываем сообщение
    if (!visitorsData || visitorsData.length === 0) {
        const visitorsCount = document.getElementById('visitors-count');
        if (visitorsCount) {
            visitorsCount.textContent = 'Нет данных';
        }
        
        const visitorsChange = document.getElementById('visitors-change');
        if (visitorsChange) {
            visitorsChange.innerHTML = '';
        }
        
        // Очищаем график
        if (window.visitorsChart) {
            window.visitorsChart.destroy();
        }
        return;
    }
    
    // Подсчет общего количества посетителей
    let totalVisitors = 0;
    let uniqueVisitors = 0;
    
    visitorsData.forEach(item => {
        totalVisitors += item.count;
        if (item.unique_count) {
            uniqueVisitors += item.unique_count;
        }
    });
    
    // Обновление счетчика посетителей
    const visitorsCount = document.getElementById('visitors-count');
    if (visitorsCount) {
        visitorsCount.textContent = totalVisitors.toLocaleString('ru-RU');
    }
    
    // Если есть данные об уникальных посетителях, показываем их
    const visitorsChange = document.getElementById('visitors-change');
    if (visitorsChange) {
        if (uniqueVisitors > 0) {
            visitorsChange.innerHTML = `
                <i class="fas fa-user"></i> ${uniqueVisitors.toLocaleString('ru-RU')} уникальных
            `;
        } else {
            visitorsChange.innerHTML = '';
        }
    }
    
    // Подготовка данных для графика
    const labels = visitorsData.map(item => item.date);
    const counts = visitorsData.map(item => item.count);
    const uniqueCounts = visitorsData.map(item => item.unique_count || 0);
    
    // Создание графика посещаемости
    const visitorsChartCanvas = document.getElementById('visitors-chart');
    if (!visitorsChartCanvas) {
        return;
    }
    
    const ctx = visitorsChartCanvas.getContext('2d');
    
    if (window.visitorsChart) {
        window.visitorsChart.destroy();
    }
    
    window.visitorsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Все посещения',
                    data: counts,
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.2)',
                    tension: 0.1,
                    fill: true
                },
                {
                    label: 'Уникальные посетители',
                    data: uniqueCounts,
                    borderColor: '#6f42c1',
                    backgroundColor: 'rgba(111, 66, 193, 0.2)',
                    tension: 0.1,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#fff'
                    }
                },
                title: {
                    display: true,
                    text: 'Динамика посещаемости',
                    color: '#fff'
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Обновление данных о заказах
function updateOrdersData(ordersData) {
    // Если данных нет, показываем сообщение
    if (!ordersData || ordersData.length === 0) {
        const ordersCount = document.getElementById('orders-count');
        if (ordersCount) {
            ordersCount.textContent = 'Нет данных';
        }
        
        const ordersChange = document.getElementById('orders-change');
        if (ordersChange) {
            ordersChange.innerHTML = '';
        }
        
        // Очищаем график
        if (window.ordersChart) {
            window.ordersChart.destroy();
        }
        return;
    }
    
    // Подсчет общего количества заказов и выручки
    let totalOrders = 0;
    let totalRevenue = 0;
    
    ordersData.forEach(item => {
        totalOrders += item.count;
        if (item.total_price) {
            totalRevenue += parseFloat(item.total_price);
        }
    });
    
    // Обновление счетчика заказов
    const ordersCount = document.getElementById('orders-count');
    if (ordersCount) {
        ordersCount.textContent = totalOrders.toLocaleString('ru-RU');
    }
    
    // Расчет среднего количества заказов в день
    const avgOrdersPerDay = totalOrders / ordersData.length;
    
    const ordersChange = document.getElementById('orders-change');
    if (ordersChange) {
        ordersChange.innerHTML = `
            <i class="fas fa-calendar-day"></i> ${avgOrdersPerDay.toFixed(1)} в день
        `;
    }
    
    // Подготовка данных для графика
    const labels = ordersData.map(item => item.date);
    const counts = ordersData.map(item => item.count);
    
    // Создание графика заказов
    const ordersChartCanvas = document.getElementById('orders-chart');
    if (!ordersChartCanvas) {
        return;
    }
    
    const ctx = ordersChartCanvas.getContext('2d');
    
    if (window.ordersChart) {
        window.ordersChart.destroy();
    }
    
    window.ordersChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Количество заказов',
                data: counts,
                backgroundColor: 'rgba(40, 167, 69, 0.5)',
                borderColor: '#28a745',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#fff'
                    }
                },
                title: {
                    display: true,
                    text: 'Динамика заказов',
                    color: '#fff'
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0,
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Обновление данных о выручке
function updateRevenueData(revenueData) {
    // Если данных нет, выходим
    if (!revenueData || revenueData.length === 0) {
        // Очищаем график
        if (window.revenueChart) {
            window.revenueChart.destroy();
        }
        return;
    }
    
    // Подсчет общей выручки
    let totalRevenue = 0;
    revenueData.forEach(item => {
        totalRevenue += parseFloat(item.revenue);
    });
    
    // Обновление счетчика выручки
    const revenueCount = document.getElementById('revenue-count');
    if (revenueCount) {
        revenueCount.textContent = totalRevenue.toLocaleString('ru-RU') + ' ₽';
    }
    
    // Расчет среднемесячной выручки
    const avgMonthlyRevenue = totalRevenue / revenueData.length;
    
    const revenueChange = document.getElementById('revenue-change');
    if (revenueChange) {
        revenueChange.innerHTML = `
            <i class="fas fa-chart-line"></i> ${avgMonthlyRevenue.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽/мес
        `;
    }
    
    // Подготовка данных для графика
    const labels = revenueData.map(item => item.month);
    const revenues = revenueData.map(item => item.revenue);
    
    // Создание графика выручки
    const revenueChartCanvas = document.getElementById('revenue-chart');
    if (!revenueChartCanvas) {
        return;
    }
    
    const ctx = revenueChartCanvas.getContext('2d');
    
    if (window.revenueChart) {
        window.revenueChart.destroy();
    }
    
    window.revenueChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Выручка (₽)',
                data: revenues,
                backgroundColor: 'rgba(253, 126, 20, 0.5)',
                borderColor: '#fd7e14',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#fff'
                    }
                },
                title: {
                    display: true,
                    text: 'Выручка по месяцам',
                    color: '#fff'
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value.toLocaleString('ru-RU') + ' ₽';
                        },
                        color: '#8a8d93'
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Обновление данных о типах топлива
function updateFuelTypesData(fuelTypesData) {
    // Если данных нет, выходим
    if (!fuelTypesData || fuelTypesData.length === 0) {
        // Очищаем график
        if (window.fuelTypesChart) {
            window.fuelTypesChart.destroy();
        }
        return;
    }
    
    // Подсчет общего объема топлива
    let totalVolume = 0;
    fuelTypesData.forEach(item => {
        totalVolume += parseFloat(item.volume);
    });
    
    // Обновление счетчика объема топлива
    const fuelCount = document.getElementById('fuel-count');
    if (fuelCount) {
        fuelCount.textContent = totalVolume.toLocaleString('ru-RU') + ' л';
    }
    
    // Определение самого популярного типа топлива
    const mostPopularFuel = [...fuelTypesData].sort((a, b) => b.volume - a.volume)[0];
    
    const fuelChange = document.getElementById('fuel-change');
    if (fuelChange) {
        fuelChange.innerHTML = `
            <i class="fas fa-gas-pump"></i> ${mostPopularFuel.name}
        `;
    }
    
    // Подготовка данных для графика
    const labels = fuelTypesData.map(item => item.name);
    const volumes = fuelTypesData.map(item => item.volume);
    
    // Создание графика типов топлива
    const fuelTypesChartCanvas = document.getElementById('fuel-types-chart');
    if (!fuelTypesChartCanvas) {
        return;
    }
    
    const ctx = fuelTypesChartCanvas.getContext('2d');
    
    if (window.fuelTypesChart) {
        window.fuelTypesChart.destroy();
    }
    
    window.fuelTypesChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                label: 'Объем (л)',
                data: volumes,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                    'rgba(75, 192, 192, 0.7)',
                    'rgba(153, 102, 255, 0.7)',
                    'rgba(255, 159, 64, 0.7)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        color: '#fff'
                    }
                },
                title: {
                    display: true,
                    text: 'Популярность типов топлива',
                    color: '#fff'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = Math.round((value / total) * 100);
                            return `${label}: ${value.toLocaleString('ru-RU')} л (${percentage}%)`;
                        }
                    }
                }
            }
        }
    });
}

// Обновление таблицы последних заказов
function updateRecentOrdersTable(recentOrders) {
    const recentOrdersTableBody = document.querySelector('#recent-orders-table tbody');
    if (!recentOrdersTableBody) {
        return;
    }
    
    // Если данных нет, показываем сообщение
    if (!recentOrders || recentOrders.length === 0) {
        recentOrdersTableBody.innerHTML = `
            <tr>
                <td colspan="7" class="no-data-message">Нет данных о заказах</td>
            </tr>
        `;
        return;
    }
    
    // Формирование HTML для таблицы
    let tableHtml = '';
    
    recentOrders.forEach(order => {
        // Определение класса для статуса
        let statusClass = '';
        switch (order.status) {
            case 'PENDING':
                statusClass = 'order-status pending';
                break;
            case 'CONFIRMED':
                statusClass = 'order-status confirmed';
                break;
            case 'DELIVERED':
                statusClass = 'order-status delivered';
                break;
            case 'CANCELLED':
                statusClass = 'order-status cancelled';
                break;
        }
        
        // Перевод статуса на русский
        let statusText = '';
        switch (order.status) {
            case 'PENDING':
                statusText = 'Ожидает';
                break;
            case 'CONFIRMED':
                statusText = 'Подтвержден';
                break;
            case 'DELIVERED':
                statusText = 'Доставлен';
                break;
            case 'CANCELLED':
                statusText = 'Отменен';
                break;
            default:
                statusText = order.status;
        }
        
        tableHtml += `
            <tr>
                <td>${order.id}</td>
                <td>${order.date}</td>
                <td>${order.client || 'Неизвестно'}</td>
                <td>${order.fuelType}</td>
                <td>${parseFloat(order.volume).toLocaleString('ru-RU')} л</td>
                <td>${parseFloat(order.totalPrice).toLocaleString('ru-RU')} ₽</td>
                <td><span class="${statusClass}">${statusText}</span></td>
            </tr>
        `;
    });
    
    recentOrdersTableBody.innerHTML = tableHtml;
}

// Функция для изменения типа графика
function changeChartType(chartId, type) {
    try {
        // Находим контейнер графика
        const chartCanvas = document.getElementById(`${chartId}-chart`);
        if (!chartCanvas) {
            console.error(`График с ID ${chartId}-chart не найден`);
            return;
        }
        
        const chartContainer = chartCanvas.closest('.stats-chart-container');
        if (!chartContainer) {
            console.error(`Контейнер для графика ${chartId}-chart не найден`);
            return;
        }
        
        // Получаем кнопки переключения типа графика для данного графика
        const chartButtons = chartContainer.querySelectorAll('.chart-type-btn');
        
        // Удаляем класс active у всех кнопок этого графика
        chartButtons.forEach(button => {
            button.classList.remove('active');
        });
        
        // Добавляем класс active к нажатой кнопке
        const clickedButton = chartContainer.querySelector(`.chart-type-btn[data-type="${type}"]`);
        if (clickedButton) {
            clickedButton.classList.add('active');
        } else {
            console.warn(`Кнопка с типом ${type} для графика ${chartId} не найдена`);
        }
        
        // Изменяем тип графика
        switch (chartId) {
            case 'visitors':
                if (window.visitorsChart) {
                    window.visitorsChart.config.type = type;
                    window.visitorsChart.update();
                }
                break;
            case 'orders':
                if (window.ordersChart) {
                    window.ordersChart.config.type = type;
                    window.ordersChart.update();
                }
                break;
        }
    } catch (error) {
        console.error('Ошибка при изменении типа графика:', error);
    }
}

// Функция для экспорта статистики
function exportStatistics() {
    try {
        // Проверяем, есть ли данные для экспорта
        if (!statsData.visitors.length && !statsData.orders.length) {
            alert('Нет данных для экспорта. Пожалуйста, загрузите данные сначала.');
            return;
        }
        
        // Получаем текст выбранного периода
        const dateRangeSelect = document.getElementById('date-range');
        const periodText = dateRangeSelect ? 
            dateRangeSelect.options[dateRangeSelect.selectedIndex].text : 
            'Последние 30 дней';
        
        // Создаем объект с данными для экспорта
        const exportData = {
            date: new Date().toLocaleString('ru-RU'),
            period: periodText,
            visitors: {
                total: statsData.visitors.reduce((sum, item) => sum + parseInt(item.count), 0),
                data: statsData.visitors
            },
            orders: {
                total: statsData.orders.reduce((sum, item) => sum + parseInt(item.count), 0),
                data: statsData.orders
            },
            revenue: {
                total: statsData.revenue.reduce((sum, item) => sum + parseFloat(item.revenue), 0),
                data: statsData.revenue
            },
            fuelTypes: statsData.fuelTypes,
            recentOrders: statsData.recentOrders
        };
        
        // Преобразуем данные в JSON
        const jsonData = JSON.stringify(exportData, null, 2);
        
        // Создаем Blob с данными
        const blob = new Blob([jsonData], { type: 'application/json' });
        
        // Создаем ссылку для скачивания
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `statistics_export_${formatDate(new Date()).replace(/\./g, '-')}.json`;
        
        // Добавляем ссылку в DOM и эмулируем клик
        document.body.appendChild(a);
        a.click();
        
        // Удаляем ссылку из DOM
        setTimeout(() => {
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 0);
        
        console.log("Статистика успешно экспортирована");
    } catch (error) {
        console.error("Ошибка при экспорте статистики:", error);
        alert("Ошибка при экспорте статистики. Пожалуйста, попробуйте еще раз.");
    }
}

// Функция форматирования даты
function formatDate(date) {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}.${month}.${year}`;
}