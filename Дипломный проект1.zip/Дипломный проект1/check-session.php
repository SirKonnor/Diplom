<?php
header('Content-Type: application/json');
session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'session_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));

// Проверяем авторизацию
$isAuthenticated = false;
$userData = null;

// Проверяем различные варианты хранения данных пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    
    // Пытаемся получить данные пользователя из базы данных
    try {
        require_once 'config.php';
        
        $stmt = $pdo->prepare("SELECT id, firstName, lastName, email, role FROM user WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            $userData = $user;
            
            // Сохраняем данные пользователя в сессии для будущего использования
            $_SESSION['user'] = $userData;
        } else {
            $isAuthenticated = false;
        }
    } catch (PDOException $e) {
        logError("Database error: " . $e->getMessage());
        $isAuthenticated = false;
    }
}
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userData = $_SESSION['user'];
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userData = $_SESSION['auth']['user'];
}

// Возвращаем результат проверки
echo json_encode([
    'success' => true,
    'isAuthenticated' => $isAuthenticated,
    'user' => $userData,
    'session_id' => session_id(),
    'debug' => [
        'session' => $_SESSION
    ]
]);
?>