document.addEventListener("DOMContentLoaded", () => {
  // Получаем данные авторизации
  const authData = JSON.parse(sessionStorage.getItem("auth")) || {}

  // Проверяем авторизацию
  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // Основные элементы DOM
  const conversationsList = document.getElementById("conversationsList")
  const messagesBody = document.getElementById("messagesBody")
  const messageInput = document.getElementById("messageInput")
  const sendMessageBtn = document.getElementById("sendMessageBtn")
  const conversationTitle = document.getElementById("conversationTitle")
  const userStatusHeader = document.getElementById("userStatusHeader")
  const headerStatusIndicator = document.getElementById("headerStatusIndicator")
  const headerStatusText = document.getElementById("headerStatusText")
  const viewProfileBtn = document.getElementById("viewProfileBtn")
  const messageInputContainer = document.querySelector(".message-input")
  const adminUsersBtn = document.getElementById("adminUsersBtn")
  const messagesTitle = document.getElementById("messagesTitle")
  const logoutBtn = document.getElementById("logoutBtn")
  const adminSearchContainer = document.getElementById("adminSearchContainer")
  const searchInput = document.getElementById("searchInput")
  const searchButton = document.getElementById("searchButton")
  const sortSelect = document.getElementById("sortSelect")

  // Элементы для работы с файлами
  const fileInput = document.getElementById("fileInput")
  const attachButton = document.getElementById("attachButton")
  const attachmentPreview = document.getElementById("attachmentPreview")

  // Переменные состояния
  const isAdmin = authData.user?.role === "admin"
  const isHelper = authData.user?.role === "helper"
  const isSupport = isAdmin || isHelper
  let currentConversationId = null
  let currentConversationUserId = null // Добавляем переменную для хранения ID пользователя
  let allConversations = []
  let statusUpdateInterval = null
  let messageCheckInterval = null
  let selectedFiles = []

  // Функция для обработки выбора файлов
  const handleFileSelect = (event) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    // Добавляем новые файлы к существующим (если зажат Ctrl)
    if (!event.ctrlKey && !event.metaKey) {
      selectedFiles = []
      attachmentPreview.innerHTML = ""
    }

    // Обрабатываем каждый выбранный файл
    for (let i = 0; i < files.length; i++) {
      const file = files[i]

      // Проверяем размер файла (максимум 10MB)
      if (file.size > 10 * 1024 * 1024) {
        alert(`Файл "${file.name}" слишком большой. Максимальный размер: 10MB`)
        continue
      }

      selectedFiles.push(file)
      createFilePreview(file, selectedFiles.length - 1)
    }

    // Показываем контейнер превью
    attachmentPreview.style.display = selectedFiles.length > 0 ? "flex" : "none"

    // Очищаем input для возможности выбора тех же файлов снова
    fileInput.value = ""
  }

  // Функция для создания превью файла
  const createFilePreview = (file, index) => {
    const previewItem = document.createElement("div")
    previewItem.className = "attachment-preview-item"
    previewItem.dataset.index = index

    // Определяем тип файла и создаем соответствующее превью
    if (file.type.startsWith("image/")) {
      // Превью изображения
      const reader = new FileReader()
      reader.onload = (e) => {
        previewItem.innerHTML = `
          <div class="file-preview-content">
            <img src="${e.target.result}" alt="${file.name}" class="attachment-thumbnail">
            <div class="file-info">
              <span class="file-name" title="${file.name}">${truncateFileName(file.name, 20)}</span>
              <span class="file-size">${formatFileSize(file.size)}</span>
            </div>
            <button class="remove-attachment" data-index="${index}" title="Удалить файл">
              <i class="fas fa-times"></i>
            </button>
          </div>
        `
        attachmentPreview.appendChild(previewItem)
        addRemoveListener(previewItem.querySelector(".remove-attachment"))
      }
      reader.readAsDataURL(file)
    } else {
      // Превью для других типов файлов
      const icon = getFileIcon(file.type)
      previewItem.innerHTML = `
        <div class="file-preview-content">
          <div class="file-icon-container">
            <i class="fas ${icon} file-icon"></i>
          </div>
          <div class="file-info">
            <span class="file-name" title="${file.name}">${truncateFileName(file.name, 20)}</span>
            <span class="file-size">${formatFileSize(file.size)}</span>
          </div>
          <button class="remove-attachment" data-index="${index}" title="Удалить файл">
            <i class="fas fa-times"></i>
          </button>
        </div>
      `
      attachmentPreview.appendChild(previewItem)
      addRemoveListener(previewItem.querySelector(".remove-attachment"))
    }
  }

  // Функция для добавления обработчика удаления файла
  const addRemoveListener = (button) => {
    button.addEventListener("click", (e) => {
      const index = Number.parseInt(e.currentTarget.dataset.index)
      removeAttachment(index)
    })
  }

  // Функция для удаления файла из превью
  const removeAttachment = (index) => {
    if (index >= 0 && index < selectedFiles.length) {
      selectedFiles.splice(index, 1)
      rebuildPreview()
    }
  }

  // Функция для пересборки превью после удаления файла
  const rebuildPreview = () => {
    attachmentPreview.innerHTML = ""

    selectedFiles.forEach((file, index) => {
      createFilePreview(file, index)
    })

    attachmentPreview.style.display = selectedFiles.length > 0 ? "flex" : "none"
  }

  // Функция для получения иконки файла
  const getFileIcon = (fileType) => {
    if (fileType.includes("pdf")) return "fa-file-pdf"
    if (fileType.includes("word") || fileType.includes("document")) return "fa-file-word"
    if (fileType.includes("excel") || fileType.includes("spreadsheet")) return "fa-file-excel"
    if (fileType.includes("powerpoint") || fileType.includes("presentation")) return "fa-file-powerpoint"
    if (fileType.includes("video")) return "fa-file-video"
    if (fileType.includes("audio")) return "fa-file-audio"
    if (fileType.includes("zip") || fileType.includes("archive") || fileType.includes("rar")) return "fa-file-archive"
    if (fileType.includes("text")) return "fa-file-alt"
    return "fa-file"
  }

  // Функция для форматирования размера файла
  const formatFileSize = (bytes) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  // Функция для обрезки имени файла
  const truncateFileName = (fileName, maxLength) => {
    if (fileName.length <= maxLength) return fileName
    const extension = fileName.split(".").pop()
    const nameWithoutExt = fileName.substring(0, fileName.lastIndexOf("."))
    const truncatedName = nameWithoutExt.substring(0, maxLength - extension.length - 4) + "..."
    return truncatedName + "." + extension
  }

  // Функция для обновления статуса пользователя
  const updateUserStatus = async (status) => {
    try {
      await fetch("update-user-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
          status: status,
        }),
      })
    } catch (error) {
      console.error("Ошибка обновления статуса:", error)
    }
  }

  // Функция для получения статуса пользователя
  const getUserStatus = async (userId) => {
    try {
      const response = await fetch("get-user-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userId,
        }),
      })

      const data = await response.json()
      return data.success ? data : { success: false, status: "offline", lastSeen: null }
    } catch (error) {
      console.error("Ошибка получения статуса:", error)
      return { success: false, status: "offline", lastSeen: null }
    }
  }

  // Функция для форматирования времени последнего посещения
  const formatLastSeen = (lastSeen) => {
    if (!lastSeen) return "Неизвестно"

    const lastSeenDate = new Date(lastSeen)
    const now = new Date()
    const diffMs = now - lastSeenDate
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMins / 60)
    const diffDays = Math.floor(diffHours / 24)

    if (diffMins < 1) return "Только что"
    if (diffMins < 60) return `${diffMins} мин. назад`
    if (diffHours < 24) return `${diffHours} ч. назад`
    if (diffDays < 7) return `${diffDays} дн. назад`

    return lastSeenDate.toLocaleDateString()
  }

  // Функция для получения текста статуса
  const getStatusText = (status, lastSeen) => {
    switch (status) {
      case "online":
        return "В сети"
      case "offline":
        return lastSeen ? `Был в сети ${formatLastSeen(lastSeen)}` : "Не в сети"
      default:
        return "Не в сети"
    }
  }

  // Функция для форматирования последнего сообщения с учетом вложений
  const formatLastMessage = (message, hasAttachments, attachmentCount, lastAttachmentName) => {
    if (hasAttachments && attachmentCount > 0) {
      if (message && message.trim()) {
        // Есть и текст, и файлы
        if (attachmentCount === 1) {
          return `📎 ${lastAttachmentName || "Файл"}: ${message}`
        } else {
          return `📎 ${attachmentCount} файлов: ${message}`
        }
      } else {
        // Только файлы без текста
        if (attachmentCount === 1) {
          return `📎 ${lastAttachmentName || "Файл"}`
        } else {
          return `📎 ${attachmentCount} файлов`
        }
      }
    } else if (message && message.trim()) {
      // Только текст
      return message
    } else {
      // Нет ни текста, ни файлов
      return "Нет сообщений"
    }
  }

  // Функция для создания элемента диалога
  const createConversationElement = (conversation) => {
    const convElement = document.createElement("div")
    convElement.className = "conversation"
    convElement.dataset.userId = conversation.user_id
    convElement.dataset.userName = conversation.user_name
    convElement.dataset.status = conversation.status || "offline"

    const statusText = getStatusText(conversation.status, conversation.last_seen)
    const unreadBadge =
      conversation.unread_count > 0 ? `<span class="unread-count">${conversation.unread_count}</span>` : ""

    // Форматируем последнее сообщение с учетом вложений
    const formattedLastMessage = formatLastMessage(
      conversation.last_message,
      conversation.has_attachments,
      conversation.attachment_count,
      conversation.last_attachment_name,
    )

    convElement.innerHTML = `
      <div class="conversation-avatar">
        <img src="${conversation.avatar_path || "images/default-avatar.png"}" 
             alt="${conversation.user_name}"
             onerror="this.src='images/default-avatar.png'">
        <div class="user-status ${conversation.status || "offline"}"></div>
      </div>
      <div class="conversation-info">
        <h4>${conversation.user_name}</h4>
        <p class="last-message">${formattedLastMessage}</p>
        <div class="conversation-meta">
          <span class="message-time">${conversation.last_message_time || ""}</span>
          <span class="user-status-text ${conversation.status || "offline"}">${statusText}</span>
        </div>
        <small class="user-id-display">ID: ${conversation.user_id}</small>
        ${unreadBadge}
      </div>
    `

    // Добавляем обработчик клика
    convElement.addEventListener("click", () => {
      openConversation(conversation.user_id, conversation.user_name, conversation.status, conversation.last_seen)
    })

    return convElement
  }

  // Функция для создания элемента техподдержки
  const createSupportElement = async () => {
    try {
      const adminId = await getAdminId()
      let adminStatus = { status: "offline", last_seen: null }

      if (adminId) {
        adminStatus = await getUserStatus(adminId)
      }

      const supportElement = document.createElement("div")
      supportElement.className = "conversation"
      supportElement.dataset.conversationId = "support"
      supportElement.dataset.adminId = adminId

      const statusText = getStatusText(adminStatus.status, adminStatus.last_seen)

      supportElement.innerHTML = `
        <div class="conversation-avatar">
          <i class="fas fa-headset"></i>
          <div class="user-status ${adminStatus.status}"></div>
        </div>
        <div class="conversation-info">
          <h4>Техподдержка</h4>
          <p class="last-message">Напишите ваш вопрос...</p>
          <div class="conversation-meta">
            <span class="message-time">Всегда доступна</span>
            <span class="user-status-text ${adminStatus.status}">${statusText}</span>
          </div>
          <small class="user-id-display">ID: ${adminId || "Н/Д"}</small>
        </div>
      `

      // Добавляем обработчик клика
      supportElement.addEventListener("click", () => {
        openSupportConversation(adminId, adminStatus.status, adminStatus.last_seen)
      })

      return supportElement
    } catch (error) {
      console.error("Ошибка создания элемента техподдержки:", error)
      return null
    }
  }

  // Функция для получения ID администратора
  const getAdminId = async () => {
    try {
      const response = await fetch("get-admin-id.php", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()
      return data.success ? data.adminId : null
    } catch (error) {
      console.error("Ошибка получения ID администратора:", error)
      return null
    }
  }

  // Функция для загрузки диалогов с поддержкой вложений
  const loadConversations = async () => {
    try {
      conversationsList.innerHTML = `
        <div class="loading-conversations">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Загрузка диалогов...</p>
        </div>
      `

      if (isSupport) {
        // Показываем панель поиска для админа/помощника
        if (adminSearchContainer) {
          adminSearchContainer.style.display = "block"
        }

        // Загружаем диалоги для админа/помощника с информацией о вложениях
        const response = await fetch("get-admin-conversations-with-attachments.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            adminId: authData.user.id,
            showAll: true,
            isHelper: isHelper,
          }),
        })

        const data = await response.json()

        if (data.success && data.conversations) {
          allConversations = data.conversations

          // Получаем статусы для всех пользователей
          for (const conv of allConversations) {
            const statusData = await getUserStatus(conv.user_id)
            conv.status = statusData.status
            conv.last_seen = statusData.lastSeen
          }

          displayConversations(allConversations)
        } else {
          conversationsList.innerHTML = '<p class="empty">Нет активных диалогов</p>'
        }
      } else {
        // Для обычного пользователя
        conversationsList.innerHTML = ""

        // Создаем элемент техподдержки
        const supportElement = await createSupportElement()
        if (supportElement) {
          conversationsList.appendChild(supportElement)
        }

        // Загружаем другие диалоги пользователя с информацией о вложениях
        try {
          const response = await fetch("get-user-conversations-with-attachments.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              userId: authData.user.id,
            }),
          })

          const data = await response.json()

          if (data.success && data.conversations) {
            for (const conv of data.conversations) {
              if (conv.support_role !== "helper") {
                const statusData = await getUserStatus(conv.user_id)
                conv.status = statusData.status
                conv.last_seen = statusData.lastSeen

                const convElement = createConversationElement(conv)
                conversationsList.appendChild(convElement)
              }
            }
          }
        } catch (error) {
          console.error("Ошибка загрузки диалогов пользователя:", error)
        }
      }

      // Автоматически открываем первый диалог
      const firstConversation = conversationsList.querySelector(".conversation")
      if (firstConversation) {
        firstConversation.click()
      }
    } catch (error) {
      console.error("Ошибка загрузки диалогов:", error)
      conversationsList.innerHTML = '<p class="error">Ошибка загрузки диалогов</p>'
    }
  }

  // Функция для отображения диалогов
  const displayConversations = (conversations) => {
    conversationsList.innerHTML = ""

    if (!conversations || conversations.length === 0) {
      conversationsList.innerHTML = '<p class="empty">Нет активных диалогов</p>'
      return
    }

    conversations.forEach((conversation) => {
      const convElement = createConversationElement(conversation)
      conversationsList.appendChild(convElement)
    })
  }

  // ИСПРАВЛЕННАЯ функция для открытия диалога
  const openConversation = async (userId, userName, status = "offline", lastSeen = null) => {
    currentConversationId = userId
    currentConversationUserId = userId // Сохраняем ID пользователя отдельно

    // Обновляем активный диалог
    document.querySelectorAll(".conversation").forEach((c) => c.classList.remove("active"))
    const activeConv = document.querySelector(`[data-user-id="${userId}"]`)
    if (activeConv) {
      activeConv.classList.add("active")

      // ИСПРАВЛЕНИЕ: Убираем уведомления для этого диалога
      const unreadBadge = activeConv.querySelector(".unread-count")
      if (unreadBadge) {
        unreadBadge.remove()
      }
    }

    // Обновляем заголовок
    conversationTitle.textContent = `${userName} (ID: ${userId})`

    // Обновляем статус в заголовке
    if (userStatusHeader && headerStatusIndicator && headerStatusText) {
      userStatusHeader.style.display = "flex"
      headerStatusIndicator.className = `status-indicator ${status}`
      headerStatusText.textContent = getStatusText(status, lastSeen)
      headerStatusText.className = `status-text ${status}`
    }

    // ИСПРАВЛЕНИЕ: Показываем кнопку профиля с правильным ID
    if (viewProfileBtn) {
      viewProfileBtn.style.display = "inline-block"
      viewProfileBtn.innerHTML = '<i class="fas fa-user"></i> Профиль'
      viewProfileBtn.onclick = () => {
        window.location.href = `profile.html?userId=${userId}` // Используем правильный userId
      }
    }

    // Показываем поле ввода
    if (messageInputContainer) {
      messageInputContainer.style.display = "flex"
    }

    // Загружаем сообщения
    await loadMessages(userId)

    // ИСПРАВЛЕНИЕ: Отмечаем сообщения как прочитанные
    await markMessagesAsRead(userId)
  }

  // Функция для открытия диалога с техподдержкой
  const openSupportConversation = async (adminId, status = "offline", lastSeen = null) => {
    currentConversationId = "support"
    currentConversationUserId = adminId // Сохраняем ID админа

    // Обновляем активный диалог
    document.querySelectorAll(".conversation").forEach((c) => c.classList.remove("active"))
    const supportConv = document.querySelector('[data-conversation-id="support"]')
    if (supportConv) {
      supportConv.classList.add("active")
    }

    // Обновляем заголовок
    conversationTitle.textContent = `Техподдержка ${adminId ? `(ID: ${adminId})` : ""}`

    // Обновляем статус в заголовке
    if (userStatusHeader && headerStatusIndicator && headerStatusText) {
      userStatusHeader.style.display = "flex"
      headerStatusIndicator.className = `status-indicator ${status}`
      headerStatusText.textContent = getStatusText(status, lastSeen)
      headerStatusText.className = `status-text ${status}`
    }

    // Показываем кнопку профиля техподдержки
    if (viewProfileBtn && adminId) {
      viewProfileBtn.style.display = "inline-block"
      viewProfileBtn.innerHTML = '<i class="fas fa-headset"></i> Профиль техподдержки'
      viewProfileBtn.onclick = () => {
        window.location.href = `profile.html?userId=${adminId}` // Используем ID админа
      }
    }

    // Показываем поле ввода
    if (messageInputContainer) {
      messageInputContainer.style.display = "flex"
    }

    // Загружаем сообщения
    await loadMessages("support")

    // Отмечаем сообщения как прочитанные
    if (adminId) {
      await markMessagesAsRead(adminId)
    }
  }

  // НОВАЯ функция для отметки сообщений как прочитанные
  const markMessagesAsRead = async (senderId) => {
    try {
      const response = await fetch("mark-messages-read.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          receiverId: authData.user.id,
          senderId: senderId,
        }),
      })

      const data = await response.json()
      if (!data.success) {
        console.error("Ошибка отметки сообщений как прочитанные:", data.error)
      }
    } catch (error) {
      console.error("Ошибка отметки сообщений как прочитанные:", error)
    }
  }

  // Функция для загрузки сообщений
  const loadMessages = async (conversationId) => {
    try {
      messagesBody.innerHTML = `
        <div class="loading-messages">
          <i class="fas fa-spinner fa-spin"></i>
          <p>Загрузка сообщений...</p>
        </div>
      `

      const response = await fetch("get-messages.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
          conversationId: conversationId,
          isAdmin: isAdmin,
          isHelper: isHelper,
        }),
      })

      const data = await response.json()

      if (data.success) {
        displayMessages(data.messages)
      } else {
        messagesBody.innerHTML = '<p class="error">Ошибка загрузки сообщений</p>'
      }
    } catch (error) {
      console.error("Ошибка загрузки сообщений:", error)
      messagesBody.innerHTML = '<p class="error">Ошибка загрузки сообщений</p>'
    }
  }

  // Функция для отображения сообщений
  const displayMessages = (messages) => {
    messagesBody.innerHTML = ""

    if (!messages || messages.length === 0) {
      messagesBody.innerHTML = `
        <div class="empty-conversation">
          <i class="fas fa-comments"></i>
          <h3>Нет сообщений</h3>
          <p>Начните диалог, отправив первое сообщение</p>
        </div>
      `
      return
    }

    messages.forEach((message) => {
      const isOutgoing = message.sender_id == authData.user.id
      const messageElement = document.createElement("div")
      messageElement.className = `message ${isOutgoing ? "message-outgoing" : "message-incoming"}`

      let senderInfo = ""
      if (!isOutgoing) {
        if (message.sender_role === "admin") {
          senderInfo = `<small class="sender-role">Администратор (ID: ${message.sender_id})</small>`
        } else if (message.sender_role === "helper") {
          senderInfo = `<small class="sender-role">Техподдержка (ID: ${message.sender_id})</small>`
        }
      }

      // Создаем HTML для вложений
      let attachmentsHtml = ""
      if (message.attachments && message.attachments.length > 0) {
        attachmentsHtml = '<div class="message-attachments">'

        message.attachments.forEach((attachment) => {
          if (attachment.file_type.startsWith("image/")) {
            // Изображение
            attachmentsHtml += `
              <div class="attachment-item attachment-image">
                <a href="${attachment.file_path}" target="_blank" class="attachment-link">
                  <img src="${attachment.file_path}" alt="${attachment.file_name}" class="attachment-img">
                  <div class="attachment-overlay">
                    <i class="fas fa-search-plus"></i>
                  </div>
                </a>
                <div class="attachment-info">
                  <span class="attachment-name">${attachment.file_name}</span>
                  <span class="attachment-size">${formatFileSize(attachment.file_size)}</span>
                </div>
              </div>
            `
          } else if (attachment.file_type.startsWith("video/")) {
            // Видео
            attachmentsHtml += `
              <div class="attachment-item attachment-video">
                <video controls class="attachment-video-player">
                  <source src="${attachment.file_path}" type="${attachment.file_type}">
                  Ваш браузер не поддерживает видео.
                </video>
                <div class="attachment-info">
                  <span class="attachment-name">${attachment.file_name}</span>
                  <span class="attachment-size">${formatFileSize(attachment.file_size)}</span>
                </div>
              </div>
            `
          } else if (attachment.file_type.startsWith("audio/")) {
            // Аудио
            attachmentsHtml += `
              <div class="attachment-item attachment-audio">
                <audio controls class="attachment-audio-player">
                  <source src="${attachment.file_path}" type="${attachment.file_type}">
                  Ваш браузер не поддерживает аудио.
                </audio>
                <div class="attachment-info">
                  <span class="attachment-name">${attachment.file_name}</span>
                  <span class="attachment-size">${formatFileSize(attachment.file_size)}</span>
                </div>
              </div>
            `
          } else {
            // Другие файлы
            const icon = getFileIcon(attachment.file_type)
            attachmentsHtml += `
              <div class="attachment-item attachment-file">
                <a href="${attachment.file_path}" target="_blank" download="${attachment.file_name}" class="attachment-link">
                  <div class="attachment-icon">
                    <i class="fas ${icon}"></i>
                  </div>
                  <div class="attachment-info">
                    <span class="attachment-name">${attachment.file_name}</span>
                    <span class="attachment-size">${formatFileSize(attachment.file_size)}</span>
                  </div>
                  <div class="attachment-download">
                    <i class="fas fa-download"></i>
                  </div>
                </a>
              </div>
            `
          }
        })

        attachmentsHtml += "</div>"
      }

      messageElement.innerHTML = `
        ${senderInfo}
        ${message.text ? `<p>${message.text}</p>` : ""}
        ${attachmentsHtml}
        <small>${new Date(message.created_at).toLocaleString()}</small>
        ${
          isOutgoing
            ? `<div class="read-status ${message.is_read ? "read" : "unread"}">
          ${message.is_read ? "Прочитано" : "Отправлено"} <i class="fas fa-check${message.is_read ? "-double" : ""}"></i>
        </div>`
            : ""
        }
      `

      messagesBody.appendChild(messageElement)
    })

    messagesBody.scrollTop = messagesBody.scrollHeight
  }

  // Функция для отправки сообщения
  const sendMessage = async () => {
    const text = messageInput.value.trim()
    const hasFiles = selectedFiles.length > 0

    if (!text && !hasFiles) {
      alert("Введите текст сообщения или прикрепите файл")
      return
    }

    if (!currentConversationId) {
      alert("Выберите диалог для отправки сообщения")
      return
    }

    try {
      // Блокируем кнопку отправки
      sendMessageBtn.disabled = true
      sendMessageBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'

      let response

      if (hasFiles) {
        // Отправляем с файлами через FormData
        const formData = new FormData()
        formData.append("sender_id", authData.user.id)
        formData.append("receiver_id", currentConversationId === "support" ? "support" : currentConversationId)
        formData.append("text", text)
        formData.append("isAdmin", isAdmin)
        formData.append("isHelper", isHelper)

        // Добавляем файлы
        selectedFiles.forEach((file) => {
          formData.append("attachments[]", file)
        })

        response = await fetch("send-message-with-attachments.php", {
          method: "POST",
          body: formData,
        })
      } else {
        // Отправляем только текст через JSON
        response = await fetch("send-message.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sender_id: authData.user.id,
            receiver_id: currentConversationId === "support" ? "support" : currentConversationId,
            text: text,
            isAdmin: isAdmin,
            isHelper: isHelper,
          }),
        })
      }

      const data = await response.json()

      if (data.success) {
        // Очищаем поля ввода
        messageInput.value = ""
        selectedFiles = []
        attachmentPreview.innerHTML = ""
        attachmentPreview.style.display = "none"

        // Перезагружаем сообщения
        await loadMessages(currentConversationId)

        // Обновляем список диалогов для админа
        if (isSupport) {
          await loadConversations()
        }
      } else {
        alert("Ошибка отправки сообщения: " + (data.error || "Неизвестная ошибка"))
      }
    } catch (error) {
      console.error("Ошибка отправки сообщения:", error)
      alert("Ошибка отправки сообщения")
    } finally {
      // Разблокируем кнопку отправки
      sendMessageBtn.disabled = false
      sendMessageBtn.innerHTML = '<i class="fas fa-paper-plane"></i>'
    }
  }

  // Функция для обновления статусов всех пользователей
  const updateAllUserStatuses = async () => {
    const conversations = document.querySelectorAll(".conversation")

    for (const conv of conversations) {
      const userId = conv.dataset.userId || conv.dataset.adminId
      if (userId && userId !== "support") {
        const statusData = await getUserStatus(userId)

        // Обновляем индикатор статуса
        const statusIndicator = conv.querySelector(".user-status")
        if (statusIndicator) {
          statusIndicator.className = `user-status ${statusData.status}`
        }

        // Обновляем текст статуса
        const statusText = conv.querySelector(".user-status-text")
        if (statusText) {
          const newStatusText = getStatusText(statusData.status, statusData.lastSeen)
          statusText.textContent = newStatusText
          statusText.className = `user-status-text ${statusData.status}`
        }

        // Обновляем статус в заголовке, если это текущий диалог
        if (currentConversationId == userId) {
          if (headerStatusIndicator && headerStatusText) {
            headerStatusIndicator.className = `status-indicator ${statusData.status}`
            headerStatusText.textContent = getStatusText(statusData.status, statusData.lastSeen)
            headerStatusText.className = `status-text ${statusData.status}`
          }
        }
      }
    }
  }

  // Функция поиска
  const performSearch = () => {
    if (!isSupport) return

    const searchTerm = searchInput.value.trim().toLowerCase()

    if (!searchTerm) {
      displayConversations(allConversations)
      return
    }

    const filteredConversations = allConversations.filter((conv) => {
      const userName = conv.user_name.toLowerCase()
      const userId = conv.user_id.toString()
      return userName.includes(searchTerm) || userId.includes(searchTerm)
    })

    displayConversations(filteredConversations)
  }

  // Функция сортировки
  const sortConversations = () => {
    if (!isSupport || !sortSelect) return

    const sortValue = sortSelect.value
    const sortedConversations = [...allConversations]

    switch (sortValue) {
      case "newest":
        sortedConversations.sort((a, b) => new Date(b.last_message_time || 0) - new Date(a.last_message_time || 0))
        break
      case "oldest":
        sortedConversations.sort((a, b) => new Date(a.last_message_time || 0) - new Date(b.last_message_time || 0))
        break
      case "unread":
        sortedConversations.sort((a, b) => (b.unread_count || 0) - (a.unread_count || 0))
        break
      case "name":
        sortedConversations.sort((a, b) => a.user_name.localeCompare(b.user_name))
        break
      case "online":
        sortedConversations.sort((a, b) => {
          if (a.status === "online" && b.status !== "online") return -1
          if (a.status !== "online" && b.status === "online") return 1
          return 0
        })
        break
    }

    displayConversations(sortedConversations)
  }

  // Обработчики событий для файлов
  if (fileInput) {
    fileInput.addEventListener("change", handleFileSelect)
  }

  if (attachButton) {
    attachButton.addEventListener("click", () => {
      fileInput.click()
    })
  }

  // Обработчики событий
  if (sendMessageBtn) {
    sendMessageBtn.addEventListener("click", sendMessage)
  }

  if (messageInput) {
    messageInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault()
        sendMessage()
      }
    })
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      updateUserStatus("offline")
      sessionStorage.removeItem("auth")
      window.location.href = "index.html"
    })
  }

  if (searchButton) {
    searchButton.addEventListener("click", performSearch)
  }

  if (searchInput) {
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        performSearch()
      }
    })
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", sortConversations)
  }

  // Показываем кнопку админа только для администратора
  if (isAdmin && adminUsersBtn) {
    adminUsersBtn.style.display = "block"
    messagesTitle.textContent = "Сообщения от пользователей"

    adminUsersBtn.addEventListener("click", () => {
      window.location.href = "admin-users.html"
    })
  }

  // Мобильное меню
  const mobileMenuBtn = document.getElementById("mobileMenuBtn")
  const navMenu = document.getElementById("navMenu")
  const conversationsToggle = document.getElementById("conversationsToggle")
  const backToConversations = document.getElementById("backToConversations")

  if (mobileMenuBtn && navMenu) {
    mobileMenuBtn.addEventListener("click", () => {
      navMenu.classList.toggle("active")
      mobileMenuBtn.classList.toggle("active")
    })
  }

  if (conversationsToggle) {
    conversationsToggle.addEventListener("click", () => {
      conversationsList.classList.toggle("active")
    })
  }

  if (backToConversations) {
    backToConversations.addEventListener("click", () => {
      if (window.innerWidth <= 768) {
        conversationsList.classList.add("active")
        document.querySelector(".messages-container").classList.remove("active")
      }
    })
  }

  // Drag & Drop функциональность
  const setupDragAndDrop = () => {
    const dropZone = messageInputContainer

    if (!dropZone) return // Предотвращаем стандартное поведение браузера
    ;["dragenter", "dragover", "dragleave", "drop"].forEach((eventName) => {
      dropZone.addEventListener(eventName, preventDefaults, false)
      document.body.addEventListener(eventName, preventDefaults, false)
    })

    // Подсвечиваем зону при перетаскивании
    ;["dragenter", "dragover"].forEach((eventName) => {
      dropZone.addEventListener(eventName, highlight, false)
    })
    ;["dragleave", "drop"].forEach((eventName) => {
      dropZone.addEventListener(eventName, unhighlight, false)
    })

    // Обрабатываем сброс файлов
    dropZone.addEventListener("drop", handleDrop, false)

    function preventDefaults(e) {
      e.preventDefault()
      e.stopPropagation()
    }

    function highlight() {
      dropZone.classList.add("drag-over")
    }

    function unhighlight() {
      dropZone.classList.remove("drag-over")
    }

    function handleDrop(e) {
      const dt = e.dataTransfer
      const files = dt.files

      if (files.length > 0) {
        // Создаем событие для обработки файлов
        const event = { target: { files: files }, ctrlKey: false }
        handleFileSelect(event)
      }
    }
  }

  // Инициализация
  const init = async () => {
    // Устанавливаем статус онлайн
    await updateUserStatus("online")

    // Загружаем диалоги
    await loadConversations()

    // Настраиваем drag & drop
    setupDragAndDrop()

    // Запускаем интервалы обновления
    statusUpdateInterval = setInterval(() => {
      updateUserStatus("online")
    }, 15000) // Каждые 15 секунд

    messageCheckInterval = setInterval(() => {
      updateAllUserStatuses()
    }, 10000) // Каждые 10 секунд
  }

  // Обработка закрытия страницы
  window.addEventListener("beforeunload", () => {
    updateUserStatus("offline")
    if (statusUpdateInterval) clearInterval(statusUpdateInterval)
    if (messageCheckInterval) clearInterval(messageCheckInterval)
  })

  // Запускаем инициализацию
  init()
})
