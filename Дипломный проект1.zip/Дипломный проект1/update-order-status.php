<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['orderId']) || empty($data['orderId'])) {
        throw new Exception('Order ID is required');
    }
    
    if (!isset($data['status']) || empty($data['status'])) {
        throw new Exception('Status is required');
    }
    
    $orderId = $data['orderId'];
    $status = $data['status'];
    
    // Validate status
    $validStatuses = ['PENDING', 'CONFIRMED', 'DELIVERED', 'CANCELLED'];
    if (!in_array($status, $validStatuses)) {
        throw new Exception('Invalid status. Valid statuses are: ' . implode(', ', $validStatuses));
    }
    
    // Check if user is admin
    $isAdmin = isset($data['isAdmin']) ? $data['isAdmin'] : false;
    
    if (!$isAdmin) {
        throw new Exception('Only administrators can update order status');
    }
    
    // Get reason if provided (for CANCELLED status)
    $reason = isset($data['reason']) ? trim($data['reason']) : null;
    
    // Require reason for CANCELLED status
    if ($status === 'CANCELLED' && empty($reason)) {
        throw new Exception('Reason is required when cancelling an order');
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Update order status
try {
    // First check if the order exists
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = :orderId");
    $stmt->execute(['orderId' => $orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception('Order not found');
    }
    
    // Check if the reason column exists in the orders table
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'reason'");
    $reasonColumnExists = $stmt->rowCount() > 0;
    
    // If reason column doesn't exist, add it
    if (!$reasonColumnExists) {
        $pdo->exec("ALTER TABLE orders ADD COLUMN reason TEXT");
    }
    
    // Update the order status and reason if provided
    if ($status === 'CANCELLED' && $reason) {
        $stmt = $pdo->prepare("UPDATE orders SET status = :status, reason = :reason WHERE id = :orderId");
        $stmt->execute([
            'status' => $status,
            'reason' => $reason,
            'orderId' => $orderId
        ]);
    } else {
        // For other statuses, clear the reason field
        $stmt = $pdo->prepare("UPDATE orders SET status = :status, reason = NULL WHERE id = :orderId");
        $stmt->execute([
            'status' => $status,
            'orderId' => $orderId
        ]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Order status updated successfully'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
