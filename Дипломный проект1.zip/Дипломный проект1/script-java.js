// Добавляем обработчик для кнопок навигации и "Связаться с нами"
document.addEventListener("DOMContentLoaded", () => {
  // Обработчик для всех ссылок с классом scroll-link
  const scrollLinks = document.querySelectorAll(".scroll-link")
  scrollLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault()
      const targetId = link.getAttribute("href")
      const targetSection = document.querySelector(targetId)

      if (targetSection) {
        targetSection.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  const userIcon = document.getElementById("user-icon")

  if (authData.isAuthenticated) {
    userIcon.href = "profile.html"
    // Можно добавить визуальное отображение
    userIcon.innerHTML = '<i class="fas fa-user-check"></i>'

    // Проверяем наличие непрочитанных сообщений
    checkUnreadMessages(authData.user.id)
  }

  // Инициализируем функциональность сворачивания виджета
  initCurrencyWidgetToggle()

  // Загружаем реальные данные о курсах валют
  fetchRealCurrencyRates()

  // Обновляем данные каждые 2 минуты
  setInterval(fetchRealCurrencyRates, 120000)

  // Добавляем анимацию частиц для hero секции
  animateHeroParticles()

  // Загружаем данные о топливе
  loadFuelsData()

  // Принудительное обновление каждые 10 минут
  setInterval(forceUpdateCurrencyRates, 600000)
})

// ДОБАВЛЕННАЯ функция для инициализации кнопки сворачивания виджета валют
function initCurrencyWidgetToggle() {
  const toggleButton = document.getElementById("currency-toggle")
  const widget = document.getElementById("currency-mini-widget")

  if (toggleButton && widget) {
    // Проверяем сохраненное состояние
    const isCollapsed = localStorage.getItem("currencyWidgetCollapsed") === "true"
    if (isCollapsed) {
      widget.classList.add("collapsed")
    }

    // Добавляем обработчик клика
    toggleButton.addEventListener("click", () => {
      const isCurrentlyCollapsed = widget.classList.contains("collapsed")

      if (isCurrentlyCollapsed) {
        // Разворачиваем
        widget.classList.remove("collapsed")
        localStorage.setItem("currencyWidgetCollapsed", "false")
      } else {
        // Сворачиваем
        widget.classList.add("collapsed")
        localStorage.setItem("currencyWidgetCollapsed", "true")
      }
    })
  }
}

// ИСПРАВЛЕННАЯ функция для обновления мини виджета валют
function updateMiniCurrencyWidget(data) {
  try {
    // Обновляем время последнего обновления
    const updateTimeElement = document.getElementById("mini-update-time")
    if (updateTimeElement) {
      const now = new Date()
      const timeString = now.toLocaleTimeString("ru-RU", {
        hour: "2-digit",
        minute: "2-digit",
      })
      updateTimeElement.textContent = timeString
    }

    // Обновляем курсы валют
    if (data.usd) {
      updateMiniCurrencyItem("usd", data.usd)
    }
    if (data.eur) {
      updateMiniCurrencyItem("eur", data.eur)
    }

    // Обновляем свернутое состояние
    updateCollapsedState(data)

    console.log("Виджет валют успешно обновлен")
  } catch (error) {
    console.error("Ошибка при обновлении виджета валют:", error)
  }
}

// Обновленная функция для получения курсов валют с автоматическим обновлением
async function fetchRealCurrencyRates() {
  try {
    console.log("Запрос курсов валют...")

    // Используем улучшенную версию API
    const response = await fetch("get_currency_rates.php", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })

    console.log("Статус ответа:", response.status)

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`)
    }

    // Получаем текст ответа для отладки
    const responseText = await response.text()
    console.log("Ответ сервера:", responseText)

    // Пытаемся распарсить JSON
    let result
    try {
      result = JSON.parse(responseText)
    } catch (parseError) {
      console.error("Ошибка парсинга JSON:", parseError)
      console.error("Полученный текст:", responseText)
      throw new Error("Сервер вернул некорректный JSON")
    }

    if (!result.success) {
      throw new Error(result.error || "Ошибка получения данных")
    }

    console.log("Полученные данные:", result.data)

    // Показываем информацию об автоматическом обновлении
    if (result.auto_updated) {
      console.log("🔄 Данные автоматически обновлены с API")
    }

    // Обновляем виджет с данными из базы
    updateMiniCurrencyWidget(result.data)

    // Показываем время последнего обновления
    updateLastUpdateTime(result.data)
  } catch (error) {
    console.error("Ошибка при получении курсов валют:", error)

    // Показываем сообщение об ошибке
    const updateTimeElement = document.getElementById("mini-update-time")
    if (updateTimeElement) {
      updateTimeElement.textContent = "Ошибка"
    }

    // Fallback: пробуем получить данн��е напрямую с API
    try {
      console.log("Пробуем резервный API...")
      const fallbackResponse = await fetch("https://api.exchangerate-api.com/v4/latest/RUB")

      if (!fallbackResponse.ok) {
        throw new Error("Резервный API недоступен")
      }

      const fallbackData = await fallbackResponse.json()

      if (fallbackData.rates) {
        const usdRate = (1 / fallbackData.rates.USD).toFixed(2)
        const eurRate = (1 / fallbackData.rates.EUR).toFixed(2)

        console.log("Данные из резервного API:", { usdRate, eurRate })

        updateMiniCurrencyWidget({
          usd: { rate: usdRate, change: "0.00", trend: "neutral" },
          eur: { rate: eurRate, change: "0.00", trend: "neutral" },
        })
      }
    } catch (fallbackError) {
      console.error("Резервный API также недоступен:", fallbackError)

      // Показываем статические данные как последний резерв
      updateMiniCurrencyWidget({
        usd: { rate: "92.50", change: "0.00", trend: "neutral" },
        eur: { rate: "102.30", change: "0.00", trend: "neutral" },
      })
    }
  }
}

// Новая функция для обновления времени последнего обновления
function updateLastUpdateTime(data) {
  const updateTimeElement = document.getElementById("mini-update-time")
  if (updateTimeElement && data.usd && data.usd.last_updated) {
    const lastUpdate = new Date(data.usd.last_updated)
    const now = new Date()
    const diffMinutes = Math.floor((now - lastUpdate) / (1000 * 60))

    let timeText
    if (diffMinutes < 1) {
      timeText = "только что"
    } else if (diffMinutes < 60) {
      timeText = `${diffMinutes} мин назад`
    } else {
      const diffHours = Math.floor(diffMinutes / 60)
      timeText = `${diffHours} ч назад`
    }

    updateTimeElement.textContent = timeText
    updateTimeElement.title = `Последнее обновление: ${lastUpdate.toLocaleString("ru-RU")}`
  }
}

// Добавляем функцию для принудительного обновления курсов
async function forceUpdateCurrencyRates() {
  try {
    console.log("Принудительное обновление курсов...")

    const response = await fetch("update_currency_rates.php", {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
    })

    if (response.ok) {
      const result = await response.json()
      if (result.success) {
        console.log("✅ Курсы принудительно обновлены")
        // Перезагружаем данные
        setTimeout(() => fetchRealCurrencyRates(), 1000)
      }
    }
  } catch (error) {
    console.error("Ошибка принудительного обновления:", error)
  }
}

// Обновленная функция для обновления отдельного элемента валюты
function updateMiniCurrencyItem(currency, data) {
  const rateElement = document.getElementById(`mini-${currency}-rate`)
  const changeElement = document.getElementById(`mini-${currency}-change`)

  if (rateElement && changeElement) {
    // Обновляем курс
    rateElement.textContent = data.rate

    // Обновляем изменение с стрелкой
    const change = Number.parseFloat(data.change)
    const sign = change > 0 ? "+" : ""

    // Определяем иконку стрелки на основе тренда
    let arrowIcon = ""
    let arrowClass = "currency-arrow neutral"

    if (data.trend === "up") {
      arrowIcon = '<i class="fas fa-arrow-up"></i>'
      arrowClass = "currency-arrow up"
    } else if (data.trend === "down") {
      arrowIcon = '<i class="fas fa-arrow-down"></i>'
      arrowClass = "currency-arrow down"
    } else {
      arrowIcon = '<i class="fas fa-minus"></i>'
      arrowClass = "currency-arrow neutral"
    }

    changeElement.innerHTML = `${sign}${Math.abs(change).toFixed(2)} <span class="${arrowClass}">${arrowIcon}</span>`

    // Обновляем стиль в зависимости от тренда
    changeElement.className = "currency-mini-change"
    if (data.trend === "up") {
      changeElement.classList.add("up")
    } else if (data.trend === "down") {
      changeElement.classList.add("down")
    } else {
      changeElement.classList.add("neutral")
    }
  }
}

// Обновленная функция для обновления свернутого состояния
function updateCollapsedState(data) {
  const collapsedUsd = document.getElementById("collapsed-usd")
  const collapsedEur = document.getElementById("collapsed-eur")

  if (collapsedUsd && collapsedEur && data.usd && data.eur) {
    // Добавляем стрелки в свернутое состояние
    const usdArrow = data.usd.trend === "up" ? "↗" : data.usd.trend === "down" ? "↘" : "→"
    const eurArrow = data.eur.trend === "up" ? "↗" : data.eur.trend === "down" ? "↘" : "→"

    const usdColor = data.usd.trend === "up" ? "#4caf50" : data.usd.trend === "down" ? "#f44336" : "#007bff"
    const eurColor = data.eur.trend === "up" ? "#4caf50" : data.eur.trend === "down" ? "#f44336" : "#007bff"

    collapsedUsd.innerHTML = `${data.usd.rate} <span style="color: ${usdColor}">${usdArrow}</span>`
    collapsedEur.innerHTML = `${data.eur.rate} <span style="color: ${eurColor}">${eurArrow}</span>`
  }
}

// Функция для анимации частиц в hero секции
function animateHeroParticles() {
  const heroSection = document.querySelector(".hero")
  if (!heroSection) return

  const particlesContainer = document.querySelector(".hero-particles")
  if (!particlesContainer) return

  // Создаем частицы
  for (let i = 0; i < 50; i++) {
    createParticle(particlesContainer)
  }
}

// Функция для создания отдельной частицы
function createParticle(container) {
  const particle = document.createElement("div")
  particle.className = "particle"

  // Случайное положение
  const posX = Math.random() * 100
  const posY = Math.random() * 100

  // Случайный размер
  const size = Math.random() * 3 + 1

  // Случайная прозрачность
  const opacity = Math.random() * 0.5 + 0.1

  // Случайная скорость
  const speedX = Math.random() * 1 - 0.5
  const speedY = Math.random() * 1 - 0.5

  // Применяем стили
  particle.style.cssText = `
    position: absolute;
    top: ${posY}%;
    left: ${posX}%;
    width: ${size}px;
    height: ${size}px;
    background-color: rgba(255, 255, 255, ${opacity});
    border-radius: 50%;
    pointer-events: none;
  `

  // Добавляем частицу в контейнер
  container.appendChild(particle)

  // Анимируем частицу
  animateParticle(particle, posX, posY, speedX, speedY)
}

// Функция для анимации частицы
function animateParticle(particle, posX, posY, speedX, speedY) {
  let x = posX
  let y = posY

  function update() {
    // Обновляем позицию
    x += speedX
    y += speedY

    // Проверяем границы
    if (x < 0 || x > 100) speedX *= -1
    if (y < 0 || y > 100) speedY *= -1

    // Применяем новую позицию
    particle.style.left = `${x}%`
    particle.style.top = `${y}%`

    // Продолжаем анимацию
    requestAnimationFrame(update)
  }

  update()
}

// Функция для проверки непрочитанных сообщений
async function checkUnreadMessages(userId) {
  // Не проверяем только на странице сообщений
  if (window.location.pathname.includes("messages.html")) {
    return
  }

  try {
    const response = await fetch("get-unread-messages-count.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
      }),
    })

    const data = await response.json()

    if (data.success) {
      updateNotificationBadges(data.count)
    }
  } catch (error) {
    console.error("Ошибка получения непрочитанных сообщений:", error)
  }
}

// Функция для обновления значков уведомлений
function updateNotificationBadges(count) {
  const userIcon = document.getElementById("user-icon")

  if (userIcon) {
    // Удаляем существующий значок, если есть
    const existingBadge = userIcon.querySelector(".notification-badge")
    if (existingBadge) {
      existingBadge.remove()
    }

    // Добавляем новый значок, если есть непрочитанные сообщения
    if (count > 0) {
      const badge = document.createElement("div")
      badge.className = "notification-badge"
      badge.textContent = count > 9 ? "9+" : count
      userIcon.appendChild(badge)
    }
  }
}

// Функция для анимации контента в секциях
function animateSectionContent(section) {
  if (section.classList.contains("hero")) {
    animateHeroContent(section)
  } else if (section.classList.contains("advantages")) {
    animateAdvantagesCards(section)
  } else if (section.classList.contains("fuel")) {
    animateFuelItems(section)
  } else if (section.classList.contains("cta")) {
    // CTA анимация уже реализована через CSS
  } else if (section.classList.contains("testimonials")) {
    // Testimonials анимация уже реализована через CSS
  } else if (section.classList.contains("contact-social")) {
    // Contact-social анимация уже реализована через CSS
  }
}

// Функция для анимации карточек в секции fuel
function animateFuelItems(fuelSection) {
  const items = fuelSection.querySelectorAll(".fuel-item")

  items.forEach((item, index) => {
    item.style.opacity = "0"
    item.style.transform = "translateY(30px)"

    setTimeout(
      () => {
        item.style.transition = "opacity 0.8s ease, transform 0.8s ease"
        item.style.opacity = "1"
        item.style.transform = "translateY(0)"
      },
      100 + index * 200,
    ) // Добавляем задержку для каждой следующей карточки
  })
}

// Обновляем IntersectionObserver для всех секций
document.addEventListener("DOMContentLoaded", () => {
  const elements = document.querySelectorAll(".hidden")

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Добавляем небольшую задержку для более плавного эффекта
          setTimeout(() => {
            entry.target.classList.add("visible")

            // Анимируем содержимое секции
            animateSectionContent(entry.target)
          }, 100)
        }
      })
    },
    {
      threshold: 0.15, // Немного увеличиваем порог для лучшего тайминга
      rootMargin: "0px 0px -50px 0px", // Срабатывает немного раньше, чем элемент полностью в поле зрения
    },
  )

  elements.forEach((element) => {
    observer.observe(element)
  })
})

// Функция для анимации контента в hero секции
function animateHeroContent(heroSection) {
  const heroText = heroSection.querySelector(".hero-text")
  const heroImage = heroSection.querySelector(".hero-image")

  if (heroText) {
    heroText.style.opacity = "0"
    heroText.style.transform = "translateX(-30px)"

    setTimeout(() => {
      heroText.style.transition = "opacity 0.8s ease, transform 0.8s ease"
      heroText.style.opacity = "1"
      heroText.style.transform = "translateX(0)"
    }, 100)
  }

  if (heroImage) {
    heroImage.style.opacity = "0"
    heroImage.style.transform = "translateX(30px)"

    setTimeout(() => {
      heroImage.style.transition = "opacity 0.8s ease, transform 0.8s ease"
      heroImage.style.opacity = "1"
      heroImage.style.transform = "translateX(0)"
    }, 500)
  }
}

// Функция для анимации карточек в секции advantages
function animateAdvantagesCards(advantagesSection) {
  const cards = advantagesSection.querySelectorAll(".advantage-card")

  cards.forEach((card, index) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(30px)"

    setTimeout(
      () => {
        card.style.transition = "opacity 0.8s ease, transform 0.8s ease"
        card.style.opacity = "1"
        card.style.transform = "translateY(0)"
      },
      100 + index * 200,
    ) // Добавляем задержку для каждой следующей карточки
  })
}

// Улучшенная обработка кликов по кнопкам "Подробнее"
document.addEventListener("DOMContentLoaded", () => {
  const toggleButtons = document.querySelectorAll(".toggle-details")
  let currentlyOpen = null
  let isAnimating = false

  toggleButtons.forEach((button) => {
    button.addEventListener("click", function () {
      if (isAnimating) return // Предотвращаем клики во время анимации

      const advantageCard = this.closest(".advantage-card")
      const details = advantageCard.querySelector(".details")
      const icon = this.querySelector("i")

      // Проверяем, открыт ли этот блок
      const isOpen = details.classList.contains("open")

      // Если открыт другой блок, сначала закрываем его
      if (currentlyOpen && currentlyOpen !== details) {
        isAnimating = true

        // Получаем иконку для текущего открытого блока
        const openIcon = currentlyOpen.closest(".advantage-card").querySelector(".toggle-details i")

        // Устанавливаем фиксированную высоту перед анимацией
        currentlyOpen.style.height = currentlyOpen.scrollHeight + "px"

        // Принудительный перерасчет
        currentlyOpen.offsetHeight

        // Анимируем высоту до 0
        currentlyOpen.style.height = "0"
        currentlyOpen.style.opacity = "0"
        currentlyOpen.style.transform = "translateY(-10px)"
        currentlyOpen.classList.remove("open")

        // Обновляем иконку
        openIcon.classList.remove("fa-chevron-up")
        openIcon.classList.add("fa-chevron-down")

        // После завершения анимации
        setTimeout(() => {
          // Теперь обрабатываем кликнутый блок
          if (!isOpen) {
            // Открываем этот блок
            details.classList.add("open")
            details.style.height = "0"
            details.style.opacity = "0"
            details.style.transform = "translateY(-10px)"

            // Принудительный перерасчет
            details.offsetHeight

            // Анимируем до полной высоты
            details.style.height = details.scrollHeight + "px"
            details.style.opacity = "1"
            details.style.transform = "translateY(0)"

            // Обновляем иконку
            icon.classList.remove("fa-chevron-down")
            icon.classList.add("fa-chevron-up")

            // Устанавливаем текущий открытый блок
            currentlyOpen = details

            // После завершения анимации устанавливаем высоту на auto
            setTimeout(() => {
              details.style.height = "auto"
              isAnimating = false
            }, 500)
          } else {
            isAnimating = false
          }
        }, 500)
      } else {
        // Если нет другого открытого блока или мы закрываем текущий блок
        isAnimating = true

        if (isOpen) {
          // Закрываем этот блок
          details.style.height = details.scrollHeight + "px"

          // Принудительный перерасчет
          details.offsetHeight

          // Анимируем высоту до 0
          details.style.height = "0"
          details.style.opacity = "0"
          details.style.transform = "translateY(-10px)"
          details.classList.remove("open")

          // Обновляем иконку
          icon.classList.remove("fa-chevron-up")
          icon.classList.add("fa-chevron-down")

          // Очищаем текущий открытый блок
          currentlyOpen = null

          setTimeout(() => {
            isAnimating = false
          }, 500)
        } else {
          // Открываем этот блок
          details.classList.add("open")
          details.style.height = "0"
          details.style.opacity = "0"
          details.style.transform = "translateY(-10px)"

          // Принудительный перерасчет
          details.offsetHeight

          // Анимируем до полной высоты
          details.style.height = details.scrollHeight + "px"
          details.style.opacity = "1"
          details.style.transform = "translateY(0)"

          // Обновляем иконку
          icon.classList.remove("fa-chevron-down")
          icon.classList.add("fa-chevron-up")

          // Устанавливаем текущий открытый блок
          currentlyOpen = details

          // После завершения анимации устанавливаем высоту на auto
          setTimeout(() => {
            details.style.height = "auto"
            isAnimating = false
          }, 500)
        }
      }
    })
  })
})

function updateUserIcon() {
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  const userIcon = document.getElementById("user-icon")

  if (authData.isAuthenticated) {
    userIcon.href = "profile.html"
    userIcon.innerHTML = '<i class="fas fa-user-check"></i>'
  } else {
    userIcon.href = "login.html"
    userIcon.innerHTML = '<i class="fas fa-user"></i>'
  }
}

window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    updateUserIcon()
  }
})

// Функция для загрузки данных о топливе из базы данных
function loadFuelsData() {
  const fuelSection = document.querySelector(".fuel-grid")
  if (!fuelSection) return

  fetch("get-fuels-json.php")
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok")
      }
      return response.json()
    })
    .then((fuels) => {
      // Очищаем текущее содержимое
      fuelSection.innerHTML = ""

      // Добавляем карточки топлива на основе данных из БД
      fuels.forEach((fuel) => {
        const fuelCard = createFuelCard(fuel)
        fuelSection.appendChild(fuelCard)
      })
    })
    .catch((error) => {
      console.error("Ошибка при загрузке данных о топливе:", error)
      fuelSection.innerHTML =
        '<p class="error-message">Не удалось загрузить данные о топливе. Пожалуйста, попробуйте позже.</p>'
    })
}

// Обновленная функция для создания карточки топлива
function createFuelCard(fuel) {
  const fuelItem = document.createElement("div")
  fuelItem.className = "fuel-item"

  // Добавляем бейдж скидки, если есть новая цена и она меньше старой
  if (fuel.newPrice && Number.parseFloat(fuel.pastPrice) > Number.parseFloat(fuel.newPrice)) {
    const discount = Math.round(
      ((Number.parseFloat(fuel.pastPrice) - Number.parseFloat(fuel.newPrice)) / Number.parseFloat(fuel.pastPrice)) *
        100,
    )
    const discountBadge = document.createElement("div")
    discountBadge.className = "discount-badge"
    discountBadge.textContent = `-${discount}%`
    fuelItem.appendChild(discountBadge)
  }

  // Добавляем изображение
  const img = document.createElement("img")
  img.src = fuel.photo_path || "images/empty.jpg"
  img.alt = fuel.name
  fuelItem.appendChild(img)

  // Добавляем название
  const title = document.createElement("h3")
  title.textContent = fuel.name
  fuelItem.appendChild(title)

  // Добавляем блок с рейтингом и качеством
  const qualityDiv = document.createElement("div")
  qualityDiv.className = "fuel-quality"

  const starsDiv = document.createElement("div")
  starsDiv.className = "quality-stars"

  // Добавляем звезды рейтинга
  const rating = Number.parseFloat(fuel.rating)
  const fullStars = Math.floor(rating)
  const halfStar = rating - fullStars >= 0.5

  for (let i = 1; i <= 5; i++) {
    const star = document.createElement("i")
    if (i <= fullStars) {
      star.className = "fas fa-star"
    } else if (i === fullStars + 1 && halfStar) {
      star.className = "fas fa-star-half-alt"
    } else {
      star.className = "far fa-star"
    }
    starsDiv.appendChild(star)
  }

  qualityDiv.appendChild(starsDiv)

  const qualityText = document.createElement("span")
  qualityText.className = "quality-text"
  qualityText.textContent = fuel.quality
  qualityDiv.appendChild(qualityText)

  fuelItem.appendChild(qualityDiv)

  // Добавляем преимущества
  const featuresDiv = document.createElement("div")
  featuresDiv.className = "fuel-features"

  try {
    const dignities = JSON.parse(fuel.dignities)
    if (Array.isArray(dignities)) {
      dignities.forEach((dignity) => {
        const span = document.createElement("span")
        span.textContent = dignity
        featuresDiv.appendChild(span)
      })
    }
  } catch (e) {
    console.error("Ошибка при разборе JSON преимуществ:", e)
  }

  fuelItem.appendChild(featuresDiv)

  // Добавляем описание
  const description = document.createElement("p")
  description.textContent = fuel.info
  fuelItem.appendChild(description)

  // Добавляем цену
  const priceDiv = document.createElement("div")
  priceDiv.className = "fuel-price"

  const priceInnerDiv = document.createElement("div")

  // Определяем актуальную цену
  let actualPrice
  if (fuel.newPrice && Number.parseFloat(fuel.pastPrice) > Number.parseFloat(fuel.newPrice)) {
    const oldPrice = document.createElement("span")
    oldPrice.className = "price-old"
    oldPrice.textContent = `${Number.parseFloat(fuel.pastPrice).toFixed(2).replace(".", ",")} ₽/л`
    priceInnerDiv.appendChild(oldPrice)

    const currentPrice = document.createElement("span")
    currentPrice.className = "price-current"
    currentPrice.textContent = `${Number.parseFloat(fuel.newPrice).toFixed(2).replace(".", ",")} ₽/л`
    priceInnerDiv.appendChild(currentPrice)

    actualPrice = Number.parseFloat(fuel.newPrice)
  } else {
    const currentPrice = document.createElement("span")
    currentPrice.className = "price-current"
    currentPrice.textContent = `${Number.parseFloat(fuel.pastPrice).toFixed(2).replace(".", ",")} ₽/л`
    priceInnerDiv.appendChild(currentPrice)

    actualPrice = Number.parseFloat(fuel.pastPrice)
  }

  priceDiv.appendChild(priceInnerDiv)
  fuelItem.appendChild(priceDiv)

  // Добавляем кнопку заказа с обработчиком события
  const orderButton = document.createElement("a")
  orderButton.href = "#"
  orderButton.className = "btn-main"
  orderButton.textContent = "Заказать"

  // Добавляем обработчик события для кнопки заказа
  orderButton.addEventListener("click", (event) => {
    event.preventDefault()
    // Открываем модальное окно и передаем данные о топливе
    openOrderModal(fuel.id, fuel.name, actualPrice)
  })

  fuelItem.appendChild(orderButton)

  return fuelItem
}

// Реализуем функцию openOrderModal для открытия модального окна
function openOrderModal(fuelId, fuelName, fuelPrice) {
  // Проверяем авторизацию пользователя
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")

  // Если пользователь не авторизован, показываем модальное окно с требованием авторизации
  if (!authData.isAuthenticated) {
    // Получаем элементы модального окна авторизации
    const authModal = document.getElementById("authRequiredModal")
    const closeBtn = authModal.querySelector(".close-modal")

    // Отображаем модальное окно
    authModal.style.display = "block"

    // Добавляем обработчики для закрытия модального окна
    closeBtn.onclick = () => {
      authModal.style.display = "none"
    }

    // Закрытие модального окна при клике вне его области
    window.onclick = (event) => {
      if (event.target == authModal) {
        authModal.style.display = "none"
      }
    }

    return // Прерываем выполнение функции
  }
  // Получаем элементы модального окна
  const modal = document.getElementById("orderModal")
  const closeBtn = document.querySelector(".close-modal")
  const cancelBtn = document.getElementById("cancelOrder")
  const form = document.getElementById("orderForm")
  const orderMessage = document.getElementById("orderMessage")

  // Очищаем предыдущие сообщения
  orderMessage.textContent = ""
  orderMessage.className = "order-message"

  // Заполняем поля формы
  document.getElementById("fuel_id").value = fuelId
  document.getElementById("fuel_name").value = fuelName
  document.getElementById("fuel_price").value = fuelPrice.toFixed(2).replace(".", ",") + " ₽/л"

  // Устанавливаем минимальную дату доставки (завтра)
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  const tomorrowFormatted = tomorrow.toISOString().split("T")[0]
  document.getElementById("delivery_date").min = tomorrowFormatted

  // Очищаем поля формы, которые должны быть заполнены пользователем
  document.getElementById("quantity").value = "100"
  document.getElementById("total_price").value = (100 * fuelPrice).toFixed(2).replace(".", ",") + " ₽"
  document.getElementById("delivery_date").value = tomorrowFormatted
  document.getElementById("delivery_time").value = ""
  document.getElementById("delivery_address").value = ""
  document.getElementById("comments").value = ""

  // Добавляем обработчик для расчета итоговой стоимости при изменении количества
  document.getElementById("quantity").addEventListener("input", function () {
    const quantity = Number.parseFloat(this.value) || 0
    const total = quantity * fuelPrice
    document.getElementById("total_price").value = total.toFixed(2).replace(".", ",") + " ₽"
  })

  // Отображаем модальное окно
  modal.style.display = "block"

  // Добавляем обработчики для закрытия модального окна
  closeBtn.onclick = () => {
    modal.style.display = "none"
  }

  cancelBtn.onclick = () => {
    modal.style.display = "none"
  }

  // Закрытие модального окна при клике вне его области
  window.onclick = (event) => {
    if (event.target == modal) {
      modal.style.display = "none"
    }
  }

  // Обработчик отправки формы
  form.onsubmit = (e) => {
    e.preventDefault()

    // Проверка заполнения обязательных полей
    const quantity = document.getElementById("quantity").value
    const deliveryDate = document.getElementById("delivery_date").value
    const deliveryTime = document.getElementById("delivery_time").value
    const deliveryAddress = document.getElementById("delivery_address").value

    if (!quantity || !deliveryDate || !deliveryTime || !deliveryAddress) {
      orderMessage.textContent = "Пожалуйста, заполните все обязательные поля"
      orderMessage.className = "order-message error"
      return
    }

    // Здесь можно добавить код для отправки данных на сервер
    // Например, с использованием fetch API

    // Временно: показываем сообщение об успешном оформлении заказа
    orderMessage.textContent = "Заказ успешно оформлен! Наш менеджер свяжется с вами в ближайшее время."
    orderMessage.className = "order-message success"

    // Закрываем модальное окно через 3 секунды
    setTimeout(() => {
      modal.style.display = "none"
      orderMessage.textContent = ""
      orderMessage.className = "order-message"
    }, 3000)
  }
}
