document.addEventListener("DOMContentLoaded", () => {
  // Проверяем авторизацию
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // Получаем элементы страницы
  const ordersList = document.getElementById("orders-list")
  const pagination = document.getElementById("pagination")
  const statusFilter = document.getElementById("status-filter")
  const dateFromFilter = document.getElementById("date-from")
  const dateToFilter = document.getElementById("date-to")
  const applyFiltersBtn = document.getElementById("apply-filters")
  const resetFiltersBtn = document.getElementById("reset-filters")
  const modal = document.getElementById("order-details-modal")
  const closeModal = document.querySelector(".close-modal")
  const orderDetailsContent = document.getElementById("order-details-content")
  const detailOrderId = document.getElementById("detail-order-id")
  const adminSearch = document.getElementById("admin-search")
  const searchInput = document.getElementById("search-input")
  const searchButton = document.getElementById("search-button")
  const ordersTitle = document.getElementById("orders-title")

  // Проверяем, является ли пользователь администратором
  const isAdmin = authData.user && authData.user.role === "admin"

  // Если пользователь - администратор, показываем поиск и меняем заголовок
  if (isAdmin) {
    adminSearch.style.display = "block"
    ordersTitle.textContent = "Все заказы"
  }

  // Текущие параметры пагинации и фильтрации
  let currentPage = 1
  const currentLimit = 5
  let currentFilters = {
    status: "",
    dateFrom: "",
    dateTo: "",
    search: "",
  }

  // Загружаем заказы при загрузке страницы
  loadOrders()

  // Обработчики событий для фильтров
  applyFiltersBtn.addEventListener("click", () => {
    currentFilters.status = statusFilter.value
    currentFilters.dateFrom = dateFromFilter.value
    currentFilters.dateTo = dateToFilter.value
    currentPage = 1 // Сбрасываем на первую страницу при применении фильтров
    loadOrders()
  })

  resetFiltersBtn.addEventListener("click", () => {
    statusFilter.value = ""
    dateFromFilter.value = ""
    dateToFilter.value = ""
    searchInput.value = ""
    currentFilters = {
      status: "",
      dateFrom: "",
      dateTo: "",
      search: "",
    }
    currentPage = 1
    loadOrders()
  })

  // Обработчик для поиска (только для администратора)
  if (searchButton) {
    searchButton.addEventListener("click", () => {
      currentFilters.search = searchInput.value.trim()
      currentPage = 1
      loadOrders()
    })
  }

  // Обработчик для поиска по нажатию Enter
  if (searchInput) {
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        currentFilters.search = searchInput.value.trim()
        currentPage = 1
        loadOrders()
      }
    })
  }

  // Обработчики для модального окна
  closeModal.addEventListener("click", () => {
    modal.style.display = "none"
  })

  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.style.display = "none"
    }
  })

  // Обработчик для кнопки администратора
  const adminUsersBtn = document.getElementById("adminUsersBtn")
  if (isAdmin && adminUsersBtn) {
    adminUsersBtn.style.display = "block"
    adminUsersBtn.addEventListener("click", () => {
      window.location.href = "admin-users.html"
    })
  }

  // Обработчик для кнопки выхода
  const logoutBtn = document.getElementById("logoutBtn")
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      sessionStorage.removeItem("auth")
      localStorage.removeItem("authEmail")
      window.location.href = "index.html"
    })
  }

  // Функция для загрузки заказов
  async function loadOrders() {
    try {
      // Показываем индикатор загрузки
      ordersList.innerHTML = `
        <div class="loading-indicator">
          <i class="fas fa-spinner fa-spin"></i>
          <span>Загрузка заказов...</span>
        </div>
      `

      // Очищаем пагинацию
      pagination.innerHTML = ""

      // Получаем данные пользователя
      const userId = authData.user.id

      // Формируем параметры запроса
      const requestData = {
        userId: userId,
        page: currentPage,
        limit: currentLimit,
        isAdmin: isAdmin,
        ...currentFilters,
      }

      // Отправляем запрос на сервер
      const response = await fetch("get-user-orders.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      // Проверяем статус ответа
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      // Парсим ответ
      const data = await response.json()

      if (data.success) {
        // Отображаем заказы
        displayOrders(data.orders)

        // Отображаем пагинацию
        if (data.pagination && data.pagination.totalPages > 1) {
          displayPagination(data.pagination)
        } else {
          pagination.innerHTML = ""
        }
      } else {
        throw new Error(data.error || "Неизвестная ошибка при загрузке заказов")
      }
    } catch (error) {
      console.error("Ошибка загрузки заказов:", error)
      ordersList.innerHTML = `
        <div class="error-message">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Не удалось загрузить заказы: ${error.message}</p>
          <button onclick="loadOrders()" class="retry-btn">
            <i class="fas fa-sync-alt"></i> Попробовать снова
          </button>
        </div>
      `
    }
  }

  // Функция для отображения заказов
  function displayOrders(orders) {
    if (!orders || orders.length === 0) {
      ordersList.innerHTML = `
        <div class="empty-orders">
          <i class="fas fa-inbox"></i>
          <p>Заказы не найдены</p>
          ${
            !isAdmin
              ? `<a href="index.html#fuel-section" class="btn-main">
                  <i class="fas fa-gas-pump"></i> Заказать топливо
                </a>`
              : ""
          }
        </div>
      `
      return
    }

    // Очищаем список заказов
    ordersList.innerHTML = ""

    // Добавляем каждый заказ в список
    orders.forEach((order) => {
      const orderElement = createOrderElement(order)
      ordersList.appendChild(orderElement)
    })
  }

  // Функция для создания элемента заказа
  function createOrderElement(order) {
    // Создаем элемент заказа
    const orderElement = document.createElement("div")
    orderElement.className = `order-card ${order.status === "PENDING" ? "new-order" : ""}`

    // Определяем, какое поле даты использовать
    const dateField =
      order["created_at"] || order["date_created"] || order["order_date"] || order["date"] || order["timestamp"]

    // Форматируем дату, если она существует
    let formattedDate = "Не указана"
    let formattedTime = ""
    if (dateField) {
      const orderDate = new Date(dateField)
      formattedDate = orderDate.toLocaleDateString("ru-RU")
      formattedTime = orderDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
    }

    // Форматируем цены
    const pricePerLiter = Number.parseFloat(order.price_per_liter || 0)
    const totalPrice = Number.parseFloat(order.total_price || 0)
    const quantity = Number.parseInt(order.quantity || 0)

    const formattedPrice = pricePerLiter.toFixed(2).replace(".", ",")
    const formattedTotal = totalPrice.toFixed(2).replace(".", ",")

    // Получаем информацию о статусе
    const statusInfo = getStatusInfo(order.status)

    // Дополнительная информация для администратора
    const adminInfo = isAdmin
      ? `
      <div class="order-detail">
        <span class="order-detail-label">Пользователь</span>
        <span class="order-detail-value">
          <i class="fas fa-user"></i> ID: ${order.user_id}
        </span>
      </div>
    `
      : ""

    // Заполняем содержимое элемента
    orderElement.innerHTML = `
      <div class="order-header">
        <h4><i class="fas fa-file-invoice"></i> Заказ <span class="order-id">#${order.id}</span></h4>
        <span class="order-status ${statusInfo.class}">
          <i class="${statusInfo.icon}"></i> ${statusInfo.text}
        </span>
      </div>
      
      <div class="order-content">
        ${adminInfo}
        
        <div class="order-detail">
          <span class="order-detail-label">Дата заказа</span>
          <span class="order-detail-value">
            <i class="fas fa-calendar-alt"></i> ${formattedDate}
            ${formattedTime ? `<small>${formattedTime}</small>` : ""}
          </span>
        </div>
        
        <div class="order-detail">
          <span class="order-detail-label">Топливо</span>
          <span class="order-detail-value">
            <i class="fas fa-gas-pump"></i> ${order.fuel_name || "Не указано"}
          </span>
        </div>
        
        <div class="order-detail">
          <span class="order-detail-label">Количество</span>
          <span class="order-detail-value">
            <i class="fas fa-tachometer-alt"></i> ${quantity} л
          </span>
        </div>
        
        <div class="order-detail">
          <span class="order-detail-label">Стоимость</span>
          <span class="order-detail-value">
            <i class="fas fa-ruble-sign"></i> ${formattedTotal} ₽
          </span>
        </div>
      </div>
      
      <div class="order-footer">
        <div class="order-delivery">
          <span class="order-detail-label">Доставка</span>
          <span class="order-detail-value">
            <i class="fas fa-truck"></i> ${order.delivery_date || "Не указана"}, 
            ${order.delivery_time || ""}
          </span>
        </div>
        
        <div class="order-actions">
          <button class="order-action-btn" onclick="showOrderDetails(${order.id})">
            <i class="fas fa-info-circle"></i> Подробнее
          </button>
          ${
            order.status === "PENDING" && (isAdmin || order.user_id == authData.user.id)
              ? `
  <button class="order-action-btn cancel" onclick="cancelOrder(${order.id})">
    <i class="fas fa-times"></i> Отменить
  </button>
  <button class="order-action-btn delete" onclick="deleteOrder(${order.id}, false, false)">
    <i class="fas fa-trash"></i> Удалить
  </button>
`
              : ""
          }
        </div>
      </div>
    `

    return orderElement
  }

  // Функция для отображения пагинации
  function displayPagination(paginationData) {
    const { page, totalPages } = paginationData

    // Очищаем пагинацию
    pagination.innerHTML = ""

    // Кнопка "Предыдущая"
    const prevBtn = document.createElement("button")
    prevBtn.className = `pagination-btn ${page <= 1 ? "disabled" : ""}`
    prevBtn.innerHTML = '<i class="fas fa-chevron-left"></i>'
    prevBtn.disabled = page <= 1
    prevBtn.addEventListener("click", () => {
      if (page > 1) {
        currentPage = page - 1
        loadOrders()
      }
    })
    pagination.appendChild(prevBtn)

    // Номера страниц
    const maxVisiblePages = 5
    let startPage = Math.max(1, page - Math.floor(maxVisiblePages / 2))
    const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1)

    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1)
    }

    for (let i = startPage; i <= endPage; i++) {
      const pageBtn = document.createElement("button")
      pageBtn.className = `pagination-btn ${i === page ? "active" : ""}`
      pageBtn.textContent = i
      pageBtn.addEventListener("click", () => {
        if (i !== page) {
          currentPage = i
          loadOrders()
        }
      })
      pagination.appendChild(pageBtn)
    }

    // Кнопка "Следующая"
    const nextBtn = document.createElement("button")
    nextBtn.className = `pagination-btn ${page >= totalPages ? "disabled" : ""}`
    nextBtn.innerHTML = '<i class="fas fa-chevron-right"></i>'
    nextBtn.disabled = page >= totalPages
    nextBtn.addEventListener("click", () => {
      if (page < totalPages) {
        currentPage = page + 1
        loadOrders()
      }
    })
    pagination.appendChild(nextBtn)
  }

  // Функция для получения информации о статусе заказа
  function getStatusInfo(status) {
    switch (status) {
      case "PENDING":
        return {
          class: "pending",
          text: "В обработке",
          icon: "fas fa-clock",
        }
      case "CONFIRMED":
        return {
          class: "confirmed",
          text: "Подтвержден",
          icon: "fas fa-check-circle",
        }
      case "DELIVERED":
        return {
          class: "delivered",
          text: "Доставлен",
          icon: "fas fa-truck-loading",
        }
      case "CANCELLED":
        return {
          class: "cancelled",
          text: "Отменен",
          icon: "fas fa-ban",
        }
      default:
        return {
          class: "pending",
          text: "В обработке",
          icon: "fas fa-clock",
        }
    }
  }

  // Функция для отображения деталей заказа
  window.showOrderDetails = async (orderId) => {
    try {
      // Показываем индикатор загрузки
      orderDetailsContent.innerHTML = `
        <div class="loading-indicator">
          <i class="fas fa-spinner fa-spin"></i>
          <span>Загрузка деталей заказа...</span>
        </div>
      `

      // Отображаем модальное окно
      modal.style.display = "block"
      detailOrderId.textContent = `#${orderId}`

      // Получаем детали заказа
      const response = await fetch("get-order-details.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          userId: authData.user.id,
          isAdmin: isAdmin,
        }),
      })

      // Проверяем статус ответа
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      // Парсим ответ
      const data = await response.json()

      if (data.success && data.order) {
        displayOrderDetails(data.order, data.userData)
      } else {
        throw new Error(data.error || "Не удалось загрузить детали заказа")
      }
    } catch (error) {
      console.error("Ошибка загрузки деталей заказа:", error)
      orderDetailsContent.innerHTML = `
        <div class="error-message">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Не удалось загрузить детали заказа: ${error.message}</p>
        </div>
      `
    }
  }

  // Функция для отображения деталей заказа
  function displayOrderDetails(order, userData) {
    // Определяем, какое поле даты использовать
    const dateField =
      order["created_at"] || order["date_created"] || order["order_date"] || order["date"] || order["timestamp"]

    // Форматируем дату, если она существует
    let formattedDate = "Не указана"
    let formattedTime = ""
    if (dateField) {
      const orderDate = new Date(dateField)
      formattedDate = orderDate.toLocaleDateString("ru-RU")
      formattedTime = orderDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
    }

    // Форматируем цены
    const pricePerLiter = Number.parseFloat(order.price_per_liter || 0)
    const totalPrice = Number.parseFloat(order.total_price || 0)
    const quantity = Number.parseInt(order.quantity || 0)

    const formattedPrice = pricePerLiter.toFixed(2).replace(".", ",")
    const formattedTotal = totalPrice.toFixed(2).replace(".", ",")

    // Получаем информацию о статусе
    const statusInfo = getStatusInfo(order.status)

    // Информация о пользователе (только для администратора)
    const userInfoSection =
      isAdmin && userData
        ? `
  <div class="user-info-section">
    <h3><i class="fas fa-user"></i> Информация о пользователе</h3>
    <div class="detail-grid">
      <div class="detail-item">
        <span class="detail-label">ID пользователя</span>
        <span class="detail-value user-id">${userData.id || order.user_id}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Имя</span>
        <span class="detail-value">${userData.firstName || "Не указано"} ${userData.lastName || ""}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Email</span>
        <span class="detail-value">${userData.email || "Не указано"}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Телефон</span>
        <span class="detail-value">${userData.phone || "Не указано"}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Адрес</span>
        <span class="detail-value">${userData.address || "Не указано"}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Роль</span>
        <span class="detail-value">${userData.role || "Пользователь"}</span>
      </div>
      <div class="detail-item">
        <span class="detail-label">Дата регистрации</span>
        <span class="detail-value">${userData.date_registration || "Не указана"}</span>
      </div>
    </div>
    <div class="user-profile-link">
      <a href="profile.html?userId=${userData.id || order.user_id}" class="detail-btn primary">
        <i class="fas fa-user-circle"></i> Перейти в профиль пользователя
      </a>
    </div>
  </div>
`
        : ""

    // Отображение причины отмены заказа, если она есть
    const reasonSection =
      order.reason && order.status === "CANCELLED"
        ? `
      <div class="order-detail-section reason-section">
        <h3><i class="fas fa-exclamation-circle"></i> Причина отмены</h3>
        <p class="reason-text">${order.reason}</p>
      </div>
      `
        : ""

    // Форма изменения статуса заказа (только для администратора)
    const adminControls = isAdmin
      ? `
  <div class="order-detail-section status-change-section">
    <h3><i class="fas fa-edit"></i> Изменить статус заказа</h3>
    <div class="status-form">
      <div class="form-group">
        <label for="status-select">Новый статус:</label>
        <select id="status-select" class="status-select">
          <option value="PENDING" ${order.status === "PENDING" ? "selected" : ""}>В обработке</option>
          <option value="CONFIRMED" ${order.status === "CONFIRMED" ? "selected" : ""}>Подтвержден</option>
          <option value="DELIVERED" ${order.status === "DELIVERED" ? "selected" : ""}>Доставлен</option>
          <option value="CANCELLED" ${order.status === "CANCELLED" ? "selected" : ""}>Отменен</option>
        </select>
      </div>
      
      <div class="form-group reason-group" style="display: ${order.status === "CANCELLED" ? "block" : "none"};">
        <label for="cancel-reason">Причина отмены:</label>
        <textarea id="cancel-reason" class="cancel-reason" placeholder="Укажите причину отмены заказа">${order.reason || ""}</textarea>
      </div>
      
      <button class="detail-btn primary" onclick="updateOrderStatus(${order.id})">
        <i class="fas fa-save"></i> Сохранить изменения
      </button>
    </div>
  </div>
  
  <div class="order-detail-section delete-section">
    <h3><i class="fas fa-trash-alt"></i> Удаление заказа</h3>
    <p class="warning-text">Внимание! Это действие полностью удалит заказ из базы данных и не может быть отменено.</p>
    <button class="detail-btn danger delete-btn" onclick="deleteOrder(${order.id}, true)">
      <i class="fas fa-trash-alt"></i> Удалить заказ
    </button>
  </div>
  `
      : ""

    // Заполняем содержимое модального окна
    orderDetailsContent.innerHTML = `
      ${userInfoSection}
      
      <div class="order-detail-section">
        <h3>Информация о заказе</h3>
        <div class="detail-grid">
          <div class="detail-item">
            <span class="detail-label">Номер заказа</span>
            <span class="detail-value"><i class="fas fa-hashtag"></i> ${order.id}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Дата заказа</span>
            <span class="detail-value">
              <i class="fas fa-calendar-alt"></i> ${formattedDate}
              ${formattedTime ? `<small>${formattedTime}</small>` : ""}
            </span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Статус</span>
            <span class="detail-value">
              <span class="order-status ${statusInfo.class}">
                <i class="${statusInfo.icon}"></i> ${statusInfo.text}
              </span>
            </span>
          </div>
        </div>
      </div>
      
      ${reasonSection}
      
      <div class="order-detail-section">
        <h3>Информация о топливе</h3>
        <div class="detail-grid">
          <div class="detail-item">
            <span class="detail-label">Тип топлива</span>
            <span class="detail-value"><i class="fas fa-gas-pump"></i> ${order.fuel_name || "Не указано"}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Количество</span>
            <span class="detail-value"><i class="fas fa-tachometer-alt"></i> ${quantity} л</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Цена за литр</span>
            <span class="detail-value"><i class="fas fa-tag"></i> ${formattedPrice} ₽/л</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Общая стоимость</span>
            <span class="detail-value"><i class="fas fa-ruble-sign"></i> ${formattedTotal} ₽</span>
          </div>
        </div>
      </div>
      
      <div class="order-detail-section">
        <h3>Информация о доставке</h3>
        <div class="detail-grid">
          <div class="detail-item">
            <span class="detail-label">Дата доставки</span>
            <span class="detail-value"><i class="fas fa-calendar-day"></i> ${order.delivery_date || "Не указана"}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Время доставки</span>
            <span class="detail-value"><i class="fas fa-clock"></i> ${order.delivery_time || "Не указано"}</span>
          </div>
          <div class="detail-item">
            <span class="detail-label">Адрес доставки</span>
            <span class="detail-value"><i class="fas fa-map-marker-alt"></i> ${order.delivery_address || "Не указан"}</span>
          </div>
        </div>
      </div>
      
      ${
        order.comments
          ? `
      <div class="order-detail-section">
        <h3>Комментарий к заказу</h3>
        <p>${order.comments}</p>
      </div>
      `
          : ""
      }
      
      ${adminControls}
      
      <div class="detail-actions">
        ${
          order.status === "PENDING" && (isAdmin || order.user_id == authData.user.id)
            ? `
    <button class="detail-btn danger" onclick="cancelOrder(${order.id}, true)">
      <i class="fas fa-times"></i> Отменить заказ
    </button>
    <button class="detail-btn danger" onclick="deleteOrder(${order.id}, true, false)">
      <i class="fas fa-trash"></i> Удалить заказ
    </button>
  `
            : ""
        }
        <button class="detail-btn secondary" onclick="document.getElementById('order-details-modal').style.display='none'">
          <i class="fas fa-times"></i> Закрыть
        </button>
      </div>
    `

    // Добавляем обработчик события для выбора статуса
    setTimeout(() => {
      const statusSelect = document.getElementById("status-select")
      const reasonGroup = document.querySelector(".reason-group")

      if (statusSelect && reasonGroup) {
        statusSelect.addEventListener("change", function () {
          if (this.value === "CANCELLED") {
            reasonGroup.style.display = "block"
          } else {
            reasonGroup.style.display = "none"
          }
        })
      }
    }, 100)
  }

  // Функция для отмены заказа
  window.cancelOrder = async (orderId, closeModalAfter = false) => {
    if (!confirm("Вы уверены, что хотите отменить заказ?")) {
      return
    }

    try {
      // Если администратор отменяет заказ, запрашиваем причину
      let reason = ""
      if (isAdmin) {
        reason = prompt("Укажите причину отмены заказа:", "")
      }

      const response = await fetch("cancel-order.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          userId: authData.user.id,
          isAdmin: isAdmin,
          reason: reason,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Заказ успешно отменен")

        // Если нужно закрыть модальное окно после отмены
        if (closeModalAfter) {
          modal.style.display = "none"
        }

        // Перезагружаем список заказов
        loadOrders()
      } else {
        alert("Ошибка при отмене заказа: " + data.error)
      }
    } catch (error) {
      console.error("Ошибка при отмене заказа:", error)
      alert("Произошла ошибка при отмене заказа")
    }
  }

  // Функция для обновления статуса заказа (только для администратора)
  window.updateOrderStatus = async (orderId) => {
    if (!isAdmin) return

    const statusSelect = document.getElementById("status-select")
    const cancelReason = document.getElementById("cancel-reason")

    if (!statusSelect) return

    const newStatus = statusSelect.value
    const reason = newStatus === "CANCELLED" && cancelReason ? cancelReason.value.trim() : ""

    if (newStatus === "CANCELLED" && !reason) {
      alert("Пожалуйста, укажите причину отмены заказа")
      return
    }

    try {
      const response = await fetch("update-order-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          status: newStatus,
          userId: authData.user.id,
          isAdmin: true,
          reason: reason,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Статус заказа успешно обновлен")
        modal.style.display = "none"
        loadOrders()
      } else {
        alert("Ошибка при обновлении статуса заказа: " + data.error)
      }
    } catch (error) {
      console.error("Ошибка при обновлении статуса заказа:", error)
      alert("Произошла ошибка при обновлении статуса заказа")
    }
  }

  // Функция для удаления заказа (для администратора и обычных пользователей)
  window.deleteOrder = async (orderId, closeModalAfter = false, isAdminDelete = true) => {
    // Если это не администратор и не указано, что это пользовательское удаление
    if (!isAdmin && isAdminDelete) return

    const confirmMessage = isAdmin
      ? "ВНИМАНИЕ! Вы собираетесь полностью удалить заказ из базы данных. Это действие нельзя отменить. Продолжить?"
      : "Вы уверены, что хотите удалить этот заказ? Это действие нельзя отменить."

    if (!confirm(confirmMessage)) {
      return
    }

    // Дополнительное подтверждение только для администратора
    if (isAdmin && !confirm("Пожалуйста, подтвердите удаление заказа еще раз.")) {
      return
    }

    try {
      const response = await fetch("delete-order.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          isAdmin: isAdmin,
          userId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Заказ успешно удален из базы данных")

        // Если нужно закрыть модальное окно после удаления
        if (closeModalAfter) {
          modal.style.display = "none"
        }

        // Перезагружаем список заказов
        loadOrders()
      } else {
        alert("Ошибка при удалении заказа: " + data.error)
      }
    } catch (error) {
      console.error("Ошибка при удалении заказа:", error)
      alert("Произошла ошибка при удалении заказа")
    }
  }
})
