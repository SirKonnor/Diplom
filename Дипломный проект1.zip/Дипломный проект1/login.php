<?php
header("Content-Type: application/json");
require_once 'config.php';
session_start();

// Получение данных из запроса
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$password = isset($_POST['password']) ? trim($_POST['password']) : '';

// Проверка наличия необходимых данных
if (empty($email) || empty($password)) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Заполните все поля',
        'error_code' => 'EMPTY_FIELDS'
    ]);
    exit;
}

try {
    // Проверяем, не находится ли email в черном списке
    $stmt = $pdo->prepare("SELECT * FROM blacklist WHERE email = ?");
    $stmt->execute([$email]);
    $blacklisted = $stmt->fetch();

    if ($blacklisted) {
        http_response_code(403);
        echo json_encode([
            'success' => false,
            'error' => 'Ваш аккаунт заблокирован. Причина: ' . $blacklisted['reason'],
            'error_code' => 'ACCOUNT_BLOCKED'
        ]);
        exit;
    }

    // Ищем пользователя по email
    $stmt = $pdo->prepare("SELECT * FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Пользователь с такой почтой не найден',
            'error_code' => 'EMAIL_NOT_FOUND'
        ]);
        exit;
    }

    // Проверяем пароль
    if (!password_verify($password, $user['password'])) {
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'error' => 'Неверный пароль',
            'error_code' => 'INVALID_PASSWORD'
        ]);
        exit;
    }

    // Сохраняем данные пользователя в сессии
    $_SESSION['user'] = [
        'id' => $user['id'],
        'email' => $user['email'],
        'firstName' => $user['firstName'],
        'lastName' => $user['lastName'],
        'role' => $user['role']
    ];

    // Возвращаем успешный ответ с данными пользователя
    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $user['id'],
            'email' => $user['email'],
            'firstName' => $user['firstName'],
            'lastName' => $user['lastName'],
            'middleName' => $user['middleName'],
            'phone' => $user['phone'],
            'address' => $user['address'],
            'date_registration' => $user['date_registration'],
            'role' => $user['role'],
            'avatar_path' => $user['avatar_path']
        ]
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных: ' . $e->getMessage(),
        'error_code' => 'DATABASE_ERROR'
    ]);
}
?>
