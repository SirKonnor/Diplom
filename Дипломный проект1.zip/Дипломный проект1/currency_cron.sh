#!/bin/bash
# Cron задача для обновления курсов валют каждые 5 минут
# Для Linux/Mac: добавить в crontab: */5 * * * * /path/to/currency_cron.sh

# Переходим в директорию проекта (измените путь на свой)
cd C:\Users\vlad5\OneDrive\Рабочий стол\Дипломный проект1

# Выполняем обновление курсов
php update_currency_rates.php >> cron_output.log 2>&1

# Логируем результат
echo "$(date): Currency cron job executed" >> cron_execution.log
