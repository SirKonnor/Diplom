<?php
header("Content-Type: application/json");
require_once 'config.php';

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['adminId'])) {
        throw new Exception("Admin ID is required");
    }
    
    $adminId = $input['adminId'];
    $isHelper = isset($input['isHelper']) ? $input['isHelper'] : false;
    
    // Запрос для получения диалогов с информацией о вложениях
    $sql = "
        SELECT DISTINCT
            u.id as user_id,
            CONCAT(u.firstName, ' ', u.lastName) as user_name,
            u.avatar_path,
            u.role as support_role,
            (
                SELECT m.text 
                FROM messages m 
                WHERE (m.sender_id = u.id AND m.receiver_id = ?) 
                   OR (m.sender_id = ? AND m.receiver_id = u.id)
                ORDER BY m.created_at DESC 
                LIMIT 1
            ) as last_message,
            (
                SELECT m.created_at 
                FROM messages m 
                WHERE (m.sender_id = u.id AND m.receiver_id = ?) 
                   OR (m.sender_id = ? AND m.receiver_id = u.id)
                ORDER BY m.created_at DESC 
                LIMIT 1
            ) as last_message_time,
            (
                SELECT COUNT(*) 
                FROM messages m 
                WHERE m.sender_id = u.id 
                  AND m.receiver_id = ? 
                  AND m.is_read = 0
            ) as unread_count,
            (
                SELECT COUNT(*) > 0
                FROM messages m 
                JOIN message_attachments ma ON m.id = ma.message_id
                WHERE (m.sender_id = u.id AND m.receiver_id = ?) 
                   OR (m.sender_id = ? AND m.receiver_id = u.id)
                ORDER BY m.created_at DESC 
                LIMIT 1
            ) as has_attachments,
            (
                SELECT COUNT(ma.id)
                FROM messages m 
                JOIN message_attachments ma ON m.id = ma.message_id
                WHERE m.id = (
                    SELECT m2.id 
                    FROM messages m2 
                    WHERE (m2.sender_id = u.id AND m2.receiver_id = ?) 
                       OR (m2.sender_id = ? AND m2.receiver_id = u.id)
                    ORDER BY m2.created_at DESC 
                    LIMIT 1
                )
            ) as attachment_count,
            (
                SELECT ma.file_name
                FROM messages m 
                JOIN message_attachments ma ON m.id = ma.message_id
                WHERE (m.sender_id = u.id AND m.receiver_id = ?) 
                   OR (m.sender_id = ? AND m.receiver_id = u.id)
                ORDER BY m.created_at DESC 
                LIMIT 1
            ) as last_attachment_name
        FROM user u
        WHERE u.id IN (
            SELECT DISTINCT 
                CASE 
                    WHEN sender_id = ? THEN receiver_id 
                    ELSE sender_id 
                END as contact_id
            FROM messages 
            WHERE sender_id = ? OR receiver_id = ?
        )
        AND u.id != ?
        ORDER BY last_message_time DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $adminId, $adminId, $adminId, $adminId, $adminId, 
        $adminId, $adminId, $adminId, $adminId, $adminId, 
        $adminId, $adminId, $adminId, $adminId, $adminId
    ]);
    
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Форматируем время для каждого диалога
    foreach ($conversations as &$conversation) {
        if ($conversation['last_message_time']) {
            $conversation['last_message_time'] = date('d.m.Y H:i', strtotime($conversation['last_message_time']));
        }
        
        // Преобразуем булевы значения
        $conversation['has_attachments'] = (bool)$conversation['has_attachments'];
        $conversation['attachment_count'] = (int)$conversation['attachment_count'];
    }
    
    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
