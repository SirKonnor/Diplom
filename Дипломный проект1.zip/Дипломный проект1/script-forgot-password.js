document.addEventListener("DOMContentLoaded", () => {
  const forgotPasswordForm = document.getElementById("forgotPasswordForm")
  const errorMessage = document.getElementById("errorMessage")
  const step1 = document.getElementById("step1")
  const step2 = document.getElementById("step2")
  const resendLink = document.getElementById("resendLink")
  let userEmail = ""

  forgotPasswordForm.addEventListener("submit", async (e) => {
    e.preventDefault()
    errorMessage.style.display = "none"

    userEmail = document.getElementById("email").value.trim()

    // Базовая валидация на клиенте
    if (!userEmail || !validateEmail(userEmail)) {
      showError("Пожалуйста, введите корректный адрес электронной почты")
      return
    }

    try {
      // Имитация отправки запроса на сервер
      // В реальном приложении здесь будет запрос к серверу
      await simulateServerRequest(userEmail)

      // Показываем второй шаг
      step1.style.display = "none"
      step2.style.display = "block"
    } catch (error) {
      showError(error.message || "Ошибка при отправке запроса")
      console.error("Ошибка:", error)
    }
  })

  resendLink.addEventListener("click", async (e) => {
    e.preventDefault()

    try {
      // Имитация повторной отправки запроса
      await simulateServerRequest(userEmail)

      // Показываем уведомление о повторной отправке
      showNotification("Ссылка для сброса пароля отправлена повторно")
    } catch (error) {
      showError(error.message || "Ошибка при повторной отправке")
      console.error("Ошибка:", error)
    }
  })

  function showError(message) {
    errorMessage.textContent = message
    errorMessage.style.display = "block"
    errorMessage.classList.remove("shake")
    void errorMessage.offsetWidth // Сброс анимации
    errorMessage.classList.add("shake")
  }

  function showNotification(message) {
    // Создаем элемент уведомления
    const notification = document.createElement("div")
    notification.className = "notification"
    notification.textContent = message
    document.body.appendChild(notification)

    // Показываем уведомление
    setTimeout(() => {
      notification.classList.add("show")
    }, 10)

    // Скрываем и удаляем уведомление через 3 секунды
    setTimeout(() => {
      notification.classList.remove("show")
      setTimeout(() => {
        document.body.removeChild(notification)
      }, 300)
    }, 3000)
  }

  function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(String(email).toLowerCase())
  }

  // Функция для имитации запроса к серверу
  // В реальном приложении здесь будет настоящий запрос
  function simulateServerRequest(email) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Проверяем, существует ли пользователь с таким email
        // В реальном приложении эта проверка будет на сервере
        if (email === "test@example.com") {
          reject({ message: "Пользователь с такой почтой не найден" })
        } else {
          resolve({ success: true })
        }
      }, 1000)
    })
  }

  // Добавляем стили для уведомления
  const style = document.createElement("style")
  style.textContent = `
    .notification {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%) translateY(-100px);
      background: linear-gradient(135deg, #4caf50, #45a049);
      color: white;
      padding: 15px 30px;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(76, 175, 80, 0.3);
      opacity: 0;
      transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
      z-index: 1000;
      font-weight: 500;
    }
    
    .notification.show {
      transform: translateX(-50%) translateY(0);
      opacity: 1;
    }
  `
  document.head.appendChild(style)
})
