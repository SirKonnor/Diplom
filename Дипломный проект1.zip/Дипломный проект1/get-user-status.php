<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Function for logging errors
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'user_status_errors.log');
}

function logActivity($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'user_status_activity.log');
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['userId'])) {
    logError("Missing required parameters");
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}

try {
    $userId = (int)$input['userId'];
    
    logActivity("Getting status for user $userId");
    
    // Get user status
    $stmt = $pdo->prepare("SELECT status, last_seen, session_id FROM user_status WHERE user_id = ?");
    $stmt->execute([$userId]);
    $userStatus = $stmt->fetch();
    
    if ($userStatus) {
        // Проверяем, не устарел ли статус
        $lastSeen = new DateTime($userStatus['last_seen']);
        $now = new DateTime();
        $diff = $now->diff($lastSeen);
        
        // Если последнее обновление было более 2 минут назад, считаем пользователя offline
        $totalSeconds = $diff->days * 24 * 3600 + $diff->h * 3600 + $diff->i * 60 + $diff->s;
        
        if ($userStatus['status'] === 'online' && $totalSeconds > 120) {
            // Обновляем статус на offline
            $stmt = $pdo->prepare("UPDATE user_status SET status = 'offline' WHERE user_id = ?");
            $stmt->execute([$userId]);
            
            $userStatus['status'] = 'offline';
            logActivity("User $userId status auto-updated to offline (stale)");
        }
        
        echo json_encode([
            'success' => true,
            'status' => $userStatus['status'],
            'lastSeen' => $userStatus['last_seen'],
            'sessionId' => $userStatus['session_id'] ?? null
        ]);
    } else {
        // No status found, default to offline
        echo json_encode([
            'success' => true,
            'status' => 'offline',
            'lastSeen' => null,
            'sessionId' => null
        ]);
    }
    
} catch (Exception $e) {
    logError("Error getting user status: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
