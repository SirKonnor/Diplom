<?php
// Конфигурация платежных систем

// ЮKassa (Яндекс.Касса)
define('YUKASSA_SHOP_ID', 'your_shop_id'); // Замените на ваш Shop ID
define('YUKASSA_SECRET_KEY', 'your_secret_key'); // Замените на ваш секретный ключ
define('YUKASSA_API_URL', 'https://api.yookassa.ru/v3/');

// Сбербанк Эквайринг
define('SBERBANK_USERNAME', 'your_username'); // Замените на ваш логин
define('SBERBANK_PASSWORD', 'your_password'); // Замените на ваш пароль
define('SBERBANK_API_URL', 'https://securepayments.sberbank.ru/payment/rest/');

// Тинькофф Эквайринг
define('TINKOFF_TERMINAL_KEY', 'your_terminal_key'); // Замените на ваш Terminal Key
define('TINKOFF_SECRET_KEY', 'your_secret_key'); // Замените на ваш секретный ключ
define('TINKOFF_API_URL', 'https://securepay.tinkoff.ru/v2/');

// CloudPayments
define('CLOUDPAYMENTS_PUBLIC_ID', 'your_public_id'); // Замените на ваш Public ID
define('CLOUDPAYMENTS_API_SECRET', 'your_api_secret'); // Замените на ваш API Secret
define('CLOUDPAYMENTS_API_URL', 'https://api.cloudpayments.ru/');

// Robokassa
define('ROBOKASSA_MERCHANT_LOGIN', 'your_merchant_login'); // Замените на ваш логин
define('ROBOKASSA_PASSWORD_1', 'your_password_1'); // Замените на пароль #1
define('ROBOKASSA_PASSWORD_2', 'your_password_2'); // Замените на пароль #2
define('ROBOKASSA_API_URL', 'https://auth.robokassa.ru/Merchant/Index.aspx');

// Общие настройки
define('PAYMENT_SUCCESS_URL', 'http://your-domain.com/payment-success.php');
define('PAYMENT_FAIL_URL', 'http://your-domain.com/payment-fail.php');
define('PAYMENT_NOTIFICATION_URL', 'http://your-domain.com/payment-notification.php');

// Валюта (RUB для рублей)
define('PAYMENT_CURRENCY', 'RUB');

// Включенные платежные системы
$enabled_payment_systems = [
    'yukassa' => [
        'name' => 'ЮKassa',
        'description' => 'Банковские карты, электронные кошельки',
        'icon' => 'fas fa-credit-card',
        'enabled' => true
    ],
    'sberbank' => [
        'name' => 'Сбербанк',
        'description' => 'Сбербанк Онлайн, банковские карты',
        'icon' => 'fas fa-university',
        'enabled' => true
    ],
    'tinkoff' => [
        'name' => 'Тинькофф',
        'description' => 'Тинькофф банк, банковские карты',
        'icon' => 'fas fa-credit-card',
        'enabled' => true
    ],
    'cloudpayments' => [
        'name' => 'CloudPayments',
        'description' => 'Банковские карты, Apple Pay, Google Pay',
        'icon' => 'fas fa-cloud',
        'enabled' => false
    ],
    'robokassa' => [
        'name' => 'Robokassa',
        'description' => 'Множество способов оплаты',
        'icon' => 'fas fa-robot',
        'enabled' => false
    ]
];
?>
