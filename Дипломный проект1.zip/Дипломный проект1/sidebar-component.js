/**
 * Creates a consistent sidebar navigation based on user role
 * @param {string} currentPage - The current page identifier ('profile', 'messages', 'orders', 'users', 'edit-profile', 'settings', 'statistics')
 */
function renderSidebar(currentPage) {
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  const isAdmin = authData.user?.role === "admin"
  
  const sidebarContainer = document.querySelector(".sidebar")

  if (!sidebarContainer) return

  // Clear existing content
  sidebarContainer.innerHTML = ""

  // Profile button - always visible for all users
  const profileBtn = document.createElement("button")
  profileBtn.className = `sidebar-btn ${currentPage === "profile" ? "active" : ""}`
  profileBtn.title = "Профиль"
  profileBtn.innerHTML = '<i class="fas fa-user"></i>'
  profileBtn.onclick = () => (window.location.href = "profile.html")
  sidebarContainer.appendChild(profileBtn)

  // Orders button - visible for all users
  const ordersBtn = document.createElement("button")
  ordersBtn.className = `sidebar-btn ${currentPage === "orders" ? "active" : ""}`
  ordersBtn.title = "Заказы"
  ordersBtn.innerHTML = '<i class="fas fa-shopping-bag"></i>'
  ordersBtn.onclick = () => (window.location.href = "orders.html")
  sidebarContainer.appendChild(ordersBtn)

  // Messages button - visible for all users
  const messagesBtn = document.createElement("button")
  messagesBtn.className = `sidebar-btn ${currentPage === "messages" ? "active" : ""}`
  messagesBtn.title = "Сообщения"
  messagesBtn.innerHTML = '<i class="fas fa-envelope"></i>'
  messagesBtn.onclick = () => (window.location.href = "messages.html")
  sidebarContainer.appendChild(messagesBtn)

  // All users button - visible for admins
  if (isAdmin) {
    const usersBtn = document.createElement("button")
    usersBtn.className = `sidebar-btn ${currentPage === "users" ? "active" : ""}`
    usersBtn.title = "Пользователи"
    usersBtn.id = "adminUsersBtn"
    usersBtn.innerHTML = '<i class="fas fa-users"></i>'
    usersBtn.onclick = () => (window.location.href = "admin-users.html")
    sidebarContainer.appendChild(usersBtn)
    
    // Statistics button - visible for all admins, but access is checked on the statistics page
    const statsBtn = document.createElement("button")
    statsBtn.className = `sidebar-btn ${currentPage === "statistics" ? "active" : ""}`
    statsBtn.title = "Статистика"
    statsBtn.id = "statsBtn"
    statsBtn.innerHTML = '<i class="fas fa-chart-bar"></i>'
    statsBtn.onclick = () => (window.location.href = "statistics.html")
    sidebarContainer.appendChild(statsBtn)
  }

  // Bottom section with settings and logout
  const bottomSection = document.createElement("div")
  bottomSection.className = "sidebar-bottom"

  // Settings button - visible for all users
  const settingsBtn = document.createElement("button")
  settingsBtn.className = `sidebar-btn ${currentPage === "settings" ? "active" : ""}`
  settingsBtn.title = "Настройки"
  settingsBtn.innerHTML = '<i class="fas fa-cog"></i>'
  settingsBtn.onclick = () => (window.location.href = "settings.html")
  bottomSection.appendChild(settingsBtn)

  // Logout button - visible for all users
  const logoutBtn = document.createElement("button")
  logoutBtn.id = "logoutBtn"
  logoutBtn.className = "sidebar-btn"
  logoutBtn.title = "Выход"
  logoutBtn.innerHTML = '<i class="fas fa-sign-out-alt"></i>'
  logoutBtn.onclick = () => {
    // Отправляем запрос на сервер для уничтожения сессии
    fetch('logout.php', {
      method: 'POST',
      credentials: 'include' // Важно для работы с сессиями
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        // Очищаем данные авторизации в sessionStorage
        sessionStorage.removeItem("auth")
        localStorage.removeItem("authEmail")
        // Перенаправляем на страницу входа
        window.location.href = "index.html"
      } else {
        console.error('Ошибка при выходе из системы:', data.error);
      }
    })
    .catch(error => {
      console.error('Ошибка при отправке запроса:', error);
      // В случае ошибки все равно очищаем данные и перенаправляем
      sessionStorage.removeItem("auth")
      localStorage.removeItem("authEmail")
      window.location.href = "index.html"
    });
  }
  bottomSection.appendChild(logoutBtn)

  sidebarContainer.appendChild(bottomSection)

  // Add notification badges if needed
  updateNotificationBadges()
}

/**
 * Updates notification badges on sidebar buttons
 */
function updateNotificationBadges() {
  // This function would be implemented to show notification badges
  // on messages or other buttons as needed
  // You can integrate this with your existing notification system
}

// Initialize sidebar when the DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  // Determine current page based on URL
  const currentUrl = window.location.pathname
  let currentPage = "profile"

  if (currentUrl.includes("messages.html")) {
    currentPage = "messages"
  } else if (currentUrl.includes("orders.html")) {
    currentPage = "orders"
  } else if (currentUrl.includes("admin-users.html")) {
    currentPage = "users"
  } else if (currentUrl.includes("edit-profile.html")) {
    currentPage = "edit-profile"
  } else if (currentUrl.includes("settings.html")) {
    currentPage = "settings"
  } else if (currentUrl.includes("statistics.html")) {
    currentPage = "statistics"
  }

  renderSidebar(currentPage)
})