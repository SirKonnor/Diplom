<?php
header("Content-Type: application/json");
require_once 'config.php';

try {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['userId'])) {
        throw new Exception("User ID is required");
    }
    
    $userId = $input['userId'];
    
    // Получаем все диалоги пользователя с админами и помощниками с информацией о вложениях
    $query = "SELECT 
              u.id as user_id,
              CONCAT(u.firstName, ' ', u.lastName) as user_name,
              u.role as support_role,
              u.avatar_path,
              (SELECT text FROM messages 
               WHERE ((sender_id = :userId AND receiver_id = u.id)
               OR (receiver_id = :userId AND sender_id = u.id))
               ORDER BY created_at DESC LIMIT 1) as last_message,
              (SELECT created_at FROM messages 
               WHERE ((sender_id = :userId AND receiver_id = u.id)
               OR (receiver_id = :userId AND sender_id = u.id))
               ORDER BY created_at DESC LIMIT 1) as last_message_time,
              COUNT(CASE WHEN m.is_read = 0 AND m.receiver_id = :userId THEN 1 END) as unread_count,
              (
                SELECT COUNT(*) > 0
                FROM messages m2 
                JOIN message_attachments ma ON m2.id = ma.message_id
                WHERE m2.id = (
                    SELECT m3.id 
                    FROM messages m3 
                    WHERE ((m3.sender_id = :userId AND m3.receiver_id = u.id)
                    OR (m3.receiver_id = :userId AND m3.sender_id = u.id))
                    ORDER BY m3.created_at DESC 
                    LIMIT 1
                )
              ) as has_attachments,
              (
                SELECT COUNT(ma.id)
                FROM messages m2 
                JOIN message_attachments ma ON m2.id = ma.message_id
                WHERE m2.id = (
                    SELECT m3.id 
                    FROM messages m3 
                    WHERE ((m3.sender_id = :userId AND m3.receiver_id = u.id)
                    OR (m3.receiver_id = :userId AND m3.sender_id = u.id))
                    ORDER BY m3.created_at DESC 
                    LIMIT 1
                )
              ) as attachment_count,
              (
                SELECT ma.file_name
                FROM messages m2 
                JOIN message_attachments ma ON m2.id = ma.message_id
                WHERE ((m2.sender_id = :userId AND m2.receiver_id = u.id)
                OR (m2.receiver_id = :userId AND m2.sender_id = u.id))
                ORDER BY m2.created_at DESC 
                LIMIT 1
              ) as last_attachment_name
              FROM user u
              LEFT JOIN messages m ON (m.sender_id = u.id AND m.receiver_id = :userId) 
                                   OR (m.receiver_id = u.id AND m.sender_id = :userId)
              WHERE u.role IN ('admin', 'helper')
              AND EXISTS (
                SELECT 1 FROM messages 
                WHERE (sender_id = :userId AND receiver_id = u.id)
                OR (receiver_id = :userId AND sender_id = u.id)
              )
              GROUP BY u.id";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':userId' => $userId]);
    
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Форматируем время для каждого диалога
    foreach ($conversations as &$conversation) {
        if ($conversation['last_message_time']) {
            $conversation['last_message_time'] = date('d.m.Y H:i', strtotime($conversation['last_message_time']));
        }
        
        // Преобразуем булевы значения
        $conversation['has_attachments'] = (bool)$conversation['has_attachments'];
        $conversation['attachment_count'] = (int)$conversation['attachment_count'];
    }
    
    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
