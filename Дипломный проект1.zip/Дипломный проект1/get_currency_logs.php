<?php
// Скрипт для получения логов обновления курсов
header('Content-Type: text/plain; charset=utf-8');

$logFile = 'currency_update.log';

if (file_exists($logFile)) {
    // Читаем последние 100 строк лога
    $lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $lastLines = array_slice($lines, -100);
    
    // Выводим в обратном порядке (новые сверху)
    echo implode("\n", array_reverse($lastLines));
} else {
    echo "Файл логов не найден";
}
?>
