<?php
header('Content-Type: application/json');

// Разрешаем CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Получаем данные из запроса
$data = json_decode(file_get_contents('php://input'), true);

// Проверяем наличие необходимых данных
if (!isset($data['userId']) || !isset($data['adminId']) || !isset($data['token'])) {
    echo json_encode(['success' => false, 'error' => 'Неверные параметры запроса']);
    exit;
}

// Подключение к базе данных
require_once 'db_connect.php';

try {
    // Проверяем права администратора
    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ? AND status = 'active'");
    $stmt->execute([$data['adminId']]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin || ($admin['role'] !== 'admin' && $admin['role'] !== 'owner')) {
        echo json_encode(['success' => false, 'error' => 'Недостаточно прав']);
        exit;
    }
    
    // Получаем email пользователя
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->execute([$data['userId']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'error' => 'Пользователь не найден']);
        exit;
    }
    
    // Удаляем пользователя из черного списка, если он там есть
    $stmt = $pdo->prepare("DELETE FROM blacklist WHERE email = ?");
    $stmt->execute([$user['email']]);
    
    // Удаляем пользователя
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$data['userId']]);
    
    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Ошибка базы данных: ' . $e->getMessage()]);
}
?>
