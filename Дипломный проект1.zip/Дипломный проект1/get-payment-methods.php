<?php
header('Content-Type: application/json');

require_once 'payment-config.php';

// Возвращаем список доступных платежных систем
echo json_encode([
    'success' => true,
    'methods' => $enabled_payment_systems
]);
?>
