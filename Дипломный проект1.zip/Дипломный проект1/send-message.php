<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Function for logging errors
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'attachment_errors.log');
}

// Check if it's a form submission with files
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sender_id'], $_POST['receiver_id'], $_POST['text'])) {
    $sender_id = $_POST['sender_id'];
    $receiver_id = $_POST['receiver_id'];
    $text = $_POST['text'];
    $isAdmin = isset($_POST['isAdmin']) ? $_POST['isAdmin'] : false;
    $isHelper = isset($_POST['isHelper']) ? $_POST['isHelper'] : false;
    
    // Handle file uploads
    $hasFiles = isset($_FILES['attachments']) && !empty($_FILES['attachments']['name'][0]);
} else {
    // Handle JSON request
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['sender_id'], $input['receiver_id'], $input['text'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid input']);
        exit;
    }
    
    $sender_id = $input['sender_id'];
    $receiver_id = $input['receiver_id'];
    $text = $input['text'];
    $isAdmin = isset($input['isAdmin']) ? $input['isAdmin'] : false;
    $isHelper = isset($input['isHelper']) ? $input['isHelper'] : false;
    $hasFiles = false;
}

try {
    // If receiver is 'support', find helper or admin ID
    if ($receiver_id === 'support') {
        // For regular users, messages go to helper
        $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'helper' LIMIT 1");
        $stmt->execute();
        $helper = $stmt->fetch();
        
        if ($helper) {
            $receiver_id = $helper['id'];
        } else {
            // If no helper, find admin
            $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'admin' LIMIT 1");
            $stmt->execute();
            $admin = $stmt->fetch();
            $receiver_id = $admin ? $admin['id'] : null;
        }
    }

    if (!$receiver_id) {
        throw new Exception("Support staff not found");
    }

    // Start transaction
    $pdo->beginTransaction();
    
    // Insert message
    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, text, is_read) VALUES (?, ?, ?, 0)");
    $stmt->execute([$sender_id, $receiver_id, $text]);
    $messageId = $pdo->lastInsertId();
    
    // Handle file attachments if present
    $attachments = [];
    if ($hasFiles) {
        $uploadDir = 'uploads/';
        
        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        // Process each file
        $fileCount = count($_FILES['attachments']['name']);
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($_FILES['attachments']['error'][$i] === UPLOAD_ERR_OK) {
                $fileName = $_FILES['attachments']['name'][$i];
                $fileType = $_FILES['attachments']['type'][$i];
                $fileSize = $_FILES['attachments']['size'][$i];
                $fileTmpName = $_FILES['attachments']['tmp_name'][$i];
                
                // Generate unique filename
                $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
                $uniqueName = uniqid() . '.' . $fileExt;
                $filePath = $uploadDir . $uniqueName;
                
                // Move uploaded file
                if (move_uploaded_file($fileTmpName, $filePath)) {
                    // Insert file info into database
                    $fileStmt = $pdo->prepare("
                        INSERT INTO message_attachments 
                        (message_id, file_name, file_path, file_type, file_size) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $fileStmt->execute([$messageId, $fileName, $filePath, $fileType, $fileSize]);
                    
                    $attachments[] = [
                        'id' => $pdo->lastInsertId(),
                        'file_name' => $fileName,
                        'file_path' => $filePath,
                        'file_type' => $fileType,
                        'file_size' => $fileSize
                    ];
                }
            }
        }
    }
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message_id' => $messageId,
        'attachments' => $attachments
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logError("Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>