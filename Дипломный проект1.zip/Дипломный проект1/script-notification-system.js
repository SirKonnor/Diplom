/**
 * Система уведомлений для сайта
 * Обрабатывает уведомления о заказах и сообщениях
 */

// Глобальный объект для хранения состояния уведомлений
window.notificationSystem = {
  // Счетчики уведомлений
  counters: {
    orders: 0,
    messages: 0,
    total: 0,
  },

  // Инициализация системы уведомлений
  init: function () {
    console.log("Инициализация системы уведомлений")
    this.loadNotificationState()
    this.updateBadges()
    
    // Запускаем периодическую проверку непрочитанных сообщений
    this.startMessageChecking()
  },

  // Загрузка состояния уведомлений из sessionStorage
  loadNotificationState: function () {
    const newOrder = sessionStorage.getItem("newOrder") === "true"
    if (newOrder) {
      this.counters.orders = 1
    }

    // Если есть сохраненное количество непрочитанных сообщений
    const unreadMessages = sessionStorage.getItem("unreadMessages")
    if (unreadMessages) {
      this.counters.messages = Number.parseInt(unreadMessages, 10) || 0
    }

    this.counters.total = this.counters.orders + this.counters.messages
  },

  // Обновление значков уведомлений
  updateBadges: function () {
    // Обновляем общий счетчик
    this.counters.total = this.counters.orders + this.counters.messages

    // Получаем иконку пользователя
    const userIcon = document.getElementById("user-icon")
    if (!userIcon) return

    // Удаляем существующий значок, если есть
    const existingBadge = userIcon.querySelector(".notification-badge")
    if (existingBadge) {
      existingBadge.remove()
    }

    // Если есть уведомления, добавляем значок
    if (this.counters.total > 0) {
      const badge = document.createElement("div")
      badge.className = "notification-badge"
      badge.textContent = this.counters.total
      userIcon.appendChild(badge)
    }
  },

  // Добавление уведомления о заказе
  addOrderNotification: function () {
    this.counters.orders = 1
    sessionStorage.setItem("newOrder", "true")
    this.updateBadges()
  },

  // Сброс уведомления о заказе
  clearOrderNotification: function () {
    this.counters.orders = 0
    sessionStorage.removeItem("newOrder")
    this.updateBadges()
  },

  // Обновление количества непрочитанных сообщений
  updateMessageCount: function (count) {
    this.counters.messages = count
    sessionStorage.setItem("unreadMessages", count.toString())
    this.updateBadges()
  },

  // Получение количества непрочитанных сообщений с сервера
  fetchUnreadMessagesCount: async function () {
    try {
      // Проверяем авторизацию
      const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
      if (!authData.isAuthenticated || !authData.user || !authData.user.id) {
        console.log("Пользователь не авторизован, пропускаем запрос непрочитанных сообщений")
        return 0
      }

      const response = await fetch("get-unread-messages-count.php", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "Cache-Control": "no-cache, no-store, must-revalidate",
          "Pragma": "no-cache",
          "Expires": "0"
        },
        credentials: "include" // Важно для работы с сессиями
      })

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        this.updateMessageCount(data.count)
        return data.count
      } else {
        console.error("Ошибка при получении количества непрочитанных сообщений:", data.error)
        return 0
      }
    } catch (error) {
      console.error("Ошибка при запросе количества непрочитанных сообщений:", error)
      return 0
    }
  },
  
  // Запуск периодической проверки непрочитанных сообщений
  startMessageChecking: function() {
    // Проверяем авторизацию
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    if (!authData.isAuthenticated || !authData.user || !authData.user.id) {
      console.log("Пользователь не авторизован, периодическая проверка не запущена")
      return
    }
    
    // Сначала выполняем проверку сразу
    this.fetchUnreadMessagesCount()
    
    // Затем устанавливаем интервал
    setInterval(() => {
      this.fetchUnreadMessagesCount()
    }, 60000) // Проверяем каждую минуту
  }
}

// Инициализация системы уведомлений при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
  window.notificationSystem.init()
})

// Глобальная функция для обновления значков уведомлений
// Оставляем для обратной совместимости
window.updateNotificationBadges = (count) => {
  if (typeof count === "number") {
    window.notificationSystem.updateMessageCount(count)
  } else {
    window.notificationSystem.updateBadges()
  }
}