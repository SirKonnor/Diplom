<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'profile_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));
logError("POST data: " . file_get_contents('php://input'));

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку с кодом 200 вместо 401
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'debug' => [
            'session' => $_SESSION
        ]
    ]);
    exit;
}

// Получаем ВСЕ данные пользователя перед обновлением
$stmt = $pdo->prepare("SELECT * FROM user WHERE id = ?");
$stmt->execute([$userId]);
$current_user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$current_user) {
    logError("User not found. User ID: " . $userId);
    echo json_encode([
        'success' => false,
        'error' => 'Пользователь не найден'
    ]);
    exit;
}

// Получаем входящие данные
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    logError("Invalid input data");
    echo json_encode([
        'success' => false, 
        'error' => 'Некорректные входные данные'
    ]);
    exit;
}

try {
    // Обработка аватара
    $avatar_path = $current_user['avatar_path'];
    
    if (!empty($input['avatar']) && strpos($input['avatar'], 'data:image') === 0) {
        $upload_dir = 'uploads/avatars/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $image_data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $input['avatar']));
        $file_name = 'avatar_' . $userId . '_' . time() . '.png';
        $file_path = $upload_dir . $file_name;
        
        if (file_put_contents($file_path, $image_data)) {
            if ($current_user['avatar_path'] && !str_contains($current_user['avatar_path'], 'default-avatar')) {
                @unlink($current_user['avatar_path']);
            }
            $avatar_path = $file_path;
        }
    }

    // Подготовка SQL-запроса с новыми полями
    $sql = "UPDATE user SET 
    phone = :phone,
    address = :address,
    avatar_path = :avatar,
    whatsapp_user = :whatsapp,
    vk_user = :vk,
    telegram_user = :telegram";
    
    // Добавляем email только если он был передан и отличается от текущего
    if (isset($input['email']) && !empty($input['email']) && $input['email'] !== $current_user['email']) {
        $sql .= ", email = :email";
    }
    
    // Добавляем middleName только если он был передан
    if (isset($input['middleName'])) {
        $sql .= ", middleName = :middleName";
    }
    
    // Добавляем пароль только если он был передан
    if (!empty($input['password'])) {
        $hashed_password = password_hash($input['password'], PASSWORD_BCRYPT);
        $sql .= ", password = :password";
    }
    
    $sql .= " WHERE id = :id";
    
    $stmt = $pdo->prepare($sql);
    $params = [
        ':phone' => $input['phone'] ?? $current_user['phone'],
        ':address' => $input['address'] ?? $current_user['address'],
        ':avatar' => $avatar_path,
        ':whatsapp' => $input['whatsapp'] ?? $current_user['whatsapp_user'],
        ':vk' => $input['vk'] ?? $current_user['vk_user'],
        ':telegram' => $input['telegram'] ?? $current_user['telegram_user'],
        ':id' => $userId
    ];
    
    // Добавляем email в параметры только если он был добавлен в SQL
    if (isset($input['email']) && !empty($input['email']) && $input['email'] !== $current_user['email']) {
        $params[':email'] = $input['email'];
    }
    
    // Добавляем middleName в параметры только если он был добавлен в SQL
    if (isset($input['middleName'])) {
        $params[':middleName'] = $input['middleName'];
    }
    
    // Добавляем пароль в параметры только если он был добавлен в SQL
    if (!empty($input['password'])) {
        $params[':password'] = $hashed_password;
    }
    
    logError("SQL: " . $sql);
    logError("Params: " . json_encode($params));
    
    if (!$stmt->execute($params)) {
        throw new Exception("Failed to update user data");
    }
    
    // Получаем обновлённые данные пользователя
    $stmt = $pdo->prepare("SELECT * FROM user WHERE id = ?");
    $stmt->execute([$userId]);
    $updatedUser = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$updatedUser) {
        throw new Exception("Failed to retrieve updated user data");
    }
    
    logError("User updated successfully. User ID: " . $userId);
    
    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $updatedUser['id'],
            'firstName' => $updatedUser['firstName'],
            'lastName' => $updatedUser['lastName'],
            'middleName' => $updatedUser['middleName'],
            'email' => $updatedUser['email'],
            'phone' => $updatedUser['phone'],
            'address' => $updatedUser['address'],
            'role' => $updatedUser['role'],
            'date_registration' => $updatedUser['date_registration'],
            'avatar_path' => $updatedUser['avatar_path'],
            'whatsapp_user' => $updatedUser['whatsapp_user'],
            'vk_user' => $updatedUser['vk_user'],
            'telegram_user' => $updatedUser['telegram_user']
        ]
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>