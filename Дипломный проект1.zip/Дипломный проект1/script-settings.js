document.addEventListener("DOMContentLoaded", () => {
  // Функция для получения ID текущего пользователя
  function getUserId() {
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    return authData.user?.id || "guest"
  }

  // Функция для сохранения настройки пользователя
  function saveUserSetting(key, value) {
    const userId = getUserId()

    // Получаем текущие настройки пользователя
    const userSettings = JSON.parse(localStorage.getItem(`user_settings_${userId}`) || "{}")

    // Обновляем настройку
    userSettings[key] = value

    // Сохраняем обновленные настройки
    localStorage.setItem(`user_settings_${userId}`, JSON.stringify(userSettings))
  }

  // Функция для получения настройки пользователя
  function getUserSetting(key, defaultValue) {
    const userId = getUserId()

    // Получаем настройки пользователя
    const userSettings = JSON.parse(localStorage.getItem(`user_settings_${userId}`) || "{}")

    // Возвращаем настройку или значение по умолчанию
    return userSettings[key] !== undefined ? userSettings[key] : defaultValue
  }

  // Получаем данные пользователя
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  const isAdmin = authData.user?.role === "admin"

  // Показываем вкладку администрирования только для админов
  if (isAdmin) {
    document.querySelectorAll(".admin-only").forEach((el) => {
      el.style.display = "block"
    })
  }

  // Переключение вкладок
  const tabBtns = document.querySelectorAll(".tab-btn")
  const tabContents = document.querySelectorAll(".tab-content")

  tabBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const tabId = btn.getAttribute("data-tab")

      // Если вкладка только для админа и пользователь не админ, не переключаем
      if (btn.classList.contains("admin-only") && !isAdmin) {
        return
      }

      // Убираем активный класс со всех кнопок и контента
      tabBtns.forEach((b) => b.classList.remove("active"))
      tabContents.forEach((c) => c.classList.remove("active"))

      // Добавляем активный класс выбранной кнопке и контенту
      btn.classList.add("active")
      document.getElementById(tabId).classList.add("active")
    })
  })

  // Выбор темы
  const themeOptions = document.querySelectorAll(".theme-option")

  themeOptions.forEach((option) => {
    option.addEventListener("click", () => {
      themeOptions.forEach((o) => o.classList.remove("active"))
      option.classList.add("active")

      const theme = option.getAttribute("data-theme")
      setTheme(theme)
    })
  })

  // Функция для установки темы
  function setTheme(theme) {
    // Получаем ID пользователя
    const userId = getUserId()

    // Здесь будет логика установки темы
    console.log(`Установлена тема: ${theme} для пользователя ${userId}`)

    // Сохраняем выбор в localStorage с привязкой к пользователю
    saveUserSetting("theme", theme)

    // Применяем тему
    if (theme === "dark") {
      document.body.classList.add("dark-theme")
      document.body.classList.remove("light-theme")
    } else if (theme === "light") {
      document.body.classList.add("light-theme")
      document.body.classList.remove("dark-theme")
    } else if (theme === "auto") {
      // Определяем системную тему
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches
      if (prefersDark) {
        document.body.classList.add("dark-theme")
        document.body.classList.remove("light-theme")
      } else {
        document.body.classList.add("light-theme")
        document.body.classList.remove("dark-theme")
      }
    }
  }

  // Загружаем сохраненную тему при загрузке страницы
  const savedTheme = getUserSetting("theme", "light")
  themeOptions.forEach((option) => {
    if (option.getAttribute("data-theme") === savedTheme) {
      option.classList.add("active")
    } else {
      option.classList.remove("active")
    }
  })
  setTheme(savedTheme)

  // Выбор цветовой схемы
  const colorOptions = document.querySelectorAll(".color-option")

  colorOptions.forEach((option) => {
    option.addEventListener("click", () => {
      colorOptions.forEach((o) => o.classList.remove("active"))
      option.classList.add("active")

      const color = option.getAttribute("data-color")
      setColorScheme(color)
    })
  })

  // Функция для установки цветовой схемы
  function setColorScheme(color) {
    // Здесь будет логика установки цветовой схемы
    console.log(`Установлена цветовая схема: ${color}`)

    // Сохраняем выбор в localStorage с привязкой к пользователю
    saveUserSetting("colorScheme", color)

    // Применяем цветовую схему
    let accentColor
    switch (color) {
      case "blue":
        accentColor = "#1a73e8"
        break
      case "green":
        accentColor = "#0f9d58"
        break
      case "orange":
        accentColor = "#f4511e"
        break
      case "purple":
        accentColor = "#9c27b0"
        break
      default:
        accentColor = "#1a73e8"
    }

    document.documentElement.style.setProperty("--accent-color", accentColor)
  }

  // Загружаем сохраненную цветовую схему при загрузке страницы
  const savedColorScheme = getUserSetting("colorScheme", "blue")
  colorOptions.forEach((option) => {
    if (option.getAttribute("data-color") === savedColorScheme) {
      option.classList.add("active")
    } else {
      option.classList.remove("active")
    }
  })
  setColorScheme(savedColorScheme)

  // Выбор размера шрифта
  const fontSizeBtns = document.querySelectorAll(".font-size-btn")

  fontSizeBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      fontSizeBtns.forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")

      const size = btn.getAttribute("data-size")
      setFontSize(size)
    })
  })

  // Функция для установки размера шрифта
  function setFontSize(size) {
    // Здесь будет логика установки размера шрифта
    console.log(`Установлен размер шрифта: ${size}`)

    // Сохраняем выбор в localStorage с привязкой к пользователю
    saveUserSetting("fontSize", size)

    // Применяем размер шрифта
    let fontSizePercent
    switch (size) {
      case "small":
        fontSizePercent = "90%"
        break
      case "medium":
        fontSizePercent = "100%"
        break
      case "large":
        fontSizePercent = "110%"
        break
      default:
        fontSizePercent = "100%"
    }

    document.documentElement.style.fontSize = fontSizePercent
  }

  // Загружаем сохраненный размер шрифта при загрузке страницы
  const savedFontSize = getUserSetting("fontSize", "medium")
  fontSizeBtns.forEach((btn) => {
    if (btn.getAttribute("data-size") === savedFontSize) {
      btn.classList.add("active")
    } else {
      btn.classList.remove("active")
    }
  })
  setFontSize(savedFontSize)

  // Выбор языка
  const languageOptions = document.querySelectorAll(".language-option")

  languageOptions.forEach((option) => {
    option.addEventListener("click", () => {
      languageOptions.forEach((o) => o.classList.remove("active"))
      option.classList.add("active")

      const lang = option.getAttribute("data-lang")
      setLanguage(lang)
    })
  })

  // Функция для установки языка
  function setLanguage(lang) {
    // Здесь будет логика установки языка
    console.log(`Установлен язык: ${lang}`)

    // Сохраняем выбор в localStorage с привязкой к пользователю
    saveUserSetting("language", lang)
  }

  // Загружаем сохраненный язык при загрузке страницы
  const savedLanguage = getUserSetting("language", "ru")
  languageOptions.forEach((option) => {
    if (option.getAttribute("data-lang") === savedLanguage) {
      option.classList.add("active")
    } else {
      option.classList.remove("active")
    }
  })

  // Выбор формата даты
  const formatOptions = document.querySelectorAll(".format-option")

  formatOptions.forEach((option) => {
    option.addEventListener("click", () => {
      formatOptions.forEach((o) => o.classList.remove("active"))
      option.classList.add("active")

      const format = option.getAttribute("data-format")
      setDateFormat(format)
    })
  })

  // Функция для установки формата даты
  function setDateFormat(format) {
    // Здесь будет логика установки формата даты
    console.log(`Установлен формат даты: ${format}`)

    // Сохраняем выбор в localStorage с привязкой к пользователю
    saveUserSetting("dateFormat", format)
  }

  // Загружаем сохраненный формат даты при загрузке страницы
  const savedDateFormat = getUserSetting("dateFormat", "dd.mm.yyyy")
  formatOptions.forEach((option) => {
    if (option.getAttribute("data-format") === savedDateFormat) {
      option.classList.add("active")
    } else {
      option.classList.remove("active")
    }
  })

  // Обработчики для переключателей
  const toggleSwitches = document.querySelectorAll('.toggle-switch input[type="checkbox"]')

  toggleSwitches.forEach((toggle) => {
    toggle.addEventListener("change", () => {
      const settingId = toggle.id
      const isEnabled = toggle.checked

      // Сохраняем состояние переключателя с привязкой к пользователю
      saveUserSetting(settingId, isEnabled)

      console.log(`Настройка ${settingId} ${isEnabled ? "включена" : "выключена"}`)
    })
  })

  // Загружаем сохраненные состояния переключателей
  toggleSwitches.forEach((toggle) => {
    const settingId = toggle.id
    const savedState = getUserSetting(settingId, null)

    if (savedState !== null) {
      toggle.checked = savedState
    }
  })

  // Обработчики для селекторов
  const settingsSelects = document.querySelectorAll(".settings-select")

  settingsSelects.forEach((select) => {
    select.addEventListener("change", () => {
      const settingId = select.id
      const value = select.value

      // Сохраняем выбранное значение с привязкой к пользователю
      saveUserSetting(settingId, value)

      console.log(`Настройка ${settingId} установлена на ${value}`)
    })
  })

  // Загружаем сохраненные значения селекторов
  settingsSelects.forEach((select) => {
    const settingId = select.id
    const savedValue = getUserSetting(settingId, null)

    if (savedValue !== null) {
      select.value = savedValue
    }
  })

  // Обработчик для кнопки сохранения настроек
  const saveSettingsBtn = document.getElementById("save-settings")

  saveSettingsBtn.addEventListener("click", () => {
    // Здесь можно добавить логику для отправки настроек на сервер

    // Показываем уведомление об успешном сохранении
    showNotification("Настройки успешно сохранены", "success")
  })

  // Обработчик для кнопки сброса настроек
  const resetSettingsBtn = document.getElementById("reset-settings")

  resetSettingsBtn.addEventListener("click", () => {
    if (confirm("Вы уверены, что хотите сбросить все настройки до значений по умолчанию?")) {
      // Сбрасываем все настройки
      resetAllSettings()

      // Показываем уведомление о сбросе настроек
      showNotification("Настройки сброшены до значений по умолчанию", "info")
    }
  })

  // Функция для сброса всех настроек
  function resetAllSettings() {
    const userId = getUserId()

    // Удаляем все настройки пользователя
    localStorage.removeItem(`user_settings_${userId}`)

    // Сбрасываем тему
    themeOptions.forEach((option) => {
      option.classList.remove("active")
      if (option.getAttribute("data-theme") === "light") {
        option.classList.add("active")
      }
    })
    setTheme("light")

    // Сбрасываем цветовую схему
    colorOptions.forEach((option) => {
      option.classList.remove("active")
      if (option.getAttribute("data-color") === "blue") {
        option.classList.add("active")
      }
    })
    setColorScheme("blue")

    // Сбрасываем размер шрифта
    fontSizeBtns.forEach((btn) => {
      btn.classList.remove("active")
      if (btn.getAttribute("data-size") === "medium") {
        btn.classList.add("active")
      }
    })
    setFontSize("medium")

    // Сбрасываем язык
    languageOptions.forEach((option) => {
      option.classList.remove("active")
      if (option.getAttribute("data-lang") === "ru") {
        option.classList.add("active")
      }
    })

    // Сбрасываем формат даты
    formatOptions.forEach((option) => {
      option.classList.remove("active")
      if (option.getAttribute("data-format") === "dd.mm.yyyy") {
        option.classList.add("active")
      }
    })

    // Сбрасываем переключатели
    toggleSwitches.forEach((toggle) => {
      const defaultState =
        toggle.id === "order-notifications" ||
        toggle.id === "message-notifications" ||
        toggle.id === "email-notifications" ||
        toggle.id === "data-collection"

      toggle.checked = defaultState
    })

    // Сбрасываем селекторы
    settingsSelects.forEach((select) => {
      // Устанавливаем значения по умолчанию
      if (select.id === "log-type") {
        select.value = "all"
      }
    })
  }

  // Функция для показа уведомлений
  function showNotification(message, type = "success") {
    // Создаем элемент уведомления
    const notification = document.createElement("div")
    notification.className = `notification ${type}`

    // Добавляем иконку в зависимости от типа уведомления
    let icon
    switch (type) {
      case "success":
        icon = "fa-check-circle"
        break
      case "error":
        icon = "fa-exclamation-circle"
        break
      case "info":
        icon = "fa-info-circle"
        break
      default:
        icon = "fa-bell"
    }

    notification.innerHTML = `
            <i class="fas ${icon}"></i>
            <span>${message}</span>
            <button class="close-notification"><i class="fas fa-times"></i></button>
        `

    // Добавляем уведомление на страницу
    document.body.appendChild(notification)

    // Добавляем обработчик для закрытия уведомления
    const closeBtn = notification.querySelector(".close-notification")
    closeBtn.addEventListener("click", () => {
      notification.classList.add("closing")
      setTimeout(() => {
        notification.remove()
      }, 300)
    })

    // Автоматически скрываем уведомление через 5 секунд
    setTimeout(() => {
      notification.classList.add("closing")
      setTimeout(() => {
        notification.remove()
      }, 300)
    }, 5000)

    // Добавляем стили для уведомлений, если их еще нет
    if (!document.getElementById("notification-styles")) {
      const style = document.createElement("style")
      style.id = "notification-styles"
      style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 15px 20px;
                    border-radius: 5px;
                    background-color: #fff;
                    box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
                    display: flex;
                    align-items: center;
                    z-index: 1000;
                    animation: slideIn 0.3s ease-out forwards;
                }
                
                .notification.closing {
                    animation: slideOut 0.3s ease-out forwards;
                }
                
                .notification.success {
                    border-left: 4px solid #4CAF50;
                }
                
                .notification.error {
                    border-left: 4px solid #F44336;
                }
                
                .notification.info {
                    border-left: 4px solid #2196F3;
                }
                
                .notification i {
                    margin-right: 10px;
                    font-size: 18px;
                }
                
                .notification.success i {
                    color: #4CAF50;
                }
                
                .notification.error i {
                    color: #F44336;
                }
                
                .notification.info i {
                    color: #2196F3;
                }
                
                .notification span {
                    flex: 1;
                }
                
                .close-notification {
                    background: none;
                    border: none;
                    color: #aaa;
                    cursor: pointer;
                    margin-left: 10px;
                }
                
                .close-notification:hover {
                    color: #333;
                }
                
                @keyframes slideIn {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                @keyframes slideOut {
                    from {
                        transform: translateX(0);
                        opacity: 1;
                    }
                    to {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                }
            `
      document.head.appendChild(style)
    }
  }

  // Обработчики для модальных окон
  const modals = document.querySelectorAll(".modal")
  const closeModalBtns = document.querySelectorAll(".close-modal")

  // Закрытие модальных окон при клике на крестик
  closeModalBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const modal = btn.closest(".modal")
      modal.style.display = "none"
    })
  })

  // Закрытие модальных окон при клике вне содержимого
  window.addEventListener("click", (event) => {
    modals.forEach((modal) => {
      if (event.target === modal) {
        modal.style.display = "none"
      }
    })
  })

  // Обработчики для редактирования шаблонов email
  const templateBtns = document.querySelectorAll("[data-template]")
  const templateEditorModal = document.getElementById("template-editor-modal")
  const templateName = document.getElementById("template-name")
  const templateContent = document.getElementById("template-content")
  const templatePreview = document.getElementById("template-preview-content")
  const saveTemplateBtn = document.getElementById("save-template")
  const resetTemplateBtn = document.getElementById("reset-template")

  // Шаблоны по умолчанию
  const defaultTemplates = {
    "order-confirmation": `<h2>Подтверждение заказа #{order_id}</h2>
<p>Здравствуйте, {user_name}!</p>
<p>Ваш заказ #{order_id} от {order_date} успешно подтвержден.</p>
<p>Сумма заказа: {order_total} руб.</p>
<p>Спасибо за ваш заказ!</p>
<p>С уважением,<br>Команда Дизель Сити</p>`,

    "user-registration": `<h2>Добро пожаловать в Дизель Сити!</h2>
<p>Здравствуйте, {user_name}!</p>
<p>Ваша регистрация на сайте {site_url} успешно завершена.</p>
<p>Теперь вы можете войти в личный кабинет и оформить заказ на топливо.</p>
<p>С уважением,<br>Команда Дизель Сити</p>`,

    "password-reset": `<h2>Восстановление пароля</h2>
<p>Здравствуйте, {user_name}!</p>
<p>Вы запросили восстановление пароля на сайте {site_url}.</p>
<p>Для создания нового пароля перейдите по ссылке ниже:</p>
<p><a href="{reset_link}">Восстановить пароль</a></p>
<p>Если вы не запрашивали восстановление пароля, проигнорируйте это письмо.</p>
<p>С уважением,<br>Команда Дизель Сити</p>`,
  }

  // Открытие модального окна редактирования шаблона
  templateBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const templateId = btn.getAttribute("data-template")
      const templateTitle = btn.closest(".template-item").querySelector("h4").textContent

      // Устанавливаем название шаблона
      templateName.textContent = templateTitle

      // Загружаем содержимое шаблона
      const savedTemplate = getUserSetting(`template_${templateId}`, null)
      const template = savedTemplate || defaultTemplates[templateId]

      templateContent.value = template
      templatePreview.innerHTML = template

      // Сохраняем ID текущего шаблона
      templateContent.setAttribute("data-template-id", templateId)

      // Открываем модальное окно
      templateEditorModal.style.display = "block"
    })
  })

  // Обновление предпросмотра при вводе текста
  templateContent.addEventListener("input", () => {
    templatePreview.innerHTML = templateContent.value
  })

  // Сохранение шаблона
  saveTemplateBtn.addEventListener("click", () => {
    const templateId = templateContent.getAttribute("data-template-id")
    const template = templateContent.value

    // Сохраняем шаблон в localStorage с привязкой к пользователю
    saveUserSetting(`template_${templateId}`, template)

    // Закрываем модальное окно
    templateEditorModal.style.display = "none"

    // Показываем уведомление
    showNotification("Шаблон успешно сохранен", "success")
  })

  // Сброс шаблона к стандартному
  resetTemplateBtn.addEventListener("click", () => {
    if (confirm("Вы уверены, что хотите сбросить шаблон до стандартного?")) {
      const templateId = templateContent.getAttribute("data-template-id")

      // Удаляем сохраненный шаблон
      const userId = getUserId()
      const userSettings = JSON.parse(localStorage.getItem(`user_settings_${userId}`) || "{}")
      delete userSettings[`template_${templateId}`]
      localStorage.setItem(`user_settings_${userId}`, JSON.stringify(userSettings))

      // Устанавливаем стандартный шаблон
      templateContent.value = defaultTemplates[templateId]
      templatePreview.innerHTML = defaultTemplates[templateId]

      // Показываем уведомление
      showNotification("Шаблон сброшен до стандартного", "info")
    }
  })

  // Обработчики для кнопок редактора шаблонов
  const editorBtns = document.querySelectorAll(".editor-btn")

  editorBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const action = btn.getAttribute("data-action")

      // Получаем выделенный текст
      const start = templateContent.selectionStart
      const end = templateContent.selectionEnd
      const selectedText = templateContent.value.substring(start, end)

      // Применяем действие к выделенному тексту
      let replacement = ""
      switch (action) {
        case "bold":
          replacement = `<strong>${selectedText}</strong>`
          break
        case "italic":
          replacement = `<em>${selectedText}</em>`
          break
        case "underline":
          replacement = `<u>${selectedText}</u>`
          break
        case "link":
          const url = prompt("Введите URL:", "https://")
          if (url) {
            replacement = `<a href="${url}">${selectedText || url}</a>`
          } else {
            return
          }
          break
        case "image":
          const imageUrl = prompt("Введите URL изображения:", "https://")
          if (imageUrl) {
            replacement = `<img src="${imageUrl}" alt="${selectedText || "Изображение"}" style="max-width: 100%;">`
          } else {
            return
          }
          break
      }

      // Заменяем выделенный текст
      if (replacement) {
        templateContent.value =
          templateContent.value.substring(0, start) + replacement + templateContent.value.substring(end)
        templatePreview.innerHTML = templateContent.value

        // Устанавливаем фокус обратно на текстовое поле
        templateContent.focus()
        templateContent.selectionStart = start + replacement.length
        templateContent.selectionEnd = start + replacement.length
      }
    })
  })

  // Обработчик для выбора переменной
  const variableSelect = document.querySelector('[data-action="variable"]')

  variableSelect.addEventListener("change", () => {
    const variable = variableSelect.value

    if (variable) {
      // Получаем позицию курсора
      const start = templateContent.selectionStart

      // Вставляем переменную
      templateContent.value =
        templateContent.value.substring(0, start) + variable + templateContent.value.substring(start)
      templatePreview.innerHTML = templateContent.value

      // Устанавливаем фокус обратно на текстовое поле
      templateContent.focus()
      templateContent.selectionStart = start + variable.length
      templateContent.selectionEnd = start + variable.length

      // Сбрасываем селект
      variableSelect.value = ""
    }
  })

  // Обработчики для резервного копирования
  const createBackupBtn = document.getElementById("create-backup")
  const restoreBackupBtn = document.getElementById("restore-backup")
  const backupRestoreModal = document.getElementById("backup-restore-modal")
  const restoreBtns = document.querySelectorAll(".restore-btn")
  const uploadBackupBtn = document.getElementById("upload-backup")

  // Создание резервной копии
  createBackupBtn.addEventListener("click", () => {
    // Здесь будет логика создания резервной копии

    // Показываем уведомление
    showNotification("Резервная копия успешно создана", "success")
  })

  // Открытие модального окна восстановления
  restoreBackupBtn.addEventListener("click", () => {
    backupRestoreModal.style.display = "block"
  })

  // Восстановление из резервной копии
  restoreBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      const backupId = btn.getAttribute("data-backup")

      if (
        confirm(
          "Вы уверены, что хотите восстановить данные из этой резервной копии? Все текущие данные будут заменены.",
        )
      ) {
        // Здесь будет логика восстановления из резервной копии

        // Закрываем модальное окно
        backupRestoreModal.style.display = "none"

        // Показываем уведомление
        showNotification("Данные успешно восстановлены из резервной копии", "success")
      }
    })
  })

  // Загрузка резервной копии
  uploadBackupBtn.addEventListener("click", () => {
    const backupFile = document.getElementById("backup-file").files[0]

    if (backupFile) {
      // Здесь будет логика загрузки резервной копии

      // Закрываем модальное окно
      backupRestoreModal.style.display = "none"

      // Показываем уведомление
      showNotification("Резервная копия успешно загружена", "success")
    } else {
      showNotification("Выберите файл резервной копии", "error")
    }
  })

  // Обработчики для удаления аккаунта
  const deleteAccountBtn = document.getElementById("delete-account")
  const deleteAccountModal = document.getElementById("delete-account-modal")
  const deleteConfirmation = document.getElementById("delete-confirmation")
  const confirmDeleteBtn = document.getElementById("confirm-delete")

  // Открытие модального окна удаления аккаунта
  deleteAccountBtn.addEventListener("click", () => {
    deleteAccountModal.style.display = "block"
    deleteConfirmation.value = ""
    confirmDeleteBtn.disabled = true
  })

  // Проверка подтверждения удаления
  deleteConfirmation.addEventListener("input", () => {
    confirmDeleteBtn.disabled = deleteConfirmation.value !== "УДАЛИТЬ"
  })

  // Подтверждение удаления аккаунта
  confirmDeleteBtn.addEventListener("click", () => {
    if (deleteConfirmation.value === "УДАЛИТЬ") {
      // Здесь будет логика удаления аккаунта

      // Закрываем модальное окно
      deleteAccountModal.style.display = "none"

      // Выходим из аккаунта
      sessionStorage.removeItem("auth")

      // Перенаправляем на главную страницу
      window.location.href = "index.html"
    }
  })

  // Обработчики для системных логов
  const filterLogsBtn = document.getElementById("filter-logs")
  const logTypeSelect = document.getElementById("log-type")
  const logDateInput = document.getElementById("log-date")
  const logEntries = document.querySelectorAll(".log-entry")
  const downloadLogsBtn = document.getElementById("download-logs")
  const clearLogsBtn = document.getElementById("clear-logs")

  // Фильтрация логов
  filterLogsBtn.addEventListener("click", () => {
    const logType = logTypeSelect.value
    const logDate = logDateInput.value

    logEntries.forEach((entry) => {
      let show = true

      // Фильтрация по типу
      if (logType !== "all" && !entry.classList.contains(logType)) {
        show = false
      }

      // Фильтрация по дате
      if (logDate) {
        const entryDate = entry.querySelector(".log-time").textContent.split(" ")[0]
        const formattedEntryDate = formatDateForComparison(entryDate)

        if (formattedEntryDate !== logDate) {
          show = false
        }
      }

      entry.style.display = show ? "flex" : "none"
    })
  })

  // Функция для форматирования даты для сравнения
  function formatDateForComparison(dateStr) {
    // Преобразуем дату из формата DD.MM.YYYY в YYYY-MM-DD
    const parts = dateStr.split(".")
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1]}-${parts[0]}`
    }
    return dateStr
  }

  // Скачивание логов
  downloadLogsBtn.addEventListener("click", () => {
    // Здесь будет логика скачивания логов

    // Показываем уведомление
    showNotification("Логи успешно скачаны", "success")
  })

  // Очистка логов
  clearLogsBtn.addEventListener("click", () => {
    if (confirm("Вы уверены, что хотите очистить все логи?")) {
      // Здесь будет логика очистки логов

      // Показываем уведомление
      showNotification("Логи успешно очищены", "success")
    }
  })

  // Обработчики для скачивания данных пользователя
  const downloadDataBtn = document.getElementById("download-data")

  downloadDataBtn.addEventListener("click", () => {
    // Здесь будет логика скачивания данных пользователя

    // Показываем уведомление
    showNotification("Ваши данные подготовлены к скачиванию", "success")
  })
})
