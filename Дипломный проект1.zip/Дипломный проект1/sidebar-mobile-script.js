/**
 * Полный скрипт для управления мобильным сайдбаром и меню
 */
document.addEventListener("DOMContentLoaded", () => {
  // Получаем все необходимые элементы
  const mobileMenuToggle = document.getElementById("mobileMenuToggle")
  const menu = document.getElementById("menu")
  const mobileSidebarToggle = document.getElementById("mobileSidebarToggle")
  const sidebar = document.getElementById("sidebar")
  const sidebarOverlay = document.getElementById("sidebarOverlay")
  const body = document.body

  // Функции для проверки размера экрана
  function isMobile() {
    return window.innerWidth <= 768
  }

  function isTablet() {
    return window.innerWidth <= 992 && window.innerWidth > 768
  }

  function isDesktop() {
    return window.innerWidth > 1024
  }

  // Функция для управления состоянием кнопки сайдбара
  function updateSidebarToggleState() {
    if (!mobileSidebarToggle) return

    const isMenuOpen = menu && menu.classList.contains("active")
    const isSidebarOpen = sidebar && sidebar.classList.contains("active")

    // Управление классами для анимации
    mobileSidebarToggle.classList.toggle("menu-open", isMenuOpen)
    mobileSidebarToggle.classList.toggle("sidebar-open", isSidebarOpen)

    // Изменение иконки
    const icon = mobileSidebarToggle.querySelector("i")
    if (icon) {
      if (isSidebarOpen) {
        icon.className = "fas fa-times"
        mobileSidebarToggle.setAttribute("title", "Закрыть меню")
      } else {
        icon.className = "fas fa-bars"
        mobileSidebarToggle.setAttribute("title", "Открыть меню")
      }
    }

    // Управление позицией кнопки при открытии сайдбара
    if (isMobile()) {
      if (isSidebarOpen) {
        mobileSidebarToggle.style.left = "100px" // Справа от сайдбара
        mobileSidebarToggle.style.transform = "translateX(0)"
      } else {
        mobileSidebarToggle.style.left = "15px" // Исходная позиция
        mobileSidebarToggle.style.transform = "translateX(0)"
      }
    }
  }

  // Функция для сброса состояний при изменении размера экрана
  function resetStates() {
    if (isDesktop()) {
      // Десктоп - сбрасываем все мобильные состояния
      if (menu) {
        menu.classList.remove("active")
        menu.style.pointerEvents = ""
      }
      if (mobileMenuToggle) {
        mobileMenuToggle.classList.remove("active")
      }
      if (sidebar) {
        sidebar.classList.remove("active")
        sidebar.style.pointerEvents = ""
      }
      if (sidebarOverlay) {
        sidebarOverlay.classList.remove("active")
      }
      if (mobileSidebarToggle) {
        mobileSidebarToggle.style.left = ""
        mobileSidebarToggle.style.transform = ""
      }
      body.style.overflow = ""
    } else if (isTablet()) {
      // Планшет - сбрасываем только сайдбар
      if (sidebar) {
        sidebar.classList.remove("active")
        sidebar.style.pointerEvents = ""
      }
      if (sidebarOverlay) {
        sidebarOverlay.classList.remove("active")
      }
      if (mobileSidebarToggle) {
        mobileSidebarToggle.style.left = ""
        mobileSidebarToggle.style.transform = ""
      }
      if (!menu || !menu.classList.contains("active")) {
        body.style.overflow = ""
      }
    }
    updateSidebarToggleState()
  }

  // Функция для закрытия сайдбара
  function closeSidebar() {
    if (sidebar && isMobile()) {
      sidebar.classList.remove("active")
      if (sidebarOverlay) {
        sidebarOverlay.classList.remove("active")
      }
      body.style.overflow = ""
      updateSidebarToggleState()
    }
  }

  // Функция для открытия сайдбара
  function openSidebar() {
    if (sidebar && isMobile()) {
      sidebar.classList.add("active")
      if (sidebarOverlay) {
        sidebarOverlay.classList.add("active")
      }
      body.style.overflow = "hidden"
      updateSidebarToggleState()
    }
  }

  // Функция для переключения сайдбара
  function toggleSidebar() {
    if (sidebar && isMobile()) {
      if (sidebar.classList.contains("active")) {
        closeSidebar()
      } else {
        openSidebar()
      }
    }
  }

  // Функция для закрытия меню хедера
  function closeHeaderMenu() {
    if (menu && (isMobile() || isTablet())) {
      menu.classList.remove("active")
      if (mobileMenuToggle) {
        mobileMenuToggle.classList.remove("active")
      }
      if (!sidebar || !sidebar.classList.contains("active")) {
        body.style.overflow = ""
      }
      updateSidebarToggleState()
    }
  }

  // Функция для открытия меню хедера
  function openHeaderMenu() {
    if (menu && (isMobile() || isTablet())) {
      menu.classList.add("active")
      if (mobileMenuToggle) {
        mobileMenuToggle.classList.add("active")
      }
      body.style.overflow = "hidden"
      updateSidebarToggleState()
    }
  }

  // Функция для переключения меню хедера
  function toggleHeaderMenu() {
    if (menu && (isMobile() || isTablet())) {
      if (menu.classList.contains("active")) {
        closeHeaderMenu()
      } else {
        openHeaderMenu()
      }
    }
  }

  // Обработчик для кнопки мобильного меню хедера
  if (mobileMenuToggle && menu) {
    mobileMenuToggle.addEventListener("click", (e) => {
      e.stopPropagation()
      toggleHeaderMenu()
    })
  }

  // Обработчик для кнопки мобильного сайдбара
  if (mobileSidebarToggle && sidebar) {
    mobileSidebarToggle.addEventListener("click", (e) => {
      e.stopPropagation()
      toggleSidebar()
    })
  }

  // Обработчик для оверлея сайдбара
  if (sidebarOverlay) {
    sidebarOverlay.addEventListener("click", () => {
      closeSidebar()
    })
  }

  // Закрытие меню при клике вне их области
  document.addEventListener("click", (e) => {
    let stateChanged = false

    // Закрытие меню хедера
    if (!e.target.closest("header") && !e.target.closest(".mobile-menu-toggle")) {
      if (menu && (isMobile() || isTablet()) && menu.classList.contains("active")) {
        closeHeaderMenu()
        stateChanged = true
      }
    }

    // Закрытие сайдбара
    if (!e.target.closest(".sidebar") && !e.target.closest(".mobile-sidebar-toggle")) {
      if (sidebar && isMobile() && sidebar.classList.contains("active")) {
        closeSidebar()
        stateChanged = true
      }
    }
  })

  // Предотвращение закрытия при клике внутри сайдбара
  if (sidebar) {
    sidebar.addEventListener("click", (e) => {
      e.stopPropagation()
    })
  }

  // Предотвращение закрытия при клике внутри меню хедера
  if (menu) {
    menu.addEventListener("click", (e) => {
      // Закрываем меню только при клике на ссылки
      if (e.target.tagName === "A") {
        closeHeaderMenu()
      }
    })
  }

  // Обработчик изменения размера окна с дебаунсингом
  let resizeTimeout
  window.addEventListener("resize", () => {
    clearTimeout(resizeTimeout)
    resizeTimeout = setTimeout(() => {
      resetStates()
    }, 100)
  })

  // Обработчик для клавиши Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (sidebar && sidebar.classList.contains("active")) {
        closeSidebar()
      }
      if (menu && menu.classList.contains("active")) {
        closeHeaderMenu()
      }
    }
  })

  // Инициализация состояний при загрузке
  resetStates()

  // Экспорт функций для использования в других скриптах
  window.sidebarControls = {
    openSidebar,
    closeSidebar,
    toggleSidebar,
    openHeaderMenu,
    closeHeaderMenu,
    toggleHeaderMenu,
    isMobile,
    isTablet,
    isDesktop,
  }
})
