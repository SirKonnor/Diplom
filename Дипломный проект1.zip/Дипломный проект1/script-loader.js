// Проверка загрузки всех необходимых скриптов
document.addEventListener("DOMContentLoaded", () => {
    console.log("Проверка загрузки скриптов:")
  
    // Проверяем наличие функции openOrderModal
    if (typeof window.openOrderModal === "function") {
      console.log("✅ Функция openOrderModal успешно загружена")
    } else {
      console.error("❌ Функция openOrderModal не найдена! Проверьте подключение файла order-functions.js")
    }
  
    // Проверяем наличие модального окна
    const orderModal = document.getElementById("orderModal")
    if (orderModal) {
      console.log("✅ Модальное окно заказа (#orderModal) найдено на странице")
    } else {
      console.warn("⚠️ Модальное окно заказа (#orderModal) не найдено на странице")
    }
  
    // Проверяем наличие формы заказа
    const orderForm = document.getElementById("orderForm")
    if (orderForm) {
      console.log("✅ Форма заказа (#orderForm) найдена на странице")
    } else {
      console.warn("⚠️ Форма заказа (#orderForm) не найдена на странице")
    }
  })
  