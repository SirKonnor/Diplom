document.addEventListener("DOMContentLoaded", () => {
  // 1. First declare all variables
  const authData = JSON.parse(sessionStorage.getItem("auth")) || {}
  const messagesBody = document.getElementById("messagesBody")
  const messageInput = document.getElementById("messageInput")
  const sendMessageBtn = document.getElementById("sendMessageBtn")
  const conversationsList = document.querySelector(".conversations-list")
  const conversationTitle = document.getElementById("conversationTitle")
  const viewProfileBtn = document.getElementById("viewProfileBtn")
  const messageInputContainer = document.querySelector(".message-input")
  const adminUsersBtn = document.getElementById("adminUsersBtn")
  const messagesTitle = document.getElementById("messagesTitle")
  const logoutBtn = document.getElementById("logoutBtn")
  const userIcon = document.getElementById("user-icon")
  const messageToUser = JSON.parse(sessionStorage.getItem("messageToUser")) || null
  const fileInput = document.getElementById("fileInput")
  const attachmentPreview = document.getElementById("attachmentPreview")
  const attachButton = document.getElementById("attachButton")
  const searchInput = document.getElementById("searchInput")
  const searchButton = document.getElementById("searchButton")
  const sortSelect = document.getElementById("sortSelect")

  // Declare isAdmin and other important variables at the beginning
  const isAdmin = authData.user?.role === "admin"
  const isHelper = authData.user?.role === "helper"
  const isSupport = isAdmin || isHelper
  // Change these from const to let so they can be reassigned
  let currentConversationId = null
  let unreadMessagesCount = 0
  let selectedFiles = []
  let allConversations = []

  // Function to handle file selection
  const handleFileSelect = (event) => {
    const files = event.target.files
    if (!files || files.length === 0) return

    // Clear previous preview if attaching new files
    if (!event.ctrlKey) {
      selectedFiles = []
      attachmentPreview.innerHTML = ""
    }

    // Process each selected file
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      selectedFiles.push(file)

      // Create preview element
      const previewItem = document.createElement("div")
      previewItem.className = "attachment-preview-item"
      const fileIndex = selectedFiles.length - 1

      // Different preview based on file type
      if (file.type.startsWith("image/")) {
        // Image preview
        const reader = new FileReader()
        reader.onload = (e) => {
          previewItem.innerHTML = `
            <img src="${e.target.result}" alt="${file.name}" class="attachment-thumbnail">
            <span class="attachment-name">${file.name}</span>
            <button class="remove-attachment" data-index="${fileIndex}">
              <i class="fas fa-times"></i>
            </button>
          `
          attachmentPreview.appendChild(previewItem)
        }
        reader.readAsDataURL(file)
      } else {
        // Generic file preview
        let icon = "fa-file"
        if (file.type.includes("pdf")) icon = "fa-file-pdf"
        else if (file.type.includes("word")) icon = "fa-file-word"
        else if (file.type.includes("excel") || file.type.includes("sheet")) icon = "fa-file-excel"
        else if (file.type.includes("video")) icon = "fa-file-video"
        else if (file.type.includes("audio")) icon = "fa-file-audio"
        else if (file.type.includes("zip") || file.type.includes("archive")) icon = "fa-file-archive"

        previewItem.innerHTML = `
          <i class="fas ${icon} attachment-icon"></i>
          <span class="attachment-name">${file.name}</span>
          <button class="remove-attachment" data-index="${fileIndex}">
            <i class="fas fa-times"></i>
          </button>
        `
        attachmentPreview.appendChild(previewItem)
      }
    }

    // Show the preview container
    attachmentPreview.style.display = selectedFiles.length > 0 ? "flex" : "none"

    // Add event listeners to remove buttons
    document.querySelectorAll(".remove-attachment").forEach((button) => {
      button.addEventListener("click", (e) => {
        const index = Number.parseInt(e.currentTarget.dataset.index)
        removeAttachment(index)
      })
    })
  }

  // New function to remove attachments
  const removeAttachment = (index) => {
    if (index >= 0 && index < selectedFiles.length) {
      // Remove the file from the array
      selectedFiles.splice(index, 1)

      // Rebuild the preview
      attachmentPreview.innerHTML = ""
      selectedFiles.forEach((file, idx) => {
        const previewItem = document.createElement("div")
        previewItem.className = "attachment-preview-item"
        const fileIndex = idx

        if (file.type.startsWith("image/")) {
          // Image preview
          const reader = new FileReader()
          reader.onload = (e) => {
            previewItem.innerHTML = `
              <img src="${e.target.result}" alt="${file.name}" class="attachment-thumbnail">
              <span class="attachment-name">${file.name}</span>
              <button class="remove-attachment" data-index="${fileIndex}">
                <i class="fas fa-times"></i>
              </button>
            `
            attachmentPreview.appendChild(previewItem)
          }
          reader.readAsDataURL(file)
        } else {
          // Generic file preview
          let icon = "fa-file"
          if (file.type.includes("pdf")) icon = "fa-file-pdf"
          else if (file.type.includes("word")) icon = "fa-file-word"
          else if (file.type.includes("excel") || file.type.includes("sheet")) icon = "fa-file-excel"
          else if (file.type.includes("video")) icon = "fa-file-video"
          else if (file.type.includes("audio")) icon = "fa-file-audio"
          else if (file.type.includes("zip") || file.type.includes("archive")) icon = "fa-file-archive"

          previewItem.innerHTML = `
            <i class="fas ${icon} attachment-icon"></i>
            <span class="attachment-name">${file.name}</span>
            <button class="remove-attachment" data-index="${fileIndex}">
              <i class="fas fa-times"></i>
            </button>
          `
          attachmentPreview.appendChild(previewItem)
        }
      })

      // Show the preview container
      attachmentPreview.style.display = selectedFiles.length > 0 ? "flex" : "none"

      // Reattach event listeners to remove buttons
      document.querySelectorAll(".remove-attachment").forEach((button) => {
        button.addEventListener("click", (e) => {
          const index = Number.parseInt(e.currentTarget.dataset.index)
          removeAttachment(index)
        })
      })
    }
  }

  // Function to update user status
  const updateUserStatus = async (status) => {
    try {
      await fetch("update-user-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
          status: status,
        }),
      })
    } catch (error) {
      console.error("Error updating user status:", error)
    }
  }

  // Function to get user status
  const getUserStatus = async (userId) => {
    try {
      const response = await fetch("get-user-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userId,
        }),
      })

      const data = await response.json()
      return data.success ? data : { success: false, status: "offline", lastSeen: null }
    } catch (error) {
      console.error("Error getting user status:", error)
      return { success: false, status: "offline", lastSeen: null }
    }
  }

  // Function to format last seen time
  const formatLastSeen = (lastSeen) => {
    if (!lastSeen) return "Неизвестно"

    const lastSeenDate = new Date(lastSeen)
    const now = new Date()
    const diffMs = now - lastSeenDate
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMins / 60)
    const diffDays = Math.floor(diffHours / 24)

    if (diffMins < 1) return "Только что"
    if (diffMins < 60) return `${diffMins} мин. назад`
    if (diffHours < 24) return `${diffHours} ч. назад`
    if (diffDays < 7) return `${diffDays} дн. назад`

    return lastSeenDate.toLocaleDateString()
  }

  // Функция для получения ID администратора или помощника
  const getAdminId = async () => {
    try {
      const response = await fetch("get-admin-id.php", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()
      return data.adminId
    } catch (error) {
      console.error("Ошибка получения ID администратора:", error)
      return null
    }
  }

  // Функция для проверки непрочитанных сообщений
  const checkUnreadMessages = async () => {
    try {
      const response = await fetch("get-unread-messages-count.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        unreadMessagesCount = data.count
        updateNotificationBadges(unreadMessagesCount)
      }
    } catch (error) {
      console.error("Ошибка получения непрочитанных сообщений:", error)
    }
  }

  // Функция для обновления значков уведомлений
  const updateNotificationBadges = (count) => {
    // Remove the condition that was hiding notifications on profile pages
    // Instead, we'll show notifications everywhere except the messages page
    if (window.location.pathname.includes("messages.html")) {
      return
    }

    // Обновляем значок на иконке сообщений
    const messageIcon = document.querySelector('.sidebar-btn[title="Сообщения"]')
    if (messageIcon) {
      // Удаляем существующий значок, если есть
      const existingBadge = messageIcon.querySelector(".notification-badge")
      if (existingBadge) {
        existingBadge.remove()
      }

      // Добавляем новый значок, если есть непрочитанные сообщения
      if (count > 0) {
        const badge = document.createElement("div")
        badge.className = "notification-badge"
        badge.textContent = count > 9 ? "9+" : count
        messageIcon.appendChild(badge)
      }
    }

    // Обновляем значок на иконке пользователя
    if (userIcon) {
      // Удаляем существующий значок, если есть
      const existingBadge = userIcon.querySelector(".notification-badge")
      if (existingBadge) {
        existingBadge.remove()
      }

      // Добавляем новый значок, если есть непрочитанные сообщения
      if (count > 0) {
        const badge = document.createElement("div")
        badge.className = "notification-badge"
        badge.textContent = count > 9 ? "9+" : count
        userIcon.appendChild(badge)
      }
    }
  }

  // Загрузка диалогов
  const loadConversations = async () => {
    try {
      if (isAdmin || isHelper) {
    const adminSearchContainer = document.getElementById("adminSearchContainer")
    if (adminSearchContainer) {
      adminSearchContainer.style.display = "block"
    }
  }
      if (isSupport) {
        // Для админа/помощника - загружаем список диалогов
        const response = await fetch("get-admin-conversations.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            adminId: authData.user.id,
            showAll: true,
            isHelper: isHelper,
          }),
        })

        const data = await response.json()

        if (data.success) {
          // Store conversations for sorting
          allConversations = data.conversations

          // Add timestamp to each conversation for sorting
          allConversations.forEach((conv) => {
            // Try to extract timestamp from the conversation
            try {
              // Get the last message timestamp from the database if available
              if (conv.last_message_time) {
                conv.timestamp = new Date(conv.last_message_time).getTime()
              } else {
                // If no timestamp is available, use current time
                conv.timestamp = Date.now()
              }
            } catch (e) {
              console.error("Error parsing timestamp:", e)
              // Default to current time if parsing fails
              conv.timestamp = Date.now()
            }
          })

          // Get online status for each user
          for (const conv of allConversations) {
            const statusData = await getUserStatus(conv.user_id)
            conv.status = statusData.status
            conv.last_seen = statusData.last_seen
          }

          displayConversations(allConversations)

          // If there are conversations and sort select exists, apply the current sort
          if (allConversations.length > 0 && sortSelect) {
            sortConversations()
          }

          // If есть диалоги, открываем первый
          if (allConversations.length > 0) {
            const firstConv = allConversations[0]
            openConversation(firstConv.user_id, firstConv.user_name)
          }
        }
      } else {
        // Для обычного пользователя - показываем чаты с поддержкой и админом
        conversationsList.style.display = "block"
        conversationsList.innerHTML = ""

        // Загружаем ID администратора для техподдержки
        const adminId = await getAdminId()

        // Get admin status if available
        let adminStatus = { status: "offline", last_seen: null }
        if (adminId) {
          adminStatus = await getUserStatus(adminId)
        }

        // Добавляем чат с техподдержкой
        const supportElement = document.createElement("div")
        supportElement.className = "conversation active"
        supportElement.dataset.conversationId = "support"
        supportElement.innerHTML = `
            <div class="conversation-avatar">
                <i class="fas fa-headset"></i>
                <span class="status-indicator ${adminStatus.status}"></span>
            </div>
            <div class="conversation-info">
                <h4>Техподдержка</h4>
                <p class="last-message">Напишите ваш вопрос...</p>
                <small class="user-id-display">ID: ${adminId || "Н/Д"}</small>
                <div class="user-status">${adminStatus.status === "online" ? "В сети" : "Не в сети"} ${adminStatus.status === "offline" && adminStatus.last_seen ? "· " + formatLastSeen(adminStatus.last_seen) : ""}</div>
            </div>
          `
        conversationsList.appendChild(supportElement)

        // Загружаем другие чаты пользователя (например, с админом)
        try {
          console.log("Loading user conversations for user ID:", authData.user.id)
          const response = await fetch("get-user-conversations.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              userId: authData.user.id,
            }),
            credentials: "include", // Important for session cookies
          })

          if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`)
          }

          const data = await response.json()
          console.log("User conversations data:", data)

          if (data.success && data.conversations && data.conversations.length > 0) {
            for (const conv of data.conversations) {
              if (conv.support_role !== "helper") {
                // Get user status
                const statusData = await getUserStatus(conv.user_id)

                // Пропускаем чат с техподдержкой, он уже добавлен
                const convElement = document.createElement("div")
                convElement.className = "conversation"
                convElement.dataset.conversationId = conv.user_id
                convElement.innerHTML = `
                    <div class="conversation-avatar">
                      <i class="fas fa-user-shield"></i>
                      <span class="status-indicator ${statusData.status}"></span>
                    </div>
                    <div class="conversation-info">
                      <h4>Администратор</h4>
                      <p class="last-message">${conv.last_message || "Нет сообщений"}</p>
                      <small class="user-id-display">ID: ${conv.user_id}</small>
                      <div class="user-status">${statusData.status === "online" ? "В сети" : "Не в сети"} ${statusData.status === "offline" && statusData.last_seen ? "· " + formatLastSeen(statusData.last_seen) : ""}</div>
                      ${conv.unread_count > 0 ? `<span class="unread-count">${conv.unread_count}</span>` : ""}
                    </div>
                  `

                convElement.addEventListener("click", () => {
                  document.querySelectorAll(".conversation").forEach((c) => c.classList.remove("active"))
                  convElement.classList.add("active")
                  loadMessages(conv.user_id)
                  conversationTitle.textContent = `Администратор (ID: ${conv.user_id})`
                  currentConversationId = conv.user_id
                  messageInputContainer.style.display = "flex"

                  // Добавляем кнопку профиля администратора
                  viewProfileBtn.style.display = "inline-block"
                  viewProfileBtn.className = "profile-button"
                  viewProfileBtn.innerHTML = '<i class="fas fa-user-shield"></i> Профиль администратора'
                  viewProfileBtn.onclick = () => {
                    window.location.href = `profile.html?userId=${conv.user_id}`
                  }
                })

                conversationsList.appendChild(convElement)
              }
            }
          } else {
            console.log("No admin conversations found or data.success is false")
          }
        } catch (error) {
          console.error("Ошибка загрузки чатов пользователя:", error)
        }

        // Показываем блок ввода сообщений
        messageInputContainer.style.display = "flex"

        // Загружаем сообщения для техподдержки
        supportElement.addEventListener("click", () => {
          document.querySelectorAll(".conversation").forEach((c) => c.classList.remove("active"))
          supportElement.classList.add("active")
          openSupportConversation()
        })

        // По умолчанию открываем чат с техподдержкой
        if (adminId) {
          currentConversationId = adminId
          openSupportConversation()
        }
      }

      // Проверяем непрочитанные сообщения
      checkUnreadMessages()

      // Устанавливаем интервал для проверки новых сообщений
      setInterval(checkUnreadMessages, 30000) // Проверка каждые 30 секунд

      // Set up interval to refresh user statuses
      setInterval(async () => {
        const conversations = document.querySelectorAll(".conversation")
        for (const conv of conversations) {
          const userId = conv.dataset.userId || conv.dataset.conversationId
          if (userId && userId !== "support") {
            const statusData = await getUserStatus(userId)
            const statusIndicator = conv.querySelector(".status-indicator")
            const userStatus = conv.querySelector(".user-status")

            if (statusIndicator) {
              statusIndicator.className = `status-indicator ${statusData.status}`
            }

            if (userStatus) {
              userStatus.innerHTML = `${statusData.status === "online" ? "В сети" : "Не в сети"} ${statusData.status === "offline" && statusData.last_seen ? "· " + formatLastSeen(statusData.last_seen) : ""}`
            }
          }
        }
      }, 15000) // Update every 15 seconds instead of 30

      // Update our own status more frequently
      setInterval(() => {
        updateUserStatus("online")
      }, 15000) // Update every 15 seconds
    } catch (error) {
      console.error("Ошибка загрузки диалогов:", error)
    }
  }

  // Function to perform search
  function performSearch() {
    const searchTerm = searchInput.value.trim().toLowerCase()

    if (!searchTerm) {
      // If search term is empty, reload all conversations
      displayConversations(allConversations)
      return
    }

    // Filter conversations based on search term
    const filteredConversations = allConversations.filter((conv) => {
      const userName = conv.user_name.toLowerCase()
      const userId = conv.user_id.toString()

      return userName.includes(searchTerm) || userId.includes(searchTerm)
    })

    // Display filtered conversations
    displayConversations(filteredConversations)

    // Show message if no results found
    if (filteredConversations.length === 0) {
      conversationsList.innerHTML = '<p class="empty">Нет результатов поиска</p>'
    }
  }

  // Function to sort conversations
  function sortConversations() {
    if (!sortSelect || allConversations.length === 0) return

    const sortValue = sortSelect.value
    const sortedConversations = [...allConversations]

    // Sort conversations based on selected option
    switch (sortValue) {
      case "newest":
        // Sort by newest message timestamp (highest timestamp first)
        sortedConversations.sort((a, b) => {
          return (b.timestamp || 0) - (a.timestamp || 0)
        })
        break

      case "oldest":
        // Sort by oldest message timestamp (lowest timestamp first)
        sortedConversations.sort((a, b) => {
          return (a.timestamp || 0) - (b.timestamp || 0)
        })
        break

      case "unread":
        // Sort by unread count (conversations with unread messages first)
        sortedConversations.sort((a, b) => {
          return (b.unread_count || 0) - (a.unread_count || 0)
        })
        break

      case "name":
        // Sort alphabetically by name
        sortedConversations.sort((a, b) => {
          return a.user_name.localeCompare(b.user_name)
        })
        break

      case "online":
        // Sort by online status (online users first)
        sortedConversations.sort((a, b) => {
          if (a.status === "online" && b.status !== "online") return -1
          if (a.status !== "online" && b.status === "online") return 1
          return 0
        })
        break
    }

    // Display sorted conversations
    displayConversations(sortedConversations)
  }

  // Открытие диалога с техподдержкой (для пользователей)
  const openSupportConversation = async () => {
    currentConversationId = "support"

    // Получаем ID администратора
    const adminId = await getAdminId()

    // Get admin status
    let adminStatus = { status: "offline", last_seen: null }
    if (adminId) {
      adminStatus = await getUserStatus(adminId)
    }

    // Устанавливаем заголовок с ID и статусом
    conversationTitle.innerHTML = `
      Техподдержка ${adminId ? `(ID: ${adminId})` : ""}
      <span class="user-status-header ${adminStatus.status}">
        ${adminStatus.status === "online" ? "В сети" : "Не в сети"} 
        ${adminStatus.status === "offline" && adminStatus.last_seen ? "· " + formatLastSeen(adminStatus.last_seen) : ""}
      </span>
    `

    // Показываем кнопку профиля техподдержки
    viewProfileBtn.style.display = "inline-block"
    viewProfileBtn.className = "profile-button"
    viewProfileBtn.innerHTML = '<i class="fas fa-headset"></i> Профиль техподдержки'

    // Обработчик клика по кнопке профиля
    viewProfileBtn.onclick = async () => {
      try {
        const response = await fetch("get-admin-id.php", {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        })

        const data = await response.json()
        if (data.success && data.adminId) {
          window.location.href = `profile.html?userId=${data.adminId}`
        }
      } catch (error) {
        console.error("Ошибка получения ID техподдержки:", error)
      }
    }

    messageInputContainer.style.display = "flex"

    // Загружаем сообщения
    const messages = await loadMessages("support")

    // Если нет сообщений, добавляем приветственное сообщение
    if (!messages || messages.length === 0) {
      const welcomeMsg = document.createElement("div")
      welcomeMsg.className = "message message-incoming"
      welcomeMsg.innerHTML = `
          <small class="sender-role">Техподдержка${adminId ? ` (ID: ${adminId})` : ""}</small>
          <p>Здравствуйте! Чем я могу вам помочь?</p>
          <small>${new Date().toLocaleString()}</small>
          <div class="read-status read">
            Прочитано <i class="fas fa-check-double"></i>
          </div>
        `
      messagesBody.innerHTML = ""
      messagesBody.appendChild(welcomeMsg)
    }
  }

  // Отображение списка диалогов (для админа/помощника)
  const displayConversations = (conversations) => {
    conversationsList.innerHTML = ""

    if (!conversations || conversations.length === 0) {
      conversationsList.innerHTML = '<p class="empty">Нет активных диалогов</p>'
      return
    }

    conversations.forEach((conversation) => {
      const convElement = document.createElement("div")
      convElement.className = "conversation"
      convElement.dataset.userId = conversation.user_id
      // Add data attributes for sorting
      convElement.dataset.timestamp = conversation.timestamp || Date.now()
      convElement.dataset.unreadCount = conversation.unread_count || 0
      convElement.dataset.userName = conversation.user_name || ""
      convElement.dataset.status = conversation.status || "offline"

      convElement.innerHTML = `
          <div class="conversation-avatar">
            <img src="${conversation.avatar_path || "images/default-avatar.png"}" 
                 onerror="this.src='images/default-avatar.png'">
            <span class="status-indicator ${conversation.status || "offline"}"></span>
          </div>
          <div class="conversation-info">
            <h4>${conversation.user_name}</h4>
            <p class="last-message">${conversation.last_message || "Нет сообщений"}</p>
            <small class="user-id-display">ID: ${conversation.user_id}</small>
            <div class="user-status">
              ${conversation.status === "online" ? "В сети" : "Не в сети"} 
              ${conversation.status === "offline" && conversation.last_seen ? "· " + formatLastSeen(conversation.last_seen) : ""}
            </div>
            ${conversation.unread_count > 0 ? `<span class="unread-count">${conversation.unread_count}</span>` : ""}
          </div>
        `

      convElement.addEventListener("click", () => {
        openConversation(conversation.user_id, conversation.user_name, conversation.status, conversation.last_seen)
      })

      conversationsList.appendChild(convElement)
    })
  }

  // Открытие диалога (для админа/помощника)
  const openConversation = (userId, userName, status = "offline", lastSeen = null) => {
    currentConversationId = userId

    // Для пользователя создаем блок чата с поддержкой
    if (!isSupport) {
      const existingConv = document.querySelector('.conversation[data-conversation-id="support"]')
      if (!existingConv) {
        const convElement = document.createElement("div")
        convElement.className = "conversation active"
        convElement.dataset.conversationId = "support"
        convElement.innerHTML = `
            <div class="conversation-avatar">
              <i class="fas fa-headset"></i>
              <span class="status-indicator offline"></span>
            </div>
            <div class="conversation-info">
              <h4>Техподдержка</h4>
              <p class="last-message">Напишите ваш вопрос...</p>
            <div class="user-status">Не в сети</div>
          </div>
        `
        conversationsList.appendChild(convElement)
      }
    }

    // Обновляем UI
    document.querySelectorAll(".conversation").forEach((c) => {
      c.classList.remove("active")
      if (c.dataset.userId === userId.toString() || c.dataset.conversationId === userId.toString()) {
        c.classList.add("active")
      }
    })

    // Добавляем ID пользоателя и статус в заголовок
    conversationTitle.innerHTML = isSupport
      ? `${userName} (ID: ${userId}) <span class="user-status-header ${status}">${status === "online" ? "В сети" : "Не в сети"} ${status === "offline" && lastSeen ? "· " + formatLastSeen(lastSeen) : ""}</span>`
      : userName

    messageInputContainer.style.display = "flex"

    // Для админа/помощника показываем кнопку профиля
    viewProfileBtn.style.display = isSupport && userId !== "support" ? "inline-block" : "none"
    if (isSupport && userId !== "support") {
      viewProfileBtn.className = "profile-button"
      viewProfileBtn.innerHTML = '<i class="fas fa-user"></i> Профиль пользователя'
      viewProfileBtn.onclick = () => {
        window.location.href = `profile.html?userId=${userId}`
      }
    }

    loadMessages(userId)
  }

  // Загрузка сообщений
  const loadMessages = async (userId) => {
    try {
      const response = await fetch("get-messages.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
          conversationId: userId,
          isAdmin: isAdmin,
          isHelper: isHelper,
        }),
        credentials: "include", // Важно для передачи сессии
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        displayMessages(data.messages, userId)

        if (isSupport) {
          await markAsRead(userId)
        }

        return data.messages
      } else {
        throw new Error(data.error || "Failed to load messages")
      }
    } catch (error) {
      console.error("Ошибка загрузки сообщений:", error)
      messagesBody.innerHTML = `<p class="error">Ошибка: ${error.message}</p>`

      // Если ошибка 401, перенаправляем на логин
      if (error.message.includes("401")) {
        sessionStorage.removeItem("auth")
        window.location.href = "login.html"
      }

      return []
    }
  }

  // Отметка как прочитанные (для админа/помощника)
  const markAsRead = async (userId) => {
    try {
      await fetch("mark-messages-read.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          receiverId: authData.user.id,
          senderId: userId,
        }),
      })

      // Обновляем счетчик непрочитанных сообщений
      checkUnreadMessages()
    } catch (error) {
      console.error("Ошибка отметки сообщений:", error)
    }
  }

  // Отображение сообщений
  const displayMessages = (messages, conversationId) => {
    messagesBody.innerHTML = ""

    if (messages.length === 0) {
      messagesBody.innerHTML = '<p class="empty-conversation">Нет сообщений в этом диалоге</p>'
      return
    }

    messages.forEach((message) => {
      const isOutgoing = message.sender_id == authData.user.id
      const isSystem = message.is_system

      const messageElement = document.createElement("div")
      messageElement.className = `message ${
        isSystem ? "message-system" : isOutgoing ? "message-outgoing" : "message-incoming"
      }`

      // Добавляем информацию о роли отправителя только для входящих сообщений от админа или помощника
      let senderInfo = ""
      if (!isOutgoing && !isSystem) {
        if (message.sender_role === "admin") {
          senderInfo = `<small class="sender-role">Администратор (ID: ${message.sender_id})</small>`
        } else if (message.sender_role === "helper") {
          senderInfo = `<small class="sender-role">Техподдержка (ID: ${message.sender_id})</small>`
        } else {
          // Для админа показываем ID пользователя
          senderInfo = isSupport ? `<small class="sender-role">Пользователь (ID: ${message.sender_id})</small>` : ""
        }
      } else if (isOutgoing && isSupport && !isSystem) {
        // Для исходящих сообщений админа добавляем его ID
        senderInfo = `<small class="sender-role">Вы (ID: ${message.sender_id})</small>`
      }

      // Добавляем статус прочтения
      const readStatus =
        message.is_read == 1 || isSystem
          ? `<div class="read-status read">Прочитано <i class="fas fa-check-double"></i></div>`
          : `<div class="read-status unread">Отправлено <i class="fas fa-check"></i></div>`

      // Добавляем вложения, если они есть
      let attachmentsHtml = ""
      if (message.attachments && message.attachments.length > 0) {
        attachmentsHtml = '<div class="message-attachments">'

        message.attachments.forEach((attachment) => {
          const isImage = attachment.file_type.startsWith("image/")
          const isVideo = attachment.file_type.startsWith("video/")
          const isAudio = attachment.file_type.startsWith("audio/")

          if (isImage) {
            attachmentsHtml += `
              <div class="attachment-image">
                <a href="${attachment.file_path}" target="_blank">
                  <img src="${attachment.file_path}" alt="${attachment.file_name}">
                </a>
              </div>
            `
          } else if (isVideo) {
            attachmentsHtml += `
              <div class="attachment-video">
                <video controls>
                  <source src="${attachment.file_path}" type="${attachment.file_type}">
                  Ваш браузер не поддерживает видео.
                </video>
              </div>
            `
          } else if (isAudio) {
            attachmentsHtml += `
              <div class="attachment-audio">
                <audio controls>
                  <source src="${attachment.file_path}" type="${attachment.file_type}">
                  Ваш браузер не поддерживает аудио.
                </audio>
              </div>
            `
          } else {
            // For other file types, show a download link
            let fileIcon = "fa-file"
            if (attachment.file_type.includes("pdf")) fileIcon = "fa-file-pdf"
            else if (attachment.file_type.includes("word")) fileIcon = "fa-file-word"
            else if (attachment.file_type.includes("excel") || attachment.file_type.includes("spreadsheet"))
              fileIcon = "fa-file-excel"

            // Format file size
            const fileSize =
              attachment.file_size < 1024
                ? `${attachment.file_size} B`
                : attachment.file_size < 1048576
                  ? `${(attachment.file_size / 1024).toFixed(1)} KB`
                  : `${(attachment.file_size / 1048576).toFixed(1)} MB`

            attachmentsHtml += `
              <div class="attachment-file">
                <a href="${attachment.file_path}" target="_blank" download="${attachment.file_name}">
                  <i class="fas ${fileIcon}"></i>
                  <div class="file-info">
                    <span class="file-name">${attachment.file_name}</span>
                    <span class="file-size">${fileSize}</span>
                  </div>
                </a>
              </div>
            `
          }
        })

        attachmentsHtml += "</div>"
      }

      messageElement.innerHTML = `
          ${senderInfo}
          <p>${message.text}</p>
          ${attachmentsHtml}
          <small>${new Date(message.created_at).toLocaleString()}</small>
          ${isOutgoing ? readStatus : ""}
        `

      messagesBody.appendChild(messageElement)
    })

    messagesBody.scrollTop = messagesBody.scrollHeight
  }

  // Отправка сообщения
  const sendMessage = async () => {
    const text = messageInput.value.trim()
    if ((!text && (!selectedFiles || selectedFiles.length === 0)) || !currentConversationId) return

    try {
      // If we have files, use FormData to send them
      if (selectedFiles && selectedFiles.length > 0) {
        const formData = new FormData()
        formData.append("sender_id", authData.user.id)
        formData.append(
          "receiver_id",
          isSupport ? currentConversationId : currentConversationId === "support" ? "support" : currentConversationId,
        )
        formData.append("text", text)
        formData.append("isAdmin", isAdmin)
        formData.append("isHelper", isHelper)

        // Append each file
        selectedFiles.forEach((file) => {
          formData.append("attachments[]", file)
        })

        const response = await fetch("send-message-with-attachments.php", {
          method: "POST",
          body: formData,
        })

        if (!response.ok) {
          const errorText = await response.text()
          throw new Error(`HTTP error ${response.status}: ${errorText}`)
        }

        const data = await response.json()

        if (!data.success) {
          throw new Error(data.error || "Failed to send message")
        }
      } else {
        // If no files, use JSON
        const response = await fetch("send-message.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sender_id: authData.user.id,
            receiver_id: isSupport
              ? currentConversationId
              : currentConversationId === "support"
                ? "support"
                : currentConversationId,
            text: text,
            isAdmin: isAdmin,
            isHelper: isHelper,
          }),
        })

        if (!response.ok) {
          const errorText = await response.text()
          throw new Error(`HTTP error ${response.status}: ${errorText}`)
        }

        const data = await response.json()

        if (!data.success) {
          throw new Error(data.error || "Failed to send message")
        }
      }

      // Clear input and file selection
      messageInput.value = ""
      if (fileInput) {
        fileInput.value = ""
      }
      selectedFiles = []
      if (attachmentPreview) {
        attachmentPreview.innerHTML = ""
        attachmentPreview.style.display = "none"
      }

      // Reload messages
      loadMessages(currentConversationId)

      // Для админа/помощника обновляем список диалогов
      if (isSupport) {
        document.getElementById("conversationsList").style.display = "block"
        loadConversations()
      }
    } catch (error) {
      console.error("Ошибка отправки сообщения:", error)
      alert("Ошибка при отправке сообщения: " + error.message)
    }
  }

  // Обработчик кнопки выхода
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      // Update status to offline before logging out
      updateUserStatus("offline")
      sessionStorage.removeItem("auth")
      window.location.href = "index.html"
    })
  }

  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // Показываем кнопку админа только если пользователь - admin (не helper)
  if (isAdmin && adminUsersBtn) {
    adminUsersBtn.style.display = "block"
    messagesTitle.textContent = "Сообщения от пользователей"
  }

  // Обработчик кнопки пользователей (только для админа)
  if (adminUsersBtn && isAdmin) {
    adminUsersBtn.addEventListener("click", () => {
      window.location.href = "admin-users.html"
    })
  }

  // Set online status when page loads
  updateUserStatus("online")

  // Set offline status when page unloads
  window.addEventListener("beforeunload", () => {
    updateUserStatus("offline")
  })

  // Add event listener for file input
  if (fileInput) {
    fileInput.addEventListener("change", handleFileSelect)
  }

  // Add event listener for attach button
  if (attachButton) {
    attachButton.addEventListener("click", () => {
      fileInput.click()
    })
  }

  // Add event listeners for search and sort
  if (searchButton) {
    searchButton.addEventListener("click", performSearch)
  }

  if (searchInput) {
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        performSearch()
      }
    })
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", sortConversations)
  }

  // Обработчики событий
  sendMessageBtn.addEventListener("click", sendMessage)
  messageInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  })

  // Обработка перехода из профиля
  if (messageToUser && isSupport) {
    // Ищем диалог с этим пользователем
    const existingConv = document.querySelector(`.conversation[data-user-id="${messageToUser.userId}"]`)

    if (existingConv) {
      // Если диалог уже есть, открываем его
      existingConv.click()
    } else {
      // Если диалога нет, создаем новый
      openConversation(messageToUser.userId, messageToUser.userName)

      // Добавляем системное сообщение о новом диалоге
      const systemMsg = document.createElement("div")
      systemMsg.className = "message message-system"
      systemMsg.innerHTML = `
          <p>Новый диалог с пользователем ${messageToUser.userName} (ID: ${messageToUser.userId})</p>
          <small>${new Date().toLocaleString()}</small>
        `
      messagesBody.appendChild(systemMsg)
    }

    sessionStorage.removeItem("messageToUser")
  }

  // Загрузка начальных данных
  loadConversations()

  // Function to periodically check and update user statuses
  const updateAllUserStatuses = async () => {
    const conversations = document.querySelectorAll(".conversation")
    for (const conv of conversations) {
      const userId = conv.dataset.userId || conv.dataset.conversationId
      if (userId && userId !== "support") {
        const statusData = await getUserStatus(userId)
        const statusIndicator = conv.querySelector(".status-indicator")
        const userStatus = conv.querySelector(".user-status")

        if (statusIndicator) {
          statusIndicator.className = `status-indicator ${statusData.status}`
        }

        if (userStatus) {
          userStatus.innerHTML = `${statusData.status === "online" ? "В сети" : "Не в сети"} ${statusData.status === "offline" && statusData.last_seen ? "· " + formatLastSeen(statusData.last_seen) : ""}`
        }
      }
    }
  }

  // Set interval to refresh user statuses
  setInterval(updateAllUserStatuses, 10000) // Update every 10 seconds

  // Function to periodically update our own status
  setInterval(() => {
    updateUserStatus("online")
  }, 10000) // Update every 10 seconds
})
