/**
 * Обработка сообщений и уведомлений о сообщениях
 */
document.addEventListener("DOMContentLoaded", () => {
    // Проверяем авторизацию
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    if (!authData.isAuthenticated || !authData.user || !authData.user.id) {
      return
    }
  
    // Получаем элементы формы отправки сообщений
    const messageForm = document.getElementById("messageForm")
    const messageInput = document.getElementById("messageInput")
    const sendButton = document.getElementById("sendMessageBtn")
  
    if (!messageForm || !messageInput || !sendButton) {
      console.warn("Элементы формы отправки сообщений не найдены на странице")
      return
    }
  
    // Объявляем функцию updateChat (предполагается, что она определена в другом месте, например, в файле чата)
    // В реальном проекте, возможно, потребуется импортировать эту функцию из соответствующего модуля.
    // Для примера, определим пустую функцию:
    function updateChat() {
      // Здесь должна быть логика обновления чата
      console.log("Функция updateChat вызвана")
    }
  
    // Обработчик отправки сообщения
    messageForm.addEventListener("submit", async (event) => {
      event.preventDefault()
  
      const messageText = messageInput.value.trim()
      if (!messageText) return
  
      // Получаем ID получателя
      const receiverId = getReceiverId()
      if (!receiverId) {
        console.error("ID получателя не найден")
        return
      }
  
      try {
        // Отправляем сообщение
        const response = await fetch("send-message.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            sender_id: authData.user.id,
            receiver_id: receiverId,
            text: messageText,
          }),
        })
  
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`)
        }
  
        const data = await response.json()
  
        if (data.success) {
          // Очищаем поле ввода
          messageInput.value = ""
  
          // Обновляем чат (предполагается, что есть функция для обновления чата)
          if (typeof updateChat === "function") {
            updateChat()
          }
        } else {
          console.error("Ошибка при отправке сообщения:", data.error)
        }
      } catch (error) {
        console.error("Ошибка при отправке сообщения:", error)
      }
    })
  
    // Функция для получения ID получателя
    function getReceiverId() {
      // Пытаемся получить ID получателя из URL
      const urlParams = new URLSearchParams(window.location.search)
      const receiverId = urlParams.get("receiverId")
  
      if (receiverId) {
        return receiverId
      }
  
      // Если в URL нет, пытаемся получить из sessionStorage
      const currentChat = sessionStorage.getItem("currentChat")
      if (currentChat) {
        try {
          const chatData = JSON.parse(currentChat)
          return chatData.receiverId
        } catch (e) {
          console.error("Ошибка при парсинге данных чата:", e)
        }
      }
  
      // Если это сообщение в техподдержку
      if (document.querySelector(".support-chat")) {
        return "support"
      }
  
      return null
    }
  
    // Периодическое обновление количества непрочитанных сообщений
    function startMessageCountUpdater() {
      // Обновляем счетчик при загрузке страницы
      if (window.notificationSystem) {
        window.notificationSystem.fetchUnreadMessagesCount(authData.user.id)
      }
  
      // Устанавливаем интервал обновления (каждые 30 секунд)
      const updateInterval = 30000 // 30 секунд
  
      setInterval(() => {
        if (window.notificationSystem) {
          window.notificationSystem.fetchUnreadMessagesCount(authData.user.id)
        }
      }, updateInterval)
    }
  
    // Запускаем обновление счетчика сообщений
    startMessageCountUpdater()
  })
  