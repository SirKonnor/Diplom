<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['userId']) || empty($data['userId'])) {
        throw new Exception('User ID is required');
    }
    
    $userId = $data['userId'];
    
    // Добавляем информацию о запрашиваемом ID пользователя
    error_log("get-last-order.php: Requested user ID: " . $userId);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Database query
try {
    // Check if orders table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Orders table does not exist');
    }
    
    // Get the table structure to find the date column
    $stmt = $pdo->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Look for possible date columns
    $dateColumn = null;
    $possibleDateColumns = ['created_at', 'date_created', 'order_date', 'date', 'timestamp'];
    
    foreach ($possibleDateColumns as $column) {
        if (in_array($column, $columns)) {
            $dateColumn = $column;
            break;
        }
    }
    
    // If no date column found, use the ID column for ordering
    if (!$dateColumn) {
        $dateColumn = 'id';
    }
    
    // Get the last order using the identified date column
    $query = "SELECT * FROM orders WHERE user_id = :userId ORDER BY $dateColumn DESC LIMIT 1";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['userId' => $userId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Логируем результат запроса
    error_log("get-last-order.php: Query result for user ID $userId: " . ($order ? "Order found with ID " . $order['id'] : "No orders found"));
    
    if ($order) {
        // If status is not set, default to "PENDING"
        if (!isset($order['status']) || empty($order['status'])) {
            $order['status'] = 'PENDING';
        }
        
        // Add the date column name to the response for debugging
        echo json_encode([
            'success' => true, 
            'order' => $order,
            'dateColumn' => $dateColumn,
            'requestedUserId' => $userId // Добавляем ID пользователя в ответ для отладки
        ]);
    } else {
        // Важно: возвращаем null для order, если заказов нет
        echo json_encode([
            'success' => true, 
            'order' => null,
            'requestedUserId' => $userId // Добавляем ID пользователя в ответ для отладки
        ]);
    }
    
} catch (PDOException $e) {
    // Log the error to a file instead of displaying it
    error_log('Database error in get-last-order.php: ' . $e->getMessage());
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
