<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['orderId']) || empty($data['orderId'])) {
        throw new Exception('Order ID is required');
    }
    
    $orderId = $data['orderId'];
    
    // Get user ID from request or session
    if (isset($data['userId']) && !empty($data['userId'])) {
        $userId = $data['userId'];
    } else {
        // Try to get user ID from session
        $authData = isset($_SESSION['auth']) ? $_SESSION['auth'] : null;
        if (!$authData || !isset($authData['user']) || !isset($authData['user']['id'])) {
            // If not in session, try to get from sessionStorage via JavaScript
            $userId = null;
        } else {
            $userId = $authData['user']['id'];
        }
        
        // If still no user ID, check if we're cancelling our own order
        if (!$userId && isset($data['isOwnOrder']) && $data['isOwnOrder']) {
            // For own orders, we don't need to check user ID
            $userId = true;
        } else if (!$userId) {
            throw new Exception('User ID is required');
        }
    }
    
    // Check if user is admin
    $isAdmin = isset($data['isAdmin']) ? $data['isAdmin'] : false;
    
    // Get reason if provided
    $reason = isset($data['reason']) ? trim($data['reason']) : null;
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Update order status
try {
    // First check if the order exists
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = :orderId");
    $stmt->execute(['orderId' => $orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception('Order not found');
    }
    
    // Check if the order belongs to the user or if user is admin
    if ($userId !== true && $order['user_id'] != $userId && !$isAdmin) {
        throw new Exception('You do not have permission to cancel this order');
    }
    
    // Check if the order can be cancelled (only PENDING or CONFIRMED orders can be cancelled)
    if ($order['status'] !== 'PENDING' && $order['status'] !== 'CONFIRMED') {
        throw new Exception('This order cannot be cancelled because it is already ' . strtolower($order['status']));
    }
    
    // Check if the reason column exists in the orders table
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'reason'");
    $reasonColumnExists = $stmt->rowCount() > 0;
    
    // If reason column doesn't exist, add it
    if (!$reasonColumnExists) {
        $pdo->exec("ALTER TABLE orders ADD COLUMN reason TEXT");
    }
    
    // Update the order status and reason if provided
    if ($reason) {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'CANCELLED', reason = :reason WHERE id = :orderId");
        $stmt->execute([
            'reason' => $reason,
            'orderId' => $orderId
        ]);
    } else {
        $stmt = $pdo->prepare("UPDATE orders SET status = 'CANCELLED' WHERE id = :orderId");
        $stmt->execute(['orderId' => $orderId]);
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Order cancelled successfully'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
