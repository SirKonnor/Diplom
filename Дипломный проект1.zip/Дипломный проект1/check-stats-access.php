<?php
// Подключение к базе данных
require_once 'config.php';

// Проверка авторизации
session_start();

// Получение ID пользователя из сессии
$userId = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null;
$userRole = isset($_SESSION['user']['role']) ? $_SESSION['user']['role'] : null;

// Проверяем, есть ли ID пользователя в сессии
if (!$userId) {
    echo json_encode([
        'success' => false,
        'error' => 'Не авторизован',
        'session' => $_SESSION
    ]);
    exit;
}

try {
    // Подготовка запроса для проверки прав доступа
    $stmt = $pdo->prepare("SELECT id, role, Access FROM user WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Проверка прав доступа (администратор с доступом или владелец)
    $hasAccess = ($user && (($user['role'] === 'admin' && $user['Access'] == 1) || $user['role'] === 'owner'));
    
    echo json_encode([
        'success' => true,
        'hasAccess' => $hasAccess,
        'user' => [
            'id' => $user['id'],
            'role' => $user['role'],
            'access' => $user['Access']
        ]
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных: ' . $e->getMessage()
    ]);
}
?>