<?php
// Улучшенный скрипт для обновления курсов валют в базе данных
header('Content-Type: application/json; charset=utf-8');

// Подключение к базе данных
require_once 'config.php';

// Функция для логирования
function logMessage($message, $type = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $logEntry = "[$timestamp] [$type] $message" . PHP_EOL;
    
    // Создаем директорию logs если её нет
    if (!is_dir('logs')) {
        mkdir('logs', 0755, true);
    }
    
    file_put_contents('currency_update.log', $logEntry, FILE_APPEND | LOCK_EX);
}

try {
    logMessage("=== Начало обновления курсов валют ===");
    
    // Получаем данные с API
    $apiUrl = 'https://api.exchangerate-api.com/v4/latest/RUB';
    logMessage("Запрос к API: $apiUrl");
    
    $context = stream_context_create([
        'http' => [
            'timeout' => 10,
            'user_agent' => 'Currency Updater 1.0'
        ]
    ]);
    
    $response = file_get_contents($apiUrl, false, $context);
    
    if ($response === false) {
        throw new Exception('Не удалось получить данные с API');
    }
    
    $data = json_decode($response, true);
    
    if (!$data || !isset($data['rates'])) {
        throw new Exception('Неверный формат данных от API');
    }
    
    logMessage("Данные получены успешно. Курсы: USD=" . $data['rates']['USD'] . ", EUR=" . $data['rates']['EUR']);
    
    // Рассчитываем курсы (API возвращает курс RUB к другим валютам, нам нужно наоборот)
    $currencies = [
        'USD' => 1 / $data['rates']['USD'],
        'EUR' => 1 / $data['rates']['EUR']
    ];
    
    $updatedCurrencies = [];
    
    // Обновляем данные в базе
    foreach ($currencies as $code => $newRate) {
        logMessage("Обрабатываем валюту: $code, новый курс: $newRate");
        
        // Получаем текущий курс из базы
        $stmt = $pdo->prepare("SELECT current_rate, previous_rate FROM currency_rates WHERE currency_code = ?");
        $stmt->execute([$code]);
        $currentData = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($currentData) {
            $previousRate = $currentData['current_rate'];
            logMessage("Текущий курс в БД для $code: $previousRate");
        } else {
            $previousRate = $newRate;
            logMessage("Валюта $code не найдена в БД, создаем новую запись");
        }
        
        $rateChange = $newRate - $previousRate;
        $changePercentage = $previousRate != 0 ? ($rateChange / $previousRate) * 100 : 0;
        
        // Определяем тренд (порог 0.01 рубля для определения значимого изменения)
        $trend = 'neutral';
        if ($rateChange > 0.01) {
            $trend = 'up';
        } elseif ($rateChange < -0.01) {
            $trend = 'down';
        }
        
        logMessage("$code: изменение = $rateChange, процент = $changePercentage%, тренд = $trend");
        
        // Обновляем или вставляем данные
        $stmt = $pdo->prepare("
            INSERT INTO currency_rates (currency_code, current_rate, previous_rate, rate_change, change_percentage, trend) 
            VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                previous_rate = current_rate,
                current_rate = VALUES(current_rate),
                rate_change = VALUES(rate_change),
                change_percentage = VALUES(change_percentage),
                trend = VALUES(trend),
                last_updated = CURRENT_TIMESTAMP
        ");
        
        $stmt->execute([
            $code,
            round($newRate, 4),
            round($previousRate, 4),
            round($rateChange, 4),
            round($changePercentage, 2),
            $trend
        ]);
        
        $updatedCurrencies[$code] = [
            'current_rate' => round($newRate, 4),
            'previous_rate' => round($previousRate, 4),
            'rate_change' => round($rateChange, 4),
            'change_percentage' => round($changePercentage, 2),
            'trend' => $trend
        ];
        
        logMessage("Валюта $code успешно обновлена в БД");
    }
    
    logMessage("=== Обновление завершено успешно ===");
    
    $response = [
        'success' => true,
        'message' => 'Курсы валют успешно обновлены',
        'updated_currencies' => $updatedCurrencies,
        'timestamp' => date('Y-m-d H:i:s'),
        'api_timestamp' => $data['date'] ?? 'unknown'
    ];
    
    echo json_encode($response, JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    $errorMessage = $e->getMessage();
    logMessage("ОШИБКА: $errorMessage", 'ERROR');
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $errorMessage,
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
}
?>
