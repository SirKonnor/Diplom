<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($_SESSION['user_id']) || !$input || !isset($input['userId'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Unauthorized']));
}

try {
    // Получаем все диалоги пользователя с админами и помощниками
    $query = "SELECT 
              u.id as user_id,
              CONCAT(u.firstName, ' ', u.lastName) as user_name,
              u.role as support_role,
              u.avatar_path,
              (SELECT text FROM messages 
               WHERE ((sender_id = :userId AND receiver_id = u.id)
               OR (receiver_id = :userId AND sender_id = u.id))
               ORDER BY created_at DESC LIMIT 1) as last_message,
              COUNT(CASE WHEN m.is_read = 0 AND m.receiver_id = :userId THEN 1 END) as unread_count
              FROM user u
              LEFT JOIN messages m ON (m.sender_id = u.id AND m.receiver_id = :userId) 
                                   OR (m.receiver_id = u.id AND m.sender_id = :userId)
              WHERE u.role IN ('admin', 'helper')
              AND EXISTS (
                SELECT 1 FROM messages 
                WHERE (sender_id = :userId AND receiver_id = u.id)
                OR (receiver_id = :userId AND sender_id = u.id)
              )
              GROUP BY u.id";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':userId' => $input['userId']]);
    
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
