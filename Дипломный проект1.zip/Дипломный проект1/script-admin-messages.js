document.addEventListener('DOMContentLoaded', function() {
    const authData = JSON.parse(sessionStorage.getItem('auth')) || {};
    const conversationsList = document.querySelector('.conversations-list');
    const messagesBody = document.getElementById('messagesBody');
    const messageInput = document.getElementById('messageInput');
    const sendMessageBtn = document.getElementById('sendMessageBtn');
    const conversationTitle = document.getElementById('conversationTitle');
    const viewProfileBtn = document.getElementById('viewProfileBtn');
    const messageInputContainer = document.querySelector('.message-input');

    // Проверяем авторизацию и роль пользователя
    if (!authData.isAuthenticated || authData.user?.role !== 'admin') {
        // Проверяем сессию на сервере
        fetch('check-session.php', {
            method: 'GET',
            credentials: 'include'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.isAuthenticated && data.user && data.user.role === 'admin') {
                // Обновляем данные в sessionStorage
                const newAuthData = {
                    isAuthenticated: true,
                    user: data.user
                };
                sessionStorage.setItem('auth', JSON.stringify(newAuthData));
                
                // Продолжаем инициализацию
                initAdminMessages(data.user);
            } else {
                // Перенаправляем на страницу входа
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Ошибка при проверке сессии:', error);
            window.location.href = 'index.html';
        });
        return;
    }

    // Инициализация интерфейса администратора
    initAdminMessages(authData.user);

    // Функция инициализации интерфейса администратора
    function initAdminMessages(user) {
        let currentConversationId = null;
        let currentUserId = null;

        // Загрузка списка диалогов
        const loadConversations = async () => {
            try {
                const response = await fetch('get-admin-conversations.php', {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'Cache-Control': 'no-cache, no-store, must-revalidate',
                        'Pragma': 'no-cache',
                        'Expires': '0'
                    },
                    credentials: 'include'
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.success) {
                    displayConversations(data.conversations);
                } else {
                    console.error('Ошибка загрузки диалогов:', data.error);
                    conversationsList.innerHTML = `<p class="error">Ошибка загрузки диалогов: ${data.error}</p>`;
                }
            } catch (error) {
                console.error('Ошибка загрузки диалогов:', error);
                conversationsList.innerHTML = `<p class="error">Ошибка загрузки диалогов: ${error.message}</p>`;
            }
        };

        // Отображение списка диалогов
        const displayConversations = (conversations) => {
            conversationsList.innerHTML = '';
            
            if (conversations.length === 0) {
                conversationsList.innerHTML = '<p class="empty">Нет активных диалогов</p>';
                return;
            }
            
            conversations.forEach(conversation => {
                const conversationElement = document.createElement('div');
                conversationElement.className = 'conversation';
                conversationElement.dataset.userId = conversation.user_id;
                conversationElement.innerHTML = `
                    <div class="conversation-avatar">
                        <img src="${conversation.avatar_path || 'images/default-avatar.png'}" 
                             onerror="this.src='images/default-avatar.png'">
                    </div>
                    <div class="conversation-info">
                        <h4>${conversation.user_name}</h4>
                        <p class="last-message">${conversation.last_message || 'Нет сообщений'}</p>
                        ${conversation.unread_count > 0 ? 
                            `<span class="unread-count">${conversation.unread_count}</span>` : ''}
                    </div>
                `;
                
                conversationElement.addEventListener('click', () => {
                    openConversation(conversation.user_id, conversation.user_name);
                });
                
                conversationsList.appendChild(conversationElement);
            });
        };

        // Открытие диалога
        const openConversation = (userId, userName) => {
            currentConversationId = userId;
            currentUserId = userId;
            
            // Обновляем UI
            document.querySelectorAll('.conversation').forEach(c => {
                c.classList.remove('active');
                if (c.dataset.userId === userId) {
                    c.classList.add('active');
                }
            });
            
            conversationTitle.textContent = userName;
            viewProfileBtn.style.display = 'inline-block';
            messageInputContainer.style.display = 'flex';
            
            loadMessages(userId);
        };

        // Загрузка сообщений
        const loadMessages = async (userId) => {
            try {
                const response = await fetch('get-messages.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        conversationId: userId
                    }),
                    credentials: 'include'
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.success) {
                    displayMessages(data.messages);
                    markAsRead(userId);
                } else {
                    console.error('Ошибка загрузки сообщений:', data.error);
                    messagesBody.innerHTML = `<p class="error">Ошибка загрузки сообщений: ${data.error}</p>`;
                }
            } catch (error) {
                console.error('Ошибка загрузки сообщений:', error);
                messagesBody.innerHTML = `<p class="error">Ошибка загрузки сообщений: ${error.message}</p>`;
            }
        };

        // Отметка как прочитанные
        const markAsRead = async (userId) => {
            try {
                await fetch('mark-messages-read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        senderId: userId
                    }),
                    credentials: 'include'
                });
                
                // Обновляем счетчик непрочитанных сообщений
                if (window.notificationSystem) {
                    window.notificationSystem.fetchUnreadMessagesCount();
                }
            } catch (error) {
                console.error('Ошибка отметки сообщений:', error);
            }
        };

        // Отображение сообщений
        const displayMessages = (messages) => {
            messagesBody.innerHTML = '';
            
            if (messages.length === 0) {
                messagesBody.innerHTML = '<p class="empty-conversation">Нет сообщений в этом диалоге</p>';
                return;
            }
            
            messages.forEach(message => {
                const isOutgoing = message.sender_id == user.id;
                const messageElement = document.createElement('div');
                messageElement.className = `message ${isOutgoing ? 'message-outgoing' : 'message-incoming'}`;
                messageElement.innerHTML = `
                    <p>${message.text}</p>
                    <small>${new Date(message.created_at).toLocaleString()}</small>
                `;
                messagesBody.appendChild(messageElement);
            });
            
            messagesBody.scrollTop = messagesBody.scrollHeight;
        };

        // Отправка сообщения
        const sendMessage = async () => {
            const text = messageInput.value.trim();
            if (!text || !currentUserId) return;
            
            try {
                const response = await fetch('send-message.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        receiver_id: currentUserId,
                        text: text
                    }),
                    credentials: 'include'
                });
                
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                
                const data = await response.json();
                
                if (data.success) {
                    messageInput.value = '';
                    loadMessages(currentUserId);
                    loadConversations(); // Обновляем список диалогов
                } else {
                    console.error('Ошибка отправки сообщения:', data.error);
                    alert(`Ошибка отправки сообщения: ${data.error}`);
                }
            } catch (error) {
                console.error('Ошибка отправки сообщения:', error);
                alert(`Ошибка отправки сообщения: ${error.message}`);
            }
        };

        // Обработчики событий
        if (sendMessageBtn) {
            sendMessageBtn.addEventListener('click', sendMessage);
        }
        
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
        }
        
        if (viewProfileBtn) {
            viewProfileBtn.addEventListener('click', () => {
                if (currentUserId) {
                    window.location.href = `profile.html?userId=${currentUserId}`;
                }
            });
        }

        // Загрузка начальных данных
        loadConversations();
        
        // Периодическое обновление списка диалогов
        setInterval(loadConversations, 60000); // Обновляем каждую минуту
    }
});