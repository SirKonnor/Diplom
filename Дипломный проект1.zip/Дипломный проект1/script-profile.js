document.addEventListener("DOMContentLoaded", () => {
  const authData = JSON.parse(sessionStorage.getItem("auth")) || {}
  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // ДОБАВЛЯЕМ: Функция для обновления статуса пользователя
  const updateUserStatus = async (status) => {
    try {
      await fetch("update-user-status.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: authData.user.id,
          status: status,
        }),
      })
    } catch (error) {
      console.error("Ошибка обновления статуса:", error)
    }
  }

  // ДОБАВЛЯЕМ: Устанавливаем статус онлайн при загрузке страницы
  updateUserStatus("online")

  // ДОБАВЛЯЕМ: Интервал для поддержания статуса онлайн
  const statusUpdateInterval = setInterval(() => {
    updateUserStatus("online")
  }, 30000) // Каждые 30 секунд

  // ДОБАВЛЯЕМ: Обновляем статус при закрытии страницы
  window.addEventListener("beforeunload", () => {
    updateUserStatus("offline")
    if (statusUpdateInterval) clearInterval(statusUpdateInterval)
  })

  document.querySelectorAll("img").forEach((img) => {
    img.onerror = function () {
      if (this.classList.contains("user-avatar") || this.id === "avatarPreview") {
        this.src = "images/default-avatar.png"
      }
    }
  })

  const urlParams = new URLSearchParams(window.location.search)
  const viewedUserId = urlParams.get("userId")
  const isViewingOtherProfile = viewedUserId && viewedUserId !== authData.user?.id
  const userInfo = document.getElementById("userInfo")
  const contactInfo = document.getElementById("contactInfo")
  const logoutBtn = document.getElementById("logoutBtn")
  const sidebarBtns = document.querySelectorAll(".sidebar-btn")
  const editProfileBtn = document.querySelector(".edit-profile-btn")
  const adminUsersBtn = document.getElementById("adminUsersBtn")
  const modal = document.getElementById("editProfileModal")
  const closeModal = document.querySelector(".close-modal")
  const cancelBtn = document.querySelector(".cancel-btn")
  const userIcon = document.getElementById("user-icon")
  const changeAvatarBtn = document.getElementById("changeAvatarBtn")
  const avatarUpload = document.getElementById("avatarUpload")
  const profileEditForm = document.getElementById("profileEditForm")

  if (authData.user?.role === "admin" && adminUsersBtn) {
    adminUsersBtn.style.display = "block"
    adminUsersBtn.addEventListener("click", () => {
      window.location.href = "admin-users.html"
    })
  }

  // Функция для форматирования даты
  const formatDate = (dateStr) => {
    if (!dateStr) return "Не указана"
    const parts = dateStr.split("-")
    if (parts.length === 3) {
      return `${parts[2]}.${parts[1]}.${parts[0]}`
    }
    return dateStr
  }

  // Функция для обновления интерфейса
  const updateProfileUI = async (user) => {
    if (!user) return

    // Управление кнопками в зависимости от того, чей профиль просматриваем
    if (isViewingOtherProfile) {
      if (editProfileBtn) editProfileBtn.style.display = "none"

      // Удаляем старую кнопку сообщения, если есть
      const oldMessageBtn = document.getElementById("messageBtn")
      if (oldMessageBtn) oldMessageBtn.remove()

      // Создаем кнопку "Написать сообщение"
      const messageBtn = document.createElement("button")
      messageBtn.id = "messageBtn"
      messageBtn.className = "edit-profile-btn"
      messageBtn.innerHTML = '<i class="fas fa-envelope"></i> Написать сообщение'
      messageBtn.style.marginLeft = "10px"
      messageBtn.onclick = async () => {
        try {
          // Создаем диалог с пользователем
          const response = await fetch("create-conversations.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              sender_id: authData.user.id,
              receiver_id: user.id,
            }),
          })

          const data = await response.json()

          if (data.success) {
            // Сохраняем данные о пользователе, с которым нужно открыть диалог
            sessionStorage.setItem(
              "messageToUser",
              JSON.stringify({
                userId: user.id,
                userName: `${user.firstName} ${user.lastName}`,
                isNewConversation: data.isNewConversation,
              }),
            )
            window.location.href = "messages.html"
          } else {
            throw new Error(data.error || "Не удалось создать диалог")
          }
        } catch (error) {
          console.error("Ошибка создания диалога:", error)
          alert("Произошла ошибка при создании диалога: " + error.message)
        }
      }

      // Добавляем кнопку рядом с кнопкой редактирования
      if (editProfileBtn) {
        editProfileBtn.parentNode.insertBefore(messageBtn, editProfileBtn.nextSibling)
      } else {
        // Если кнопки редактирования нет (например, для админа)
        const header = document.querySelector(".main-content")
        if (header) header.prepend(messageBtn)
      }
    } else {
      if (editProfileBtn) editProfileBtn.style.display = "block"
      const messageBtn = document.getElementById("messageBtn")
      if (messageBtn) messageBtn.remove()
    }

    const createSocialLink = (icon, value, baseUrl = "") => {
      if (!value) return `<p><i class="${icon}"></i> Не указано</p>`

      let url = value
      if (baseUrl) {
        url = baseUrl + (value.startsWith("http") ? "" : value)
      }

      return `<p><a href="${url}" target="_blank" rel="noopener noreferrer">
                  <i class="${icon}"></i> ${value}
              </a></p>`
    }

    // ИСПРАВЛЕННАЯ функция для загрузки и отображения статуса пользователя
    const loadUserStatus = async (userId) => {
      try {
        // ИСПРАВЛЕНИЕ: Если это текущий пользователь, показываем "В сети"
        if (userId == authData.user.id) {
          return {
            success: true,
            status: "online",
            lastSeen: new Date().toISOString(),
          }
        }

        const response = await fetch("get-user-status.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            userId: userId,
          }),
        })

        const data = await response.json()
        return data.success ? data : { success: false, status: "offline", lastSeen: null }
      } catch (error) {
        console.error("Ошибка получения статуса:", error)
        return { success: false, status: "offline", lastSeen: null }
      }
    }

    // Функция для форматирования времени последнего посещения
    const formatLastSeen = (lastSeen) => {
      if (!lastSeen) return "Неизвестно"

      const lastSeenDate = new Date(lastSeen)
      const now = new Date()
      const diffMs = now - lastSeenDate
      const diffMins = Math.floor(diffMs / 60000)
      const diffHours = Math.floor(diffMins / 60)
      const diffDays = Math.floor(diffHours / 24)

      if (diffMins < 1) return "Только что"
      if (diffMins < 60) return `${diffMins} мин. назад`
      if (diffHours < 24) return `${diffHours} ч. назад`
      if (diffDays < 7) return `${diffDays} дн. назад`

      return lastSeenDate.toLocaleDateString()
    }

    // ИСПРАВЛЕННАЯ функция для получения текста статуса
    const getStatusText = (status, lastSeen, isCurrentUser = false) => {
      // ИСПРАВЛЕНИЕ: Для текущего пользователя всегда показываем "В сети"
      if (isCurrentUser) {
        return "В сети"
      }

      switch (status) {
        case "online":
          return "В сети"
        case "offline":
          return lastSeen ? `Был в сети ${formatLastSeen(lastSeen)}` : "Не в сети"
        default:
          return "Не в сети"
      }
    }

    // Загружаем и отображаем статус пользователя
    const statusData = await loadUserStatus(user.id)
    const isCurrentUser = user.id == authData.user.id
    const statusText = getStatusText(statusData.status, statusData.lastSeen, isCurrentUser)

    const userStatusHtml = `
      <div class="user-status-info">
        <div class="user-status-indicator ${statusData.status}">
          <span class="status-dot"></span>
          <span class="status-text">${statusText}</span>
        </div>
      </div>
    `

    if (userInfo) {
      userInfo.innerHTML = `
          <h2>${user.lastName} ${user.firstName}${user.middleName ? " " + user.middleName : ""}</h2>
          <div class="user-role ${user.role}">
              ${user.role === "admin" ? "Администратор" : user.role === "helper" ? "Поддержка" : "Пользователь"}
          </div>
          ${userStatusHtml}
          <div class="user-social-links">
              ${createSocialLink("fab fa-whatsapp", user.whatsapp_user, "https://wa.me/")}
              ${createSocialLink("fab fa-vk", user.vk_user, "https://vk.com/")}
              ${createSocialLink("fab fa-telegram", user.telegram_user, "https://t.me/")}
          </div>
      `
    }

    if (contactInfo) {
      contactInfo.innerHTML = `
                  <div class="info-item">
                      <h4>Телефон</h4>
                      <p>${user.phone || "Не указан"}</p>
                  </div>
                  <div class="info-item">
                      <h4>Email</h4>
                      <p>${user.email || "Не указан"}</p>
                  </div>
                  <div class="info-item">
                      <h4>Адрес</h4>
                      <p>${user.address || "Не указан"}</p>
                  </div>
                  <div class="info-item">
                      <h4>Дата регистрации</h4>
                      <p>${user.date_registration ? formatDate(user.date_registration) : "Не указана"}</p>
                  </div>
              `
    }

    // Обновляем аватар
    const avatarImg = document.querySelector(".user-avatar")
    if (avatarImg) {
      avatarImg.src = user.avatar_path || "images/default-avatar.png"
    }
  }

  // Функция для загрузки данных пользователя
  const loadUserData = async () => {
    try {
      let userData

      if (isViewingOtherProfile) {
        // Загружаем данные другого пользователя по ID
        const response = await fetch("get-user-data.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userId: viewedUserId }),
        })

        const data = await response.json()

        if (data.success) {
          userData = data.user
        } else {
          throw new Error(data.error || "User not found")
        }
      } else {
        // Загружаем данные текущего пользователя
        if (!authData.user?.email) {
          throw new Error("Email пользователя не найден")
        }

        const response = await fetch("get-user-data.php", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email: authData.user.email }),
        })

        const data = await response.json()

        if (data.success) {
          userData = {
            ...authData.user,
            ...data.user,
          }

          sessionStorage.setItem(
            "auth",
            JSON.stringify({
              isAuthenticated: true,
              user: userData,
            }),
          )
        } else {
          throw new Error(data.error || "Failed to load user data")
        }
      }

      updateProfileUI(userData)

      // Загружаем последний заказ после загрузки данных пользователя
      if (document.getElementById("ordersInfo")) {
        loadLastOrder(userData.id)
      }
    } catch (error) {
      console.error("Ошибка загрузки:", error)
      alert("Произошла ошибка при загрузке данных пользователя")

      // Если не удалось загрузить чужой профиль, перенаправляем на свой
      if (isViewingOtherProfile) {
        window.location.href = "profile.html"
      }
    }
  }

  // Загружаем данные пользователя
  loadUserData()

  // Добавим в обработчики событий после проверки авторизации
  if (authData.user?.role === "admin") {
    const adminUsersBtn = document.getElementById("adminUsersBtn")
    if (adminUsersBtn) {
      adminUsersBtn.addEventListener("click", () => {
        window.location.href = "admin-users.html"
      })
    }
  }

  // Обработчики событий
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      // ИСПРАВЛЕНИЕ: Обновляем статус на offline при выходе
      updateUserStatus("offline")
      sessionStorage.removeItem("auth")
      localStorage.removeItem("authEmail")
      window.location.href = "index.html"
    })
  }

  if (sidebarBtns) {
    sidebarBtns.forEach((btn) => {
      if (btn.id !== "logoutBtn") {
        btn.addEventListener("click", function () {
          sidebarBtns.forEach((b) => b.classList.remove("active"))
          this.classList.add("active")

          if (this.title === "Сообщения") {
            window.location.href = "messages.html"
          } else if (this.title === "Заказы") {
            window.location.href = "orders.html"
          }
        })
      }
    })
  }

  if (userIcon) {
    userIcon.href = "profile.html"
    userIcon.innerHTML = '<i class="fas fa-user-check"></i>'
  }

  // Модальное окно редактирования
  if (editProfileBtn && modal) {
    editProfileBtn.addEventListener("click", () => {
      modal.style.display = "block"
      document.getElementById("phone").value = authData.user.phone || ""
      document.getElementById("address").value = authData.user.address || ""

      // Показываем сохраненный аватар
      const avatarPreview = document.getElementById("avatarPreview")
      if (avatarPreview) {
        avatarPreview.src = authData.user.avatar_path || "images/default-avatar.png"
      }
    })
  }

  if (closeModal) {
    closeModal.addEventListener("click", () => {
      modal.style.display = "none"
    })
  }

  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => {
      modal.style.display = "none"
    })
  }

  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      modal.style.display = "none"
    }
  })

  // Обработчики для аватара
  if (changeAvatarBtn) {
    changeAvatarBtn.addEventListener("click", () => {
      document.getElementById("avatarUpload").click()
    })
  }

  if (avatarUpload) {
    avatarUpload.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        const reader = new FileReader()
        reader.onload = (event) => {
          const avatarPreview = document.getElementById("avatarPreview")
          if (avatarPreview) {
            avatarPreview.src = event.target.result
          }
        }
        reader.readAsDataURL(e.target.files[0])
      }
    })
  }

  // Обработчики для паролей
  document.querySelectorAll(".toggle-password").forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling
      if (input.type === "password") {
        input.type = "text"
        this.classList.replace("fa-eye", "fa-eye-slash")
      } else {
        input.type = "password"
        this.classList.replace("fa-eye-slash", "fa-eye")
      }
    })
  })

  const confirmPassword = document.getElementById("confirmPassword")
  if (confirmPassword) {
    confirmPassword.addEventListener("input", function () {
      const pass1 = document.getElementById("newPassword").value
      const pass2 = this.value
      const errorElement = document.getElementById("passwordError")

      if (pass1 && pass2 && pass1 !== pass2) {
        if (errorElement) errorElement.textContent = "Пароли не совпадают!"
      } else if (errorElement) {
        errorElement.textContent = ""
      }
    })
  }

  // Замените весь обработчик формы на:
  if (profileEditForm) {
    profileEditForm.addEventListener("submit", async function (e) {
      e.preventDefault()

      // Получаем все элементы формы
      const getElement = (id) => document.getElementById(id)

      const elements = {
        phone: getElement("phone"),
        email: getElement("email"),
        address: getElement("address"),
        whatsapp: getElement("whatsapp"),
        vk: getElement("vk"),
        telegram: getElement("telegram"),
        newPassword: getElement("newPassword"),
        confirmPassword: getElement("confirmPassword"),
        avatarPreview: getElement("avatarPreview"),
        submitBtn: this.querySelector('button[type="submit"]'),
      }

      // Проверка совпадения паролей
      if (elements.newPassword.value && elements.newPassword.value !== elements.confirmPassword.value) {
        alert("Пароли не совпадают!")
        return
      }

      // Сбор данных
      const formData = {
        phone: elements.phone.value,
        address: elements.address.value,
        middleName: elements.middleName.value || null,
        whatsapp: document.getElementById("whatsapp")?.value || null,
        vk: document.getElementById("vk")?.value || null,
        telegram: document.getElementById("telegram")?.value || null,
        avatar: elements.avatarPreview?.src,
        password: elements.newPassword?.value || null,
      }

      try {
        // Блокируем кнопку
        if (elements.submitBtn) {
          elements.submitBtn.disabled = true
          elements.submitBtn.textContent = "Сохранение..."
        }

        // Отправляем данные
        const response = await fetch("update-profile.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
        })

        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }

        const data = await response.json()
        console.log("Ответ сервера:", data)

        if (!data.success) {
          throw new Error(data.error || "Неизвестная ошибка сервера")
        }

        // Обновляем данные в sessionStorage
        const updatedUser = {
          ...authData.user,
          ...data.user,
          phone: formData.phone,
          email: formData.email,
          address: formData.address,
          whatsapp_user: formData.whatsapp,
          vk_user: formData.vk,
          telegram_user: formData.telegram,
        }

        sessionStorage.setItem(
          "auth",
          JSON.stringify({
            isAuthenticated: true,
            user: updatedUser,
          }),
        )

        updateProfileUI(updatedUser)
        alert("Изменения успешно сохранены!")
        modal.style.display = "none"
      } catch (error) {
        console.error("Ошибка сохранения:", error)
        alert(`Ошибка: ${error.message}`)
      } finally {
        if (elements.submitBtn) {
          elements.submitBtn.disabled = false
          elements.submitBtn.textContent = "Сохранить изменения"
        }
      }
    })
  }

  // Полностью переработанная функция загрузки последнего заказа
  async function loadLastOrder(userId) {
    const ordersInfo = document.getElementById("ordersInfo")
    if (!ordersInfo) return

    // Проверяем авторизацию
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    if (!authData.isAuthenticated) {
      ordersInfo.innerHTML = "<p>Необходимо авторизоваться для просмотра заказов</p>"
      return
    }

    // Определяем, чей профиль просматривается
    const urlParams = new URLSearchParams(window.location.search)
    const viewedUserId = urlParams.get("userId")
    const isViewingOtherProfile = viewedUserId && viewedUserId !== authData.user?.id

    // Используем ID пользователя, переданный в функцию, или ID из URL, или ID текущего пользователя
    const targetUserId = userId || viewedUserId || authData.user.id

    console.log("loadLastOrder: Loading order for user ID:", targetUserId)
    console.log("loadLastOrder: Current user ID:", authData.user.id)
    console.log("loadLastOrder: Is viewing other profile:", isViewingOtherProfile)

    try {
      // Показываем индикатор загрузки
      ordersInfo.innerHTML = `
      <div class="loading-indicator">
        <i class="fas fa-spinner fa-spin"></i>
        <span>Загрузка информации о заказах...</span>
      </div>
    `

      // Отправляем запрос на сервер
      const response = await fetch("get-last-order.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: targetUserId,
        }),
      })

      // Проверяем статус ответа
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      // Парсим ответ
      let data
      try {
        const text = await response.text()
        console.log("loadLastOrder: Raw response:", text)
        data = JSON.parse(text)
      } catch (parseError) {
        console.error("Failed to parse JSON:", parseError)
        throw new Error("Сервер вернул некорректный ответ. Пожалуйста, обратитесь к администратору.")
      }

      console.log("loadLastOrder: Parsed response:", data)

      // Проверяем успешность запроса и наличие заказа
      if (data.success) {
        if (data.order) {
          console.log("loadLastOrder: Order found:", data.order)
          displayLastOrder(data.order, data.dateColumn)
        } else {
          console.log("loadLastOrder: No orders found for user ID:", targetUserId)
          // Показываем сообщение в зависимости от того, чей профиль просматривается
          if (isViewingOtherProfile) {
            ordersInfo.innerHTML = `
            <div class="empty-orders">
              <i class="fas fa-inbox"></i>
              <p>У пользователя пока нет заказов</p>
            </div>
          `
          } else {
            ordersInfo.innerHTML = `
            <div class="empty-orders">
              <i class="fas fa-inbox"></i>
              <p>У вас пока нет заказов</p>
              <a href="index.html#fuel-section" class="btn-main">
                <i class="fas fa-gas-pump"></i> Заказать топливо
              </a>
            </div>
          `
          }
        }
      } else {
        throw new Error(data.error || "Неизвестная ошибка при загрузке заказов")
      }
    } catch (error) {
      console.error("Ошибка загрузки последнего заказа:", error)
      ordersInfo.innerHTML = `
      <div class="error-message">
        <i class="fas fa-exclamation-triangle"></i>
        <p>Не удалось загрузить информацию о заказах: ${error.message}</p>
        <button onclick="loadLastOrder('${targetUserId}')" class="retry-btn">
          <i class="fas fa-sync-alt"></i> Попробовать снова
        </button>
      </div>
    `
    }
  }

  // Функция для отображения последнего заказа в компактном формате
  function displayLastOrder(order, dateColumn) {
    const ordersInfo = document.getElementById("ordersInfo")
    if (!ordersInfo) return

    // Определяем, какое поле даты использовать
    const dateField =
      order["created_at"] || order["date_created"] || order["order_date"] || order["date"] || order["timestamp"]

    // Форматируем дату, если она существует
    let formattedDate = "Не указана"
    let formattedTime = ""
    if (dateField) {
      const orderDate = new Date(dateField)
      formattedDate = orderDate.toLocaleDateString("ru-RU")
      formattedTime = orderDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
    }

    // Форматируем цены
    const pricePerLiter = Number.parseFloat(order.price_per_liter || 0)
    const totalPrice = Number.parseFloat(order.total_price || 0)
    const quantity = Number.parseInt(order.quantity || 0)

    const formattedPrice = pricePerLiter.toFixed(2).replace(".", ",")
    const formattedTotal = totalPrice.toFixed(2).replace(".", ",")

    // Получаем информацию о статусе
    const statusInfo = getStatusInfo(order.status)

    // Создаем элемент заказа с той же структурой, что и на странице заказов
    const orderElement = document.createElement("div")
    orderElement.className = `order-card ${order.status === "PENDING" ? "new-order" : ""}`

    // Заполняем содержимое элемента
    orderElement.innerHTML = `
    <div class="order-header">
      <h4><i class="fas fa-file-invoice"></i> Заказ <span class="order-id">#${order.id}</span></h4>
      <span class="order-status ${statusInfo.class}">
        <i class="${statusInfo.icon}"></i> ${statusInfo.text}
      </span>
    </div>
    
    <div class="order-content">
      <div class="order-detail">
        <span class="order-detail-label">Дата заказа</span>
        <span class="order-detail-value">
          <i class="fas fa-calendar-alt"></i> ${formattedDate}
          ${formattedTime ? `<small>${formattedTime}</small>` : ""}
        </span>
      </div>
      
      <div class="order-detail">
        <span class="order-detail-label">Топливо</span>
        <span class="order-detail-value">
          <i class="fas fa-gas-pump"></i> ${order.fuel_name || "Не указано"}
        </span>
      </div>
      
      <div class="order-detail">
        <span class="order-detail-label">Количество</span>
        <span class="order-detail-value">
          <i class="fas fa-tachometer-alt"></i> ${quantity} л
        </span>
      </div>
      
      <div class="order-detail">
        <span class="order-detail-label">Стоимость</span>
        <span class="order-detail-value">
          <i class="fas fa-ruble-sign"></i> ${formattedTotal} ₽
        </span>
      </div>
    </div>
    
    <div class="order-footer">
      <div class="order-delivery">
        <span class="order-detail-label">Доставка</span>
        <span class="order-detail-value">
          <i class="fas fa-truck"></i> ${order.delivery_date || "Не указана"}, 
          ${order.delivery_time || ""}
        </span>
      </div>
      
      <div class="order-actions">
        <a href="orders.html" class="order-action-btn">
          <i class="fas fa-info-circle"></i> Подробнее
        </a>
      </div>
    </div>
  `

    // Очищаем контейнер и добавляем элемент заказа
    ordersInfo.innerHTML = ""
    ordersInfo.appendChild(orderElement)
  }

  // Функция для получения информации о статусе заказа
  function getStatusInfo(status) {
    switch (status) {
      case "PENDING":
        return {
          class: "pending",
          text: "В обработке",
          icon: "fas fa-clock",
        }
      case "CONFIRMED":
        return {
          class: "confirmed",
          text: "Подтвержден",
          icon: "fas fa-check-circle",
        }
      case "DELIVERED":
        return {
          class: "delivered",
          text: "Доставлен",
          icon: "fas fa-truck-loading",
        }
      case "CANCELLED":
        return {
          class: "cancelled",
          text: "Отменен",
          icon: "fas fa-ban",
        }
      default:
        return {
          class: "pending",
          text: "В обработке",
          icon: "fas fa-clock",
        }
    }
  }
})
