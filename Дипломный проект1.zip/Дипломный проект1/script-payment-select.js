document.addEventListener("DOMContentLoaded", () => {
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // Получаем ID заказа из URL
  const urlParams = new URLSearchParams(window.location.search)
  const orderId = urlParams.get("orderId")

  if (!orderId) {
    alert("Не указан ID заказа")
    window.location.href = "orders.html"
    return
  }

  const orderSummary = document.getElementById("order-summary")
  const paymentMethods = document.getElementById("payment-methods")
  const payButton = document.getElementById("pay-button")
  const paymentLoading = document.getElementById("payment-loading")

  let selectedPaymentSystem = null
  let orderData = null

  // Загружаем информацию о заказе
  loadOrderInfo()

  // Загружаем доступные способы оплаты
  loadPaymentMethods()

  // Обработчик кнопки оплаты
  payButton.addEventListener("click", processPayment)

  async function loadOrderInfo() {
    try {
      const response = await fetch("get-order-details.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          userId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success && data.order) {
        orderData = data.order
        displayOrderSummary(data.order)
      } else {
        throw new Error(data.error || "Не удалось загрузить информацию о заказе")
      }
    } catch (error) {
      console.error("Ошибка загрузки заказа:", error)
      orderSummary.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Ошибка загрузки заказа: ${error.message}</p>
                </div>
            `
    }
  }

  function displayOrderSummary(order) {
    const totalPrice = Number.parseFloat(order.total_price || 0)
    const quantity = Number.parseInt(order.quantity || 0)
    const pricePerLiter = Number.parseFloat(order.price_per_liter || 0)

    orderSummary.innerHTML = `
            <h3><i class="fas fa-file-invoice"></i> Заказ #${order.id}</h3>
            <div class="summary-item">
                <span>Топливо:</span>
                <span>${order.fuel_name || "Не указано"}</span>
            </div>
            <div class="summary-item">
                <span>Количество:</span>
                <span>${quantity} л</span>
            </div>
            <div class="summary-item">
                <span>Цена за литр:</span>
                <span>${pricePerLiter.toFixed(2)} ₽</span>
            </div>
            <div class="summary-item">
                <span>Дата доставки:</span>
                <span>${order.delivery_date || "Не указана"}</span>
            </div>
            <div class="summary-item">
                <span>Время доставки:</span>
                <span>${order.delivery_time || "Не указано"}</span>
            </div>
            <div class="summary-item">
                <span>К оплате:</span>
                <span>${totalPrice.toFixed(2)} ₽</span>
            </div>
        `
  }

  async function loadPaymentMethods() {
    try {
      const response = await fetch("get-payment-methods.php")
      const data = await response.json()

      if (data.success && data.methods) {
        displayPaymentMethods(data.methods)
        paymentMethods.style.display = "grid"
      } else {
        throw new Error(data.error || "Не удалось загрузить способы оплаты")
      }
    } catch (error) {
      console.error("Ошибка загрузки способов оплаты:", error)
      paymentMethods.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Ошибка загрузки способов оплаты: ${error.message}</p>
                </div>
            `
      paymentMethods.style.display = "block"
    }
  }

  function displayPaymentMethods(methods) {
    paymentMethods.innerHTML = ""

    Object.keys(methods).forEach((key) => {
      const method = methods[key]
      if (!method.enabled) return

      const methodElement = document.createElement("div")
      methodElement.className = "payment-method"
      methodElement.innerHTML = `
                <input type="radio" name="payment-method" value="${key}" id="payment-${key}">
                <div class="payment-icon">
                    <i class="${method.icon}"></i>
                </div>
                <div class="payment-info">
                    <h4>${method.name}</h4>
                    <p>${method.description}</p>
                </div>
            `

      methodElement.addEventListener("click", () => {
        // Убираем выделение с других методов
        document.querySelectorAll(".payment-method").forEach((el) => {
          el.classList.remove("selected")
        })

        // Выделяем выбранный метод
        methodElement.classList.add("selected")
        document.getElementById(`payment-${key}`).checked = true
        selectedPaymentSystem = key

        // Активируем кнопку оплаты
        payButton.disabled = false
      })

      paymentMethods.appendChild(methodElement)
    })
  }

  async function processPayment() {
    if (!selectedPaymentSystem) {
      alert("Пожалуйста, выберите способ оплаты")
      return
    }

    if (!orderData) {
      alert("Информация о заказе не загружена")
      return
    }

    // Проверяем, не оплачен ли уже заказ
    if (orderData.is_paid) {
      alert("Заказ уже оплачен")
      window.location.href = "orders.html"
      return
    }

    try {
      // Показываем индикатор загрузки
      paymentLoading.style.display = "block"
      payButton.disabled = true

      const response = await fetch("process-payment.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId: orderId,
          paymentSystem: selectedPaymentSystem,
          returnUrl: `${window.location.origin}/payment-success.html?orderId=${orderId}`,
        }),
      })

      const data = await response.json()

      if (data.success && data.payment_url) {
        // Сохраняем информацию о платеже в sessionStorage
        sessionStorage.setItem(
          "currentPayment",
          JSON.stringify({
            orderId: orderId,
            paymentId: data.payment_id,
            paymentSystem: selectedPaymentSystem,
          }),
        )

        // Перенаправляем на страницу оплаты
        window.location.href = data.payment_url
      } else {
        throw new Error(data.message || data.error || "Ошибка создания платежа")
      }
    } catch (error) {
      console.error("Ошибка обработки платежа:", error)
      alert("Ошибка при создании платежа: " + error.message)

      // Скрываем индикатор загрузки
      paymentLoading.style.display = "none"
      payButton.disabled = false
    }
  }

  // Мобильное меню
  const mobileToggle = document.querySelector(".mobile-menu-toggle")
  const menu = document.querySelector("#menu")

  if (mobileToggle && menu) {
    mobileToggle.addEventListener("click", () => {
      const isActive = menu.classList.contains("active")

      menu.classList.toggle("active")
      mobileToggle.classList.toggle("active")
      mobileToggle.setAttribute("aria-expanded", !isActive)

      document.body.style.overflow = isActive ? "" : "hidden"
    })

    menu.addEventListener("click", (e) => {
      if (e.target.tagName === "A") {
        menu.classList.remove("active")
        mobileToggle.classList.remove("active")
        mobileToggle.setAttribute("aria-expanded", "false")
        document.body.style.overflow = ""
      }
    })

    window.addEventListener("resize", () => {
      if (window.innerWidth > 768) {
        menu.classList.remove("active")
        mobileToggle.classList.remove("active")
        mobileToggle.setAttribute("aria-expanded", "false")
        document.body.style.overflow = ""
      }
    })
  }
})
