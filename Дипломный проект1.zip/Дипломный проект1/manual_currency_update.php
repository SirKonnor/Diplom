<?php
// Скрипт для ручного обновления курсов валют через веб-интерфейс
session_start();

// Простая защита (можно улучшить)
$allowed_ips = ['127.0.0.1', '::1', 'localhost'];
$client_ip = $_SERVER['REMOTE_ADDR'] ?? '';

if (!in_array($client_ip, $allowed_ips) && !isset($_SESSION['admin_logged_in'])) {
    http_response_code(403);
    die('Доступ запрещен');
}

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управление курсами валют</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .btn {
            background: #007bff;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin: 10px 5px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn.danger {
            background: #dc3545;
        }
        .btn.danger:hover {
            background: #c82333;
        }
        .status {
            padding: 15px;
            margin: 15px 0;
            border-radius: 5px;
            font-weight: bold;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        .currency-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        .currency-table th,
        .currency-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .currency-table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }
        .trend-up {
            color: #28a745;
        }
        .trend-down {
            color: #dc3545;
        }
        .trend-neutral {
            color: #6c757d;
        }
        .log-container {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            max-height: 300px;
            overflow-y: auto;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏦 Управление курсами валют</h1>
        
        <div class="info">
            <strong>ℹ️ Информация:</strong> Эта страница позволяет вручную обновить курсы валют и просмотреть текущее состояние.
        </div>

        <div>
            <button class="btn" onclick="updateCurrencies()">🔄 Обновить курсы сейчас</button>
            <button class="btn" onclick="loadCurrentRates()">📊 Показать текущие курсы</button>
            <button class="btn" onclick="loadLogs()">📋 Показать логи</button>
            <button class="btn danger" onclick="clearLogs()">🗑️ Очистить логи</button>
        </div>

        <div id="status"></div>
        <div id="results"></div>
        <div id="logs"></div>
    </div>

    <script>
        async function updateCurrencies() {
            const statusDiv = document.getElementById('status');
            const resultsDiv = document.getElementById('results');
            
            statusDiv.innerHTML = '<div class="info">⏳ Обновление курсов валют...</div>';
            resultsDiv.innerHTML = '';
            
            try {
                const response = await fetch('update_currency_rates.php');
                const data = await response.json();
                
                if (data.success) {
                    statusDiv.innerHTML = '<div class="success">✅ Курсы валют успешно обновлены!</div>';
                    
                    let html = '<h3>📈 Результаты обновления:</h3>';
                    html += '<table class="currency-table">';
                    html += '<tr><th>Валюта</th><th>Текущий курс</th><th>Предыдущий курс</th><th>Изменение</th><th>Процент</th><th>Тренд</th></tr>';
                    
                    for (const [currency, info] of Object.entries(data.updated_currencies)) {
                        const trendClass = `trend-${info.trend}`;
                        const trendIcon = info.trend === 'up' ? '📈' : info.trend === 'down' ? '📉' : '➡️';
                        const changeSign = info.rate_change > 0 ? '+' : '';
                        
                        html += `<tr>
                            <td><strong>${currency}</strong></td>
                            <td>${info.current_rate} ₽</td>
                            <td>${info.previous_rate} ₽</td>
                            <td class="${trendClass}">${changeSign}${info.rate_change}</td>
                            <td class="${trendClass}">${changeSign}${info.change_percentage}%</td>
                            <td class="${trendClass}">${trendIcon} ${info.trend}</td>
                        </tr>`;
                    }
                    
                    html += '</table>';
                    html += `<p><small>🕒 Обновлено: ${data.timestamp}</small></p>`;
                    
                    resultsDiv.innerHTML = html;
                } else {
                    statusDiv.innerHTML = `<div class="error">❌ Ошибка: ${data.error}</div>`;
                }
            } catch (error) {
                statusDiv.innerHTML = `<div class="error">❌ Ошибка сети: ${error.message}</div>`;
            }
        }

        async function loadCurrentRates() {
            const resultsDiv = document.getElementById('results');
            
            try {
                const response = await fetch('get_currency_rates.php');
                const data = await response.json();
                
                if (data.success) {
                    let html = '<h3>💰 Текущие курсы валют:</h3>';
                    html += '<table class="currency-table">';
                    html += '<tr><th>Валюта</th><th>Курс</th><th>Изменение</th><th>Тренд</th><th>Последнее обновление</th></tr>';
                    
                    for (const [currency, info] of Object.entries(data.data)) {
                        const trendClass = `trend-${info.trend}`;
                        const trendIcon = info.trend === 'up' ? '📈' : info.trend === 'down' ? '📉' : '➡️';
                        const changeSign = parseFloat(info.change) > 0 ? '+' : '';
                        
                        html += `<tr>
                            <td><strong>${currency.toUpperCase()}</strong></td>
                            <td>${info.rate} ₽</td>
                            <td class="${trendClass}">${changeSign}${info.change}</td>
                            <td class="${trendClass}">${trendIcon} ${info.trend}</td>
                            <td>${info.last_updated}</td>
                        </tr>`;
                    }
                    
                    html += '</table>';
                    resultsDiv.innerHTML = html;
                } else {
                    resultsDiv.innerHTML = `<div class="error">❌ Ошибка загрузки: ${data.error}</div>`;
                }
            } catch (error) {
                resultsDiv.innerHTML = `<div class="error">❌ Ошибка сети: ${error.message}</div>`;
            }
        }

        async function loadLogs() {
            const logsDiv = document.getElementById('logs');
            
            try {
                const response = await fetch('get_currency_logs.php');
                const text = await response.text();
                
                logsDiv.innerHTML = '<h3>📋 Логи обновления:</h3><div class="log-container">' + 
                    (text || 'Логи пусты') + '</div>';
            } catch (error) {
                logsDiv.innerHTML = `<div class="error">❌ Ошибка загрузки логов: ${error.message}</div>`;
            }
        }

        async function clearLogs() {
            if (!confirm('Вы уверены, что хотите очистить логи?')) {
                return;
            }
            
            try {
                const response = await fetch('clear_currency_logs.php', { method: 'POST' });
                const data = await response.json();
                
                if (data.success) {
                    document.getElementById('status').innerHTML = '<div class="success">✅ Логи очищены</div>';
                    document.getElementById('logs').innerHTML = '';
                } else {
                    document.getElementById('status').innerHTML = `<div class="error">❌ Ошибка: ${data.error}</div>`;
                }
            } catch (error) {
                document.getElementById('status').innerHTML = `<div class="error">❌ Ошибка: ${error.message}</div>`;
            }
        }

        // Автоматически загружаем текущие курсы при загрузке страницы
        window.onload = function() {
            loadCurrentRates();
        };
    </script>
</body>
</html>
