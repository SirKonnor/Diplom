<?php
header('Content-Type: application/json');

require_once 'config.php';
require_once 'payment-config.php';

// Логирование для отладки
function logPaymentNotification($message) {
    $logFile = 'payment_notifications.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
}

// Получаем данные уведомления
$input = file_get_contents('php://input');
$headers = getallheaders();

logPaymentNotification("Received notification: " . $input);
logPaymentNotification("Headers: " . json_encode($headers));

// Определяем платежную систему по заголовкам или содержимому
$paymentSystem = null;

if (isset($headers['User-Agent']) && strpos($headers['User-Agent'], 'YooKassa') !== false) {
    $paymentSystem = 'yukassa';
} elseif (isset($headers['User-Agent']) && strpos($headers['User-Agent'], 'Sberbank') !== false) {
    $paymentSystem = 'sberbank';
} elseif (isset($headers['User-Agent']) && strpos($headers['User-Agent'], 'Tinkoff') !== false) {
    $paymentSystem = 'tinkoff';
}

// Парсим данные уведомления
$notificationData = json_decode($input, true);

if (!$notificationData) {
    // Возможно, данные пришли в формате form-data
    $notificationData = $_POST;
}

logPaymentNotification("Parsed data: " . json_encode($notificationData));

try {
    switch ($paymentSystem) {
        case 'yukassa':
            handleYuKassaNotification($notificationData);
            break;
            
        case 'sberbank':
            handleSberbankNotification($notificationData);
            break;
            
        case 'tinkoff':
            handleTinkoffNotification($notificationData);
            break;
            
        default:
            // Пытаемся определить систему по данным
            if (isset($notificationData['event']) && isset($notificationData['object'])) {
                handleYuKassaNotification($notificationData);
            } elseif (isset($notificationData['orderNumber']) && isset($notificationData['operation'])) {
                handleSberbankNotification($notificationData);
            } elseif (isset($notificationData['TerminalKey']) && isset($notificationData['Status'])) {
                handleTinkoffNotification($notificationData);
            } else {
                throw new Exception('Unknown payment system');
            }
            break;
    }
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    logPaymentNotification("Error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function handleYuKassaNotification($data) {
    global $pdo;
    
    if (!isset($data['event']) || !isset($data['object'])) {
        throw new Exception('Invalid YuKassa notification format');
    }
    
    $event = $data['event'];
    $payment = $data['object'];
    
    if ($event === 'payment.succeeded') {
        $paymentId = $payment['id'];
        $orderId = $payment['metadata']['order_id'] ?? null;
        
        if ($orderId) {
            updateOrderPaymentStatus($orderId, 'paid', $paymentId);
            logPaymentNotification("YuKassa payment succeeded for order $orderId");
        }
    } elseif ($event === 'payment.canceled') {
        $paymentId = $payment['id'];
        $orderId = $payment['metadata']['order_id'] ?? null;
        
        if ($orderId) {
            updateOrderPaymentStatus($orderId, 'cancelled', $paymentId);
            logPaymentNotification("YuKassa payment cancelled for order $orderId");
        }
    }
}

function handleSberbankNotification($data) {
    global $pdo;
    
    if (!isset($data['orderNumber']) || !isset($data['operation'])) {
        throw new Exception('Invalid Sberbank notification format');
    }
    
    $orderNumber = $data['orderNumber'];
    $operation = $data['operation'];
    
    // Извлекаем ID заказа из номера заказа
    if (preg_match('/ORDER_(\d+)_/', $orderNumber, $matches)) {
        $orderId = $matches[1];
        
        if ($operation === 'deposited') {
            updateOrderPaymentStatus($orderId, 'paid', $orderNumber);
            logPaymentNotification("Sberbank payment succeeded for order $orderId");
        } elseif ($operation === 'declined') {
            updateOrderPaymentStatus($orderId, 'cancelled', $orderNumber);
            logPaymentNotification("Sberbank payment declined for order $orderId");
        }
    }
}

function handleTinkoffNotification($data) {
    global $pdo;
    
    if (!isset($data['OrderId']) || !isset($data['Status'])) {
        throw new Exception('Invalid Tinkoff notification format');
    }
    
    $orderNumber = $data['OrderId'];
    $status = $data['Status'];
    
    // Извлекаем ID заказа из номера заказа
    if (preg_match('/ORDER_(\d+)_/', $orderNumber, $matches)) {
        $orderId = $matches[1];
        
        if ($status === 'CONFIRMED') {
            updateOrderPaymentStatus($orderId, 'paid', $data['PaymentId'] ?? $orderNumber);
            logPaymentNotification("Tinkoff payment confirmed for order $orderId");
        } elseif ($status === 'REJECTED') {
            updateOrderPaymentStatus($orderId, 'cancelled', $data['PaymentId'] ?? $orderNumber);
            logPaymentNotification("Tinkoff payment rejected for order $orderId");
        }
    }
}

function updateOrderPaymentStatus($orderId, $status, $paymentId) {
    global $pdo;
    
    try {
        $isPaid = ($status === 'paid') ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE orders SET is_paid = :is_paid, payment_status = :status WHERE id = :order_id");
        $stmt->execute([
            'is_paid' => $isPaid,
            'status' => $status,
            'order_id' => $orderId
        ]);
        
        logPaymentNotification("Updated order $orderId: is_paid=$isPaid, status=$status");
        
    } catch (PDOException $e) {
        logPaymentNotification("Database error updating order $orderId: " . $e->getMessage());
        throw new Exception('Database error: ' . $e->getMessage());
    }
}
?>
