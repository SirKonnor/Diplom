<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'chat_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));
logError("POST data: " . file_get_contents('php://input'));

$input = json_decode(file_get_contents('php://input'), true);

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку с кодом 200 вместо 401
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'debug' => [
            'session' => $_SESSION
        ]
    ]);
    exit;
}

// Проверяем наличие необходимых параметров в запросе
if (!$input || !isset($input['senderId'])) {
    logError("Missing required parameters. Input: " . json_encode($input));
    echo json_encode([
        'success' => false, 
        'error' => 'Отсутствуют необходимые параметры'
    ]);
    exit;
}

try {
    // Проверяем существование таблицы messages
    $tableCheckStmt = $pdo->query("SHOW TABLES LIKE 'messages'");
    if ($tableCheckStmt->rowCount() === 0) {
        // Таблица не существует, возвращаем успех (нечего отмечать)
        echo json_encode(['success' => true]);
        exit;
    }
    
    $senderId = $input['senderId'];
    
    // Если отправитель "support", находим ID помощника
    if ($senderId === 'support') {
        $query = "SELECT id FROM user WHERE role = 'helper' OR role = 'admin' ORDER BY role = 'helper' DESC, id ASC LIMIT 1";
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($admin) {
            $senderId = $admin['id'];
        } else {
            throw new Exception('Администратор не найден');
        }
    }
    
    // Отмечаем сообщения как прочитанные
    $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE sender_id = :sender_id AND receiver_id = :receiver_id AND is_read = 0");
    $stmt->execute([
        ':sender_id' => $senderId,
        ':receiver_id' => $userId
    ]);
    
    echo json_encode([
        'success' => true,
        'updated_count' => $stmt->rowCount()
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>