<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['userId']) || empty($data['userId'])) {
        throw new Exception('User ID is required');
    }
    
    $userId = $data['userId'];
    
    // Check if user is admin
    $isAdmin = isset($data['isAdmin']) ? $data['isAdmin'] : false;
    
    // Optional pagination parameters
    $page = isset($data['page']) ? intval($data['page']) : 1;
    $limit = isset($data['limit']) ? intval($data['limit']) : 10;
    $offset = ($page - 1) * $limit;
    
    // Optional filter parameters
    $status = isset($data['status']) ? $data['status'] : null;
    $dateFrom = isset($data['dateFrom']) ? $data['dateFrom'] : null;
    $dateTo = isset($data['dateTo']) ? $data['dateTo'] : null;
    $search = isset($data['search']) ? $data['search'] : null;
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Database query
try {
    // Check if orders table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Orders table does not exist');
    }
    
    // Get the table structure to find the date column
    $stmt = $pdo->query("DESCRIBE orders");
    $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Look for possible date columns
    $dateColumn = null;
    $possibleDateColumns = ['created_at', 'date_created', 'order_date', 'date', 'timestamp'];
    
    foreach ($possibleDateColumns as $column) {
        if (in_array($column, $columns)) {
            $dateColumn = $column;
            break;
        }
    }
    
    // If no date column found, use the ID column for ordering
    if (!$dateColumn) {
        $dateColumn = 'id';
    }
    
    // Build the query
    $query = "SELECT * FROM orders";
    $params = [];
    
    // If user is admin and no search is provided, show all orders
    // Otherwise, filter by user ID
    if (!$isAdmin) {
        $query .= " WHERE user_id = :userId";
        $params['userId'] = $userId;
    } else {
        // For admin, we can either show all or filter by search
        if ($search) {
            // We need to join with users table to search by user name
            $query = "SELECT o.* FROM orders o LEFT JOIN user u ON o.user_id = u.id WHERE 1=1";
            
            // Add search conditions - now searching by user ID instead of address
            $query .= " AND (o.id LIKE :search OR o.user_id LIKE :search OR u.firstName LIKE :search OR u.lastName LIKE :search OR u.email LIKE :search)";
            $params['search'] = "%{$search}%";
        } else {
            $query .= " WHERE 1=1"; // Always true condition for consistent query structure
        }
    }
    
    // Add filters if provided
    if ($status) {
        $query .= " AND status = :status";
        $params['status'] = $status;
    }
    
    if ($dateFrom && $dateColumn) {
        $query .= " AND $dateColumn >= :dateFrom";
        $params['dateFrom'] = $dateFrom;
    }
    
    if ($dateTo && $dateColumn) {
        $query .= " AND $dateColumn <= :dateTo";
        $params['dateTo'] = $dateTo . ' 23:59:59'; // Include the entire day
    }
    
    // Count total records for pagination
    $countQuery = str_replace("SELECT o.*", "SELECT COUNT(*)", $query);
    $countQuery = str_replace("SELECT *", "SELECT COUNT(*)", $countQuery);
    
    $countStmt = $pdo->prepare($countQuery);
    foreach ($params as $key => $value) {
        $countStmt->bindValue(":$key", $value);
    }
    $countStmt->execute();
    $totalOrders = $countStmt->fetchColumn();
    
    // Add ordering
    $query .= " ORDER BY $dateColumn DESC";
    
    // Add pagination
    $query .= " LIMIT :offset, :limit";
    
    // Execute the query
    $stmt = $pdo->prepare($query);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    
    // Bind pagination parameters
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate pagination info
    $totalPages = ceil($totalOrders / $limit);
    
    echo json_encode([
        'success' => true,
        'orders' => $orders,
        'pagination' => [
            'page' => $page,
            'limit' => $limit,
            'totalOrders' => $totalOrders,
            'totalPages' => $totalPages
        ],
        'dateColumn' => $dateColumn
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
