// Глобальные функции для работы с заказами топлива
window.openOrderModal = async (fuelId, fuelName, fuelPrice) => {
  // Проверяем авторизацию пользователя
  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")

  if (!authData.isAuthenticated) {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    alert("Для заказа топлива необходимо авторизоваться")
    window.location.href = "login.html"
    return
  }

  // Проверяем, существует ли модальное окно и форма
  const modal = document.getElementById("orderModal")
  const orderForm = document.getElementById("orderForm")

  if (!modal || !orderForm) {
    console.error("Модальное окно или форма заказа не найдены")
    alert("Произошла ошибка при открытии формы заказа. Пожалуйста, обновите страницу.")
    return
  }

  // Заполняем поля формы данными о выбранном топливе
  const fuelIdInput = document.getElementById("fuel_id")
  const fuelNameInput = document.getElementById("fuel_name")
  const fuelPriceInput = document.getElementById("fuel_price")

  if (fuelIdInput) fuelIdInput.value = fuelId
  if (fuelNameInput) fuelNameInput.value = fuelName
  if (fuelPriceInput) fuelPriceInput.value = fuelPrice + " ₽/л"

  // Устанавливаем значение по умолчанию для количества
  const quantityInput = document.getElementById("quantity")
  if (quantityInput) quantityInput.value = 100

  // Рассчитываем итоговую стоимость
  const totalPriceInput = document.getElementById("total_price")
  if (quantityInput && totalPriceInput) {
    const quantity = Number.parseInt(quantityInput.value) || 0
    const priceValue = Number.parseFloat(fuelPrice)
    const total = quantity * priceValue
    totalPriceInput.value = total.toFixed(2) + " ₽"
  }

  // Отображаем модальное окно
  modal.style.display = "block"

  // Блокируем прокрутку страницы
  document.body.style.overflow = "hidden"
}

// Функция для закрытия модального окна заказа
window.closeOrderModal = () => {
  const modal = document.getElementById("orderModal")
  const orderForm = document.getElementById("orderForm")
  const orderMessage = document.getElementById("orderMessage")

  if (!modal) return

  modal.style.display = "none"

  // Разблокируем прокрутку страницы
  document.body.style.overflow = "auto"

  // Сбрасываем форму
  if (orderForm) {
    orderForm.reset()

    // Разблокируем кнопку отправки, если она была заблокирована
    const submitButton = orderForm.querySelector('button[type="submit"]')
    if (submitButton) {
      submitButton.disabled = false
      submitButton.innerHTML = "Оформить заказ"
    }
  }

  // Скрываем сообщение
  if (orderMessage) {
    orderMessage.style.display = "none"
    orderMessage.className = "order-message"
  }
}

// Функция для расчета итоговой стоимости
window.calculateTotalPrice = (price) => {
  const quantityInput = document.getElementById("quantity")
  const totalPriceInput = document.getElementById("total_price")

  if (!quantityInput || !totalPriceInput) return

  const quantity = Number.parseInt(quantityInput.value) || 0
  const priceValue = Number.parseFloat(price)
  const total = quantity * priceValue
  totalPriceInput.value = total.toFixed(2) + " ₽"
}
