document.addEventListener("DOMContentLoaded", () => {
  const authData = JSON.parse(sessionStorage.getItem("auth")) || {}
  const logoutBtn = document.getElementById("logoutBtn")
  const profileEditForm = document.getElementById("profileEditForm")
  const changeAvatarBtn = document.getElementById("changeAvatarBtn")
  const avatarUpload = document.getElementById("avatarUpload")
  const passwordError = document.getElementById("passwordError")
  const newPassword = document.getElementById("newPassword")
  const confirmPassword = document.getElementById("confirmPassword")

  // Hide password error by default
  if (passwordError) {
    passwordError.style.display = "none"
  }

  // Show password error only when user starts typing in password fields
  if (newPassword) {
    newPassword.addEventListener("input", () => {
      checkPasswords()
    })
  }

  if (confirmPassword) {
    confirmPassword.addEventListener("input", () => {
      checkPasswords()
    })
  }

  // Function to check passwords and show/hide error
  function checkPasswords() {
    if (passwordError) {
      if (newPassword.value && confirmPassword.value && newPassword.value !== confirmPassword.value) {
        passwordError.textContent = "Пароли не совпадают!"
        passwordError.style.display = "block"
      } else if (newPassword.value && newPassword.value.length < 5) {
        passwordError.textContent = "Пароль должен содержать не менее 5 символов"
        passwordError.style.display = "block"
      } else {
        passwordError.style.display = "none"
      }
    }
  }

  // Функция для проверки авторизации
  const checkAuth = async () => {
    try {
      const response = await fetch('check-session.php', {
        method: 'GET',
        credentials: 'include'
      });
      
      const data = await response.json();
      
      if (data.success && data.isAuthenticated) {
        // Обновляем данные в sessionStorage
        const newAuthData = {
          isAuthenticated: true,
          user: data.user
        };
        sessionStorage.setItem('auth', JSON.stringify(newAuthData));
        return true;
      } else {
        return false;
      }
    } catch (error) {
      console.error('Ошибка при проверке авторизации:', error);
      return false;
    }
  };

  // Загрузка текущих данных пользователя
  const loadUserData = () => {
    if (!authData.user) return

    document.getElementById("phone").value = authData.user.phone || ""
    document.getElementById("email").value = authData.user.email || ""
    document.getElementById("address").value = authData.user.address || ""
    document.getElementById("whatsapp").value = authData.user.whatsapp_user || ""
    document.getElementById("vk").value = authData.user.vk_user || ""
    document.getElementById("telegram").value = authData.user.telegram_user || ""

    const avatarPreview = document.getElementById("avatarPreview")
    if (avatarPreview) {
      avatarPreview.src = authData.user.avatar_path || "images/default-avatar.png"
    }
  }

  // Проверка авторизации
  if (!authData.isAuthenticated) {
    window.location.href = "login.html"
    return
  }

  // Загрузка данных при открытии страницы
  loadUserData()

  // Обработчик выхода
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      // Добавляем анимацию при выходе
      logoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'

      fetch('logout.php', {
        method: 'GET',
        credentials: 'include'
      }).then(() => {
        sessionStorage.removeItem("auth")
        localStorage.removeItem("authEmail")
        window.location.href = "index.html"
      }).catch(error => {
        console.error('Ошибка при выходе:', error);
        sessionStorage.removeItem("auth")
        localStorage.removeItem("authEmail")
        window.location.href = "index.html"
      });
    })
  }

  // Обработчик изменения аватара
  if (changeAvatarBtn && avatarUpload) {
    changeAvatarBtn.addEventListener("click", () => {
      avatarUpload.click()
    })

    avatarUpload.addEventListener("change", (e) => {
      if (e.target.files && e.target.files[0]) {
        const reader = new FileReader()
        reader.onload = (event) => {
          const avatarPreview = document.getElementById("avatarPreview")
          if (avatarPreview) {
            avatarPreview.src = event.target.result
            // Добавляем анимацию при изменении аватара
            avatarPreview.style.animation = "pulse 0.5s"
            setTimeout(() => {
              avatarPreview.style.animation = ""
            }, 500)
          }
        }
        reader.readAsDataURL(e.target.files[0])
      }
    })
  }

  // Обработчик отправки формы
  if (profileEditForm) {
    profileEditForm.addEventListener("submit", async function (e) {
      e.preventDefault()

      // Проверяем авторизацию перед отправкой формы
      const isAuth = await checkAuth();
      if (!isAuth) {
        showNotification('error', 'Необходимо авторизоваться для сохранения изменений');
        setTimeout(() => {
          window.location.href = "login.html";
        }, 2000);
        return;
      }

      const elements = {
        phone: document.getElementById("phone"),
        email: document.getElementById("email"),
        address: document.getElementById("address"),
        whatsapp: document.getElementById("whatsapp"),
        vk: document.getElementById("vk"),
        telegram: document.getElementById("telegram"),
        newPassword: document.getElementById("newPassword"),
        confirmPassword: document.getElementById("confirmPassword"),
        avatarPreview: document.getElementById("avatarPreview"),
        submitBtn: this.querySelector('button[type="submit"]'),
      }

      const formattedWhatsApp = formatWhatsApp(elements.whatsapp.value)

      function formatWhatsApp(number) {
        if (!number) return null
        // Оставляем только цифры
        return number.replace(/\D/g, "")
      }

      document.getElementById("telegram").addEventListener("input", function () {
        this.value = this.value.replace("@", "")
      })

      // Проверка паролей
      if (elements.newPassword.value && elements.newPassword.value !== elements.confirmPassword.value) {
        passwordError.textContent = "Пароли не совпадают!"
        passwordError.style.display = "block"
        return
      }

      // Сбор данных
      const formData = {
        phone: elements.phone.value,
        email: elements.email.value,
        address: elements.address.value,
        whatsapp: elements.whatsapp.value.trim() === "" ? "" : formattedWhatsApp,
        vk: elements.vk.value.trim(),
        telegram: elements.telegram.value.trim(),
        avatar: elements.avatarPreview?.src,
        password: elements.newPassword.value || null,
      }

      try {
        // Блокируем кнопку
        if (elements.submitBtn) {
          elements.submitBtn.disabled = true
          elements.submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Сохранение...'
        }

        // Отправляем данные
        const response = await fetch("update-profile.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(formData),
          credentials: 'include'
        })

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
        }

        const data = await response.json()

        if (!data.success) {
          throw new Error(data.error || "Неизвестная ошибка сервера")
        }

        // Обновляем данные в sessionStorage
        const updatedUser = {
          ...authData.user,
          ...data.user,
          phone: formData.phone,
          email: formData.email,
          address: formData.address,
          whatsapp_user: formData.whatsapp,
          vk_user: formData.vk,
          telegram_user: formData.telegram,
        }

        sessionStorage.setItem(
          "auth",
          JSON.stringify({
            isAuthenticated: true,
            user: updatedUser,
          }),
        )

        // Показываем уведомление об успешном сохранении
        showNotification('success', 'Изменения успешно сохранены!');

        setTimeout(() => {
          window.location.href = "profile.html"
        }, 2000)
      } catch (error) {
        console.error("Ошибка сохранения:", error)
        // Показываем уведомление об ошибке
        showNotification('error', `Ошибка: ${error.message}`);
      } finally {
        if (elements.submitBtn) {
          elements.submitBtn.disabled = false
          elements.submitBtn.innerHTML = "Сохранить изменения"
        }
      }
    })
  }

  // Функция для отображения уведомлений
  function showNotification(type, message) {
    const notificationClass = type === 'success' ? 'success-notification' : 'error-notification';
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    
    const notification = document.createElement("div");
    notification.className = notificationClass;
    notification.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
    document.body.appendChild(notification);

    setTimeout(() => {
      notification.classList.add("show");
    }, 100);

    setTimeout(() => {
      notification.classList.remove("show");
      setTimeout(() => {
        notification.remove();
      }, 500);
    }, 3000);
  }

  // Переключение видимости пароля
  document.querySelectorAll(".toggle-password").forEach((icon) => {
    icon.addEventListener("click", function () {
      const input = this.previousElementSibling
      if (input.type === "password") {
        input.type = "text"
        this.classList.replace("fa-eye", "fa-eye-slash")
      } else {
        input.type = "password"
        this.classList.replace("fa-eye-slash", "fa-eye")
      }
    })
  })

  // Добавляем стили для уведомлений
  const style = document.createElement("style")
  style.textContent = `
          .success-notification, .error-notification {
              position: fixed;
              top: 20px;
              right: 20px;
              padding: 15px 25px;
              border-radius: 8px;
              color: white;
              font-weight: 500;
              display: flex;
              align-items: center;
              gap: 10px;
              box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
              transform: translateX(120%);
              transition: transform 0.5s cubic-bezier(0.25, 0.8, 0.25, 1);
              z-index: 1000;
          }
          
          .success-notification {
              background: linear-gradient(135deg, #4CAF50, #45a049);
          }
          
          .error-notification {
              background: linear-gradient(135deg, #f44336, #e53935);
          }
          
          .success-notification.show, .error-notification.show {
              transform: translateX(0);
          }
          
          .success-notification i, .error-notification i {
              font-size: 20px;
          }
          
          @keyframes pulse {
              0% { transform: scale(1); }
              50% { transform: scale(1.1); }
              100% { transform: scale(1); }
          }
      `
  document.head.appendChild(style)
})