<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'chat_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));
logError("POST data: " . file_get_contents('php://input'));

$input = json_decode(file_get_contents('php://input'), true);

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован через сессию, проверяем данные из запроса
if (!$isAuthenticated && $input && isset($input['userId'])) {
    $isAuthenticated = true;
    $userId = $input['userId'];
    logError("Authenticated via request userId: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'messages' => [],
        'debug' => [
            'session' => $_SESSION,
            'input' => $input
        ]
    ]);
    exit;
}

// Проверяем наличие необходимых параметров в запросе
if (!$input || !isset($input['conversationId'])) {
    logError("Missing required parameters. Input: " . json_encode($input));
    echo json_encode([
        'success' => false, 
        'error' => 'Отсутствуют необходимые параметры',
        'messages' => []
    ]);
    exit;
}

try {
    // Проверяем существование таблицы messages
    $tableCheckStmt = $pdo->query("SHOW TABLES LIKE 'messages'");
    if ($tableCheckStmt->rowCount() === 0) {
        // Таблица не существует, возвращаем пустой список
        echo json_encode(['success' => true, 'messages' => []]);
        exit;
    }
    
    $isAdmin = isset($input['isAdmin']) ? $input['isAdmin'] : false;
    $isHelper = isset($input['isHelper']) ? $input['isHelper'] : false;
    $isNew = isset($input['isNew']) ? $input['isNew'] : false;
    $conversationId = $input['conversationId'];
    
    if ($isAdmin || $isHelper) {
        // Для админа/помощника - получаем сообщения с конкретным пользователем
        $query = "SELECT m.*, 
                 u1.firstName as sender_firstName, 
                 u1.lastName as sender_lastName,
                 u1.role as sender_role,
                 u2.firstName as receiver_firstName,
                 u2.lastName as receiver_lastName,
                 u2.role as receiver_role,
                 us.status as sender_status,
                 us.last_seen as sender_last_seen
                 FROM messages m
                 LEFT JOIN user u1 ON m.sender_id = u1.id
                 LEFT JOIN user u2 ON m.receiver_id = u2.id
                 LEFT JOIN user_status us ON m.sender_id = us.user_id
                 WHERE (m.sender_id = :userId AND m.receiver_id = :conversationId)
                 OR (m.receiver_id = :userId AND m.sender_id = :conversationId)
                 ORDER BY m.created_at";
                 
        $params = [
            ':userId' => $userId,
            ':conversationId' => $conversationId
        ];
    } else {
        if ($conversationId === 'support') {
            // Для пользователя - получаем сообщения с помощником (helper)
            $query = "SELECT m.*, 
                     u1.firstName as sender_firstName, 
                     u1.lastName as sender_lastName,
                     u1.role as sender_role,
                     u2.firstName as receiver_firstName,
                     u2.lastName as receiver_lastName,
                     u2.role as receiver_role,
                     us.status as sender_status,
                     us.last_seen as sender_last_seen
                     FROM messages m
                     LEFT JOIN user u1 ON m.sender_id = u1.id
                     LEFT JOIN user u2 ON m.receiver_id = u2.id
                     LEFT JOIN user_status us ON m.sender_id = us.user_id
                     WHERE (m.sender_id = :userId AND m.receiver_id IN (SELECT id FROM user WHERE role = 'helper'))
                     OR (m.receiver_id = :userId AND m.sender_id IN (SELECT id FROM user WHERE role = 'helper'))
                     ORDER BY m.created_at";
                     
            $params = [':userId' => $userId];
        } else {
            // Для пользователя - получаем сообщения с конкретным админом
            $query = "SELECT m.*, 
                     u1.firstName as sender_firstName, 
                     u1.lastName as sender_lastName,
                     u1.role as sender_role,
                     u2.firstName as receiver_firstName,
                     u2.lastName as receiver_lastName,
                     u2.role as receiver_role,
                     us.status as sender_status,
                     us.last_seen as sender_last_seen
                     FROM messages m
                     LEFT JOIN user u1 ON m.sender_id = u1.id
                     LEFT JOIN user u2 ON m.receiver_id = u2.id
                     LEFT JOIN user_status us ON m.sender_id = us.user_id
                     WHERE (m.sender_id = :userId AND m.receiver_id = :conversationId)
                     OR (m.receiver_id = :userId AND m.sender_id = :conversationId)
                     ORDER BY m.created_at";
                     
            $params = [
                ':userId' => $userId,
                ':conversationId' => $conversationId
            ];
        }
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get attachments for each message
    foreach ($messages as &$message) {
        $attachmentQuery = "SELECT * FROM message_attachments WHERE message_id = ?";
        $attachmentStmt = $pdo->prepare($attachmentQuery);
        $attachmentStmt->execute([$message['id']]);
        $attachments = $attachmentStmt->fetchAll(PDO::FETCH_ASSOC);
        
        $message['attachments'] = $attachments;
    }
    
    // Если это новый диалог и нет сообщений, добавляем системное сообщение
    if ($isNew && empty($messages)) {
        if ($isAdmin || $isHelper) {
            $messages[] = [
                'text' => 'Новый диалог с пользователем',
                'created_at' => date('Y-m-d H:i:s'),
                'is_system' => true,
                'is_read' => 1,
                'attachments' => []
            ];
        } else {
            if ($conversationId === 'support') {
                $messages[] = [
                    'text' => 'Вы начали диалог с техподдержкой. Опишите ваш вопрос.',
                    'created_at' => date('Y-m-d H:i:s'),
                    'is_system' => true,
                    'is_read' => 1,
                    'attachments' => []
                ];
            } else {
                $messages[] = [
                    'text' => 'Вы начали диалог с администратором. Опишите ваш вопрос.',
                    'created_at' => date('Y-m-d H:i:s'),
                    'is_system' => true,
                    'is_read' => 1,
                    'attachments' => []
                ];
            }
        }
    }
    
    // Отмечаем сообщения как прочитанные, если пользователь открыл диалог
    if (!$isAdmin && !$isHelper) {
        $updateQuery = "UPDATE messages 
                       SET is_read = 1 
                       WHERE receiver_id = :userId 
                       AND is_read = 0";
                       
        if ($conversationId === 'support') {
            $updateQuery .= " AND sender_id IN (SELECT id FROM user WHERE role = 'helper')";
            $updateParams = [':userId' => $userId];
        } else {
            $updateQuery .= " AND sender_id = :conversationId";
            $updateParams = [
                ':userId' => $userId,
                ':conversationId' => $conversationId
            ];
        }
        
        $updateStmt = $pdo->prepare($updateQuery);
        $updateStmt->execute($updateParams);
    }
    
    echo json_encode([
        'success' => true,
        'messages' => $messages
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'messages' => []
    ]);
}
?>