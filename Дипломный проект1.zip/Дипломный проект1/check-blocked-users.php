<?php
header("Content-Type: application/json");
require_once 'config.php';

// Получение данных из запроса
$data = json_decode(file_get_contents('php://input'), true);
$emails = isset($data['emails']) ? $data['emails'] : [];

if (empty($emails)) {
    echo json_encode([
        'success' => true,
        'blockedEmails' => []
    ]);
    exit;
}

try {
    // Подготавливаем плейсхолдеры для запроса
    $placeholders = implode(',', array_fill(0, count($emails), '?'));
    
    // Получаем список заблокированных email
    $stmt = $pdo->prepare("SELECT email FROM blacklist WHERE email IN ($placeholders)");
    $stmt->execute($emails);
    $blockedEmails = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    echo json_encode([
        'success' => true,
        'blockedEmails' => $blockedEmails
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
}
?>
