<?php
require_once 'config.php';
session_start();

// Проверка авторизации и прав доступа
$userId = isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null;
$userRole = isset($_SESSION['user']['role']) ? $_SESSION['user']['role'] : null;

if (!$userId || ($userRole !== 'admin' && $userRole !== 'owner')) {
    echo json_encode([
        'success' => false,
        'error' => 'Доступ запрещен'
    ]);
    exit;
}

try {
    // Очистка таблицы site_visits
    $pdo->exec("TRUNCATE TABLE site_visits");
    
    // Получение списка пользователей
    $stmt = $pdo->query("SELECT id FROM user");
    $userIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Получение списка страниц
    $pages = ['index.html', 'access-denied.html', 'company.html', 'edit-profile.html', 'profile.html', 'forgot-password.html', 'login.html', 'reg.html', 'orders.html', 'settings.html', 'statistics.html'];
    
    // Генерация данных за последние 90 дней
    $startDate = new DateTime();
    $startDate->modify('-90 days');
    
    $count = 0;
    $batchSize = 100;
    $values = [];
    
    // Подготовка запроса для вставки
    $insertQuery = "INSERT INTO site_visits (visit_date, ip_address, user_agent, page, user_id) VALUES ";
    
    // Генерация 1000 записей
    for ($i = 0; $i < 1000; $i++) {
        // Случайная дата за последние 90 дней
        $days = rand(0, 90);
        $hours = rand(0, 23);
        $minutes = rand(0, 59);
        
        $visitDate = clone $startDate;
        $visitDate->modify("+$days days +$hours hours +$minutes minutes");
        $formattedDate = $visitDate->format('Y-m-d H:i:s');
        
        // Случайный пользователь (NULL для неавторизованных)
        $userId = (rand(0, 100) < 30) ? $userIds[array_rand($userIds)] : 'NULL';
        
        // Случайная страница
        $page = $pages[array_rand($pages)];
        
        // Случайный IP-адрес
        $ip = rand(1, 255) . '.' . rand(0, 255) . '.' . rand(0, 255) . '.' . rand(0, 255);
        
        // Добавление значений
        $values[] = "('$formattedDate', '$ip', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36', '$page', $userId)";
        $count++;
        
        // Вставка данных пакетами
        if ($count % $batchSize === 0 || $i === 999) {
            $sql = $insertQuery . implode(',', $values);
            $pdo->exec($sql);
            $values = [];
        }
    }
    
    echo json_encode([
        'success' => true,
        'message' => 'Тестовые данные успешно сгенерированы',
        'count' => $count
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных: ' . $e->getMessage()
    ]);
}
?>