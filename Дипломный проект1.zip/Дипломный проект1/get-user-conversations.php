<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'user_conversations_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));
logError("POST data: " . file_get_contents('php://input'));

$input = json_decode(file_get_contents('php://input'), true);

// Проверяем авторизацию - более гибкая проверка для поддержки разных форматов сессии
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован через сессию, проверяем данные из запроса
if (!$isAuthenticated && $input && isset($input['userId'])) {
    $isAuthenticated = true;
    $userId = $input['userId'];
    logError("Authenticated via request userId: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'conversations' => [],
        'debug' => [
            'session' => $_SESSION,
            'input' => $input
        ]
    ]);
    exit;
}

try {
    // Получаем все диалоги пользователя с админами и помощниками
    $query = "SELECT 
              u.id as user_id,
              CONCAT(u.firstName, ' ', u.lastName) as user_name,
              u.role as support_role,
              u.avatar_path,
              (SELECT text FROM messages 
               WHERE ((sender_id = :userId AND receiver_id = u.id)
               OR (receiver_id = :userId AND sender_id = u.id))
               ORDER BY created_at DESC LIMIT 1) as last_message,
              (SELECT created_at FROM messages 
               WHERE ((sender_id = :userId AND receiver_id = u.id)
               OR (receiver_id = :userId AND sender_id = u.id))
               ORDER BY created_at DESC LIMIT 1) as last_message_time,
              COUNT(CASE WHEN m.is_read = 0 AND m.receiver_id = :userId THEN 1 END) as unread_count
              FROM user u
              LEFT JOIN messages m ON (m.sender_id = u.id AND m.receiver_id = :userId) 
                                   OR (m.receiver_id = u.id AND m.sender_id = :userId)
              WHERE u.role IN ('admin', 'helper')
              AND EXISTS (
                SELECT 1 FROM messages 
                WHERE (sender_id = :userId AND receiver_id = u.id)
                OR (receiver_id = :userId AND sender_id = u.id)
              )
              GROUP BY u.id";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':userId' => $userId]);
    
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'conversations' => []
    ]);
}
?>
