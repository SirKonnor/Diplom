<?php
// Скрипт для очистки логов
header('Content-Type: application/json; charset=utf-8');

$logFile = 'logs/currency_update.log';

try {
    if (file_exists($logFile)) {
        file_put_contents($logFile, '');
        echo json_encode(['success' => true, 'message' => 'Логи очищены']);
    } else {
        echo json_encode(['success' => true, 'message' => 'Файл логов не существует']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
