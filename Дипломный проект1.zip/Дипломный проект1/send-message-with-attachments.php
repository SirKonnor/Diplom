<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Function for logging errors
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'message_upload_errors.log');
}

// Check if form data exists
if (!isset($_POST['sender_id'], $_POST['receiver_id'])) {
    logError("Missing required parameters");
    echo json_encode(['success' => false, 'error' => 'Missing required parameters']);
    exit;
}

try {
    $senderId = $_POST['sender_id'];
    $receiverId = $_POST['receiver_id'];
    $text = isset($_POST['text']) ? $_POST['text'] : '';
    $isAdmin = isset($_POST['isAdmin']) && $_POST['isAdmin'] === 'true';
    $isHelper = isset($_POST['isHelper']) && $_POST['isHelper'] === 'true';
    
    // If receiver is support, find helper or admin ID
    if ($receiverId === 'support') {
        $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'helper' LIMIT 1");
        $stmt->execute();
        $helper = $stmt->fetch();
        
        if ($helper) {
            $receiverId = $helper['id'];
        } else {
            // If no helper, find admin
            $stmt = $pdo->prepare("SELECT id FROM user WHERE role = 'admin' LIMIT 1");
            $stmt->execute();
            $admin = $stmt->fetch();
            $receiverId = $admin ? $admin['id'] : null;
        }
    }

    if (!$receiverId) {
        throw new Exception("Support staff not found");
    }

    // Start transaction
    $pdo->beginTransaction();
    
    // Insert message
    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, text, is_read) VALUES (?, ?, ?, 0)");
    $stmt->execute([$senderId, $receiverId, $text]);
    $messageId = $pdo->lastInsertId();
    
    // Process file uploads
    $uploadedFiles = [];
    $uploadDir = 'uploads/';
    
    // Create upload directory if it doesn't exist
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Check if files were uploaded
    $hasFiles = false;
    if (isset($_FILES['attachments'])) {
        foreach ($_FILES['attachments']['name'] as $key => $name) {
            if (!empty($name)) {
                $hasFiles = true;
                break;
            }
        }
    }
    
    if ($hasFiles) {
        $fileCount = count($_FILES['attachments']['name']);
        
        for ($i = 0; $i < $fileCount; $i++) {
            if ($_FILES['attachments']['error'][$i] === UPLOAD_ERR_OK) {
                $fileName = $_FILES['attachments']['name'][$i];
                $fileType = $_FILES['attachments']['type'][$i];
                $fileSize = $_FILES['attachments']['size'][$i];
                $fileTmpName = $_FILES['attachments']['tmp_name'][$i];
                
                // Generate unique filename
                $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
                $uniqueName = uniqid() . '_' . time() . '.' . $fileExt;
                $targetFilePath = $uploadDir . $uniqueName;
                
                // Move uploaded file
                if (move_uploaded_file($fileTmpName, $targetFilePath)) {
                    // Insert file info into database
                    $fileStmt = $pdo->prepare("
                        INSERT INTO message_attachments 
                        (message_id, file_name, file_path, file_type, file_size) 
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $fileStmt->execute([$messageId, $fileName, $targetFilePath, $fileType, $fileSize]);
                    
                    $uploadedFiles[] = [
                        'id' => $pdo->lastInsertId(),
                        'file_name' => $fileName,
                        'file_path' => $targetFilePath,
                        'file_type' => $fileType,
                        'file_size' => $fileSize
                    ];
                } else {
                    logError("Failed to move uploaded file: " . $fileName);
                }
            } else {
                logError("Upload error: " . $_FILES['attachments']['error'][$i] . " for file " . $_FILES['attachments']['name'][$i]);
            }
        }
    }
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message_id' => $messageId,
        'attachments' => $uploadedFiles
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
