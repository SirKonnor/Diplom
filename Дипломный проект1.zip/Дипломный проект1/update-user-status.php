<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Обработка preflight запросов
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config.php';

session_start();

// Функция для логирования
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'user_status_errors.log');
}

function logActivity($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'user_status_activity.log');
}

try {
    // Получаем данные запроса
    $rawInput = file_get_contents('php://input');
    logActivity("Raw input: " . $rawInput);
    
    $input = json_decode($rawInput, true);
    
    if (!$input || !isset($input['userId'], $input['status'])) {
        throw new Exception('Missing required parameters: userId and status');
    }
    
    $userId = (int)$input['userId'];
    $status = trim($input['status']);
    
    logActivity("Processing status update for user $userId to status $status");
    
    // Валидация статуса - ИСПРАВЛЕНО: добавлен статус 'away'
    $allowedStatuses = ['online', 'away', 'offline'];
    if (!in_array($status, $allowedStatuses)) {
        throw new Exception('Invalid status. Allowed: ' . implode(', ', $allowedStatuses));
    }
    
    // Валидация пользователя
    if ($userId <= 0) {
        throw new Exception('Invalid user ID');
    }
    
    // Проверяем существование пользователя
    $stmt = $pdo->prepare("SELECT id FROM user WHERE id = ?");
    $stmt->execute([$userId]);
    if (!$stmt->fetch()) {
        throw new Exception('User not found');
    }
    
    // Получаем дополнительную информацию для логирования
    $sessionId = session_id();
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // Получаем текущий статус
    $stmt = $pdo->prepare("SELECT status, last_seen FROM user_status WHERE user_id = ?");
    $stmt->execute([$userId]);
    $currentStatus = $stmt->fetch();
    
    $now = date('Y-m-d H:i:s');
    
    if ($currentStatus) {
        // Обновляем существующий статус
        $stmt = $pdo->prepare("
            UPDATE user_status 
            SET status = ?, last_seen = ?, session_id = ?, user_agent = ?, ip_address = ?
            WHERE user_id = ?
        ");
        $stmt->execute([$status, $now, $sessionId, $userAgent, $ipAddress, $userId]);
        
        // Логируем изменение статуса
        if ($currentStatus['status'] !== $status) {
            logActivity("User $userId status changed from {$currentStatus['status']} to $status");
            
            // Записываем в таблицу активности, если она существует
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO user_activity_log 
                    (user_id, action, old_status, new_status, page_url, user_agent, ip_address) 
                    VALUES (?, 'status_change', ?, ?, ?, ?, ?)
                ");
                $pageUrl = $_SERVER['HTTP_REFERER'] ?? '';
                $stmt->execute([$userId, $currentStatus['status'], $status, $pageUrl, $userAgent, $ipAddress]);
            } catch (Exception $e) {
                // Игнорируем ошибки записи в лог активности
                logError("Failed to log activity: " . $e->getMessage());
            }
        }
    } else {
        // Создаем новую запись
        $stmt = $pdo->prepare("
            INSERT INTO user_status (user_id, status, last_seen, session_id, user_agent, ip_address) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $status, $now, $sessionId, $userAgent, $ipAddress]);
        
        logActivity("User $userId status created: $status");
        
        // Записываем в таблицу активности
        try {
            $stmt = $pdo->prepare("
                INSERT INTO user_activity_log 
                (user_id, action, new_status, page_url, user_agent, ip_address) 
                VALUES (?, 'status_create', ?, ?, ?, ?)
            ");
            $pageUrl = $_SERVER['HTTP_REFERER'] ?? '';
            $stmt->execute([$userId, $status, $pageUrl, $userAgent, $ipAddress]);
        } catch (Exception $e) {
            logError("Failed to log activity: " . $e->getMessage());
        }
    }
    
    // Дополнительная очистка устаревших статусов
    if ($status === 'online') {
        // Помечаем как offline пользователей, которые не обновляли статус более 2 минут
        $stmt = $pdo->prepare("
            UPDATE user_status 
            SET status = 'offline' 
            WHERE status IN ('online', 'away') 
            AND user_id != ? 
            AND last_seen < DATE_SUB(NOW(), INTERVAL 2 MINUTE)
        ");
        $stmt->execute([$userId]);
    }
    
    logActivity("Status update successful for user $userId");
    
    echo json_encode([
        'success' => true,
        'status' => $status,
        'timestamp' => $now,
        'userId' => $userId,
        'debug' => [
            'sessionId' => $sessionId,
            'userAgent' => substr($userAgent, 0, 100),
            'ipAddress' => $ipAddress
        ]
    ]);
    
} catch (Exception $e) {
    logError("Error updating user status: " . $e->getMessage());
    
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s'),
        'debug' => [
            'input' => $input ?? null,
            'rawInput' => $rawInput ?? null
        ]
    ]);
}
?>
