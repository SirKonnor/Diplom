<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'chat_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));
logError("POST data: " . file_get_contents('php://input'));

$input = json_decode(file_get_contents('php://input'), true);

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку с кодом 200 вместо 401
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'debug' => [
            'session' => $_SESSION
        ]
    ]);
    exit;
}

// Проверяем наличие необходимых параметров в запросе
if (!$input || !isset($input['receiver_id'])) {
    logError("Missing required parameters. Input: " . json_encode($input));
    echo json_encode([
        'success' => false, 
        'error' => 'Отсутствуют необходимые параметры'
    ]);
    exit;
}

try {
    // Используем ID из сессии вместо переданного sender_id
    $senderId = $userId;
    $receiverId = $input['receiver_id'];
    
    // Проверяем существование получателя
    $stmt = $pdo->prepare("SELECT id, role FROM user WHERE id = ?");
    $stmt->execute([$receiverId]);
    $receiver = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$receiver) {
        logError("Receiver not found. Receiver ID: " . $receiverId);
        echo json_encode([
            'success' => false, 
            'error' => 'Пользователь не найден'
        ]);
        exit;
    }
    
    // Получаем роль отправителя
    $stmt = $pdo->prepare("SELECT role FROM user WHERE id = ?");
    $stmt->execute([$senderId]);
    $sender = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$sender) {
        logError("Sender not found. Sender ID: " . $senderId);
        echo json_encode([
            'success' => false, 
            'error' => 'Отправитель не найден'
        ]);
        exit;
    }
    
    // Проверяем существование таблицы messages
    $tableCheckStmt = $pdo->query("SHOW TABLES LIKE 'messages'");
    if ($tableCheckStmt->rowCount() === 0) {
        // Таблица не существует, создаем ее
        $pdo->exec("CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            text TEXT NOT NULL,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");
        logError("Created messages table");
    }
    
    // Проверяем, существует ли уже диалог между этими пользователями
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM messages 
                          WHERE (sender_id = ? AND receiver_id = ?) 
                          OR (sender_id = ? AND receiver_id = ?)");
    $stmt->execute([$senderId, $receiverId, $receiverId, $senderId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $isNewConversation = ($result['count'] == 0);
    
    // Создаем приветственное сообщение только если диалога еще нет
    if ($isNewConversation) {
        // Определяем приветственное сообщение в зависимости от роли отправителя
        $welcomeMessage = "";
        
        if ($sender['role'] === 'admin') {
            $welcomeMessage = "Здравствуйте! Я администратор сайта. Чем я могу вам помочь?";
        } 
        elseif ($sender['role'] === 'helper') {
            $welcomeMessage = "Здравствуйте! Я из технической поддержки. Чем я могу вам помочь?";
        }
        else {
            // Если обычный пользователь пишет админу или помощнику
            if ($receiver['role'] === 'admin' || $receiver['role'] === 'helper') {
                $welcomeMessage = "Здравствуйте! У меня есть вопрос.";
            }
            // Если обычный пользователь пишет другому обычному пользователю
            else {
                $welcomeMessage = "Здравствуйте! Хотел бы с вами связаться.";
            }
        }
        
        if (!empty($welcomeMessage)) {
            $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, text) VALUES (?, ?, ?)");
            $stmt->execute([$senderId, $receiverId, $welcomeMessage]);
            $messageId = $pdo->lastInsertId();
            logError("Created new message with ID: " . $messageId);
        } else {
            $messageId = null;
            logError("No welcome message created");
        }
        
        echo json_encode([
            'success' => true, 
            'messageId' => $messageId,
            'isNewConversation' => true
        ]);
    } else {
        // Если диалог уже существует, просто возвращаем успех
        logError("Conversation already exists between users " . $senderId . " and " . $receiverId);
        echo json_encode([
            'success' => true,
            'isNewConversation' => false
        ]);
    }
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    logError("Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>