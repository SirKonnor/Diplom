document.addEventListener("DOMContentLoaded", () => {
  const authData = JSON.parse(sessionStorage.getItem("auth")) || {}
  const userIcon = document.getElementById("user-icon")

  if (authData.isAuthenticated) {
    userIcon.href = "profile.html"
    // Можно добавить визуальное отображение
    userIcon.innerHTML = '<i class="fas fa-user-check"></i>'

    // Проверяем наличие непрочитанных сообщений
    if (typeof checkUnreadMessages === "function") {
      checkUnreadMessages(authData.user.id)
    }
  }

  const usersGrid = document.getElementById("usersGrid")
  const userSearch = document.getElementById("userSearch")
  const prevPageBtn = document.getElementById("prevPage")
  const nextPageBtn = document.getElementById("nextPage")
  const pageInfo = document.getElementById("pageInfo")
  const logoutBtn = document.getElementById("logoutBtn")

  // Модальные окна
  const blockUserModal = document.getElementById("blockUserModal")
  const deleteUserModal = document.getElementById("deleteUserModal")
  const blockUserName = document.getElementById("blockUserName")
  const deleteUserName = document.getElementById("deleteUserName")
  const blockReason = document.getElementById("blockReason")
  const confirmBlockBtn = document.getElementById("confirmBlockBtn")
  const confirmDeleteBtn = document.getElementById("confirmDeleteBtn")

  let currentPage = 1
  const usersPerPage = 6
  let allUsers = []
  let filteredUsers = []
  let currentUserId = null
  let currentUserEmail = null
  let currentUserFullName = null

  // Проверка прав администратора
  if (authData.user?.role !== "admin") {
    window.location.href = "profile.html"
    return
  }

  // Загрузка пользователей
  const loadUsers = async (searchTerm = "") => {
    try {
      // Показываем анимацию загрузки
      usersGrid.innerHTML =
        '<div class="loading-spinner"><i class="fas fa-spinner fa-spin"></i> Загрузка пользователей...</div>'

      const response = await fetch("get-all-users.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(authData),
      })

      const data = await response.json()

      if (data.success) {
        allUsers = data.users

        // Проверяем статус блокировки для каждого пользователя
        await checkBlockedStatus(allUsers)

        filterUsers(searchTerm)
        renderUsers()
      } else {
        console.error("Ошибка загрузки пользователей:", data.error)
        usersGrid.innerHTML = `<p class="error-message"><i class="fas fa-exclamation-circle"></i> Ошибка загрузки пользователей: ${data.error}</p>`
      }
    } catch (error) {
      console.error("Ошибка:", error)
      usersGrid.innerHTML = `<p class="error-message"><i class="fas fa-exclamation-circle"></i> Произошла ошибка при загрузке пользователей</p>`
    }
  }

  // Проверка статуса блокировки пользователей
  const checkBlockedStatus = async (users) => {
    try {
      const response = await fetch("check-blocked-users.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          emails: users.map((user) => user.email),
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Обновляем статус блокировки для каждого пользователя
        users.forEach((user) => {
          user.isBlocked = data.blockedEmails.includes(user.email)
        })
      }
    } catch (error) {
      console.error("Ошибка проверки статуса блокировки:", error)
    }
  }

  // Фильтрация пользователей
  const filterUsers = (searchTerm = "") => {
    if (!searchTerm) {
      filteredUsers = [...allUsers]
      return
    }

    const term = searchTerm.toLowerCase()
    filteredUsers = allUsers.filter(
      (user) =>
        user.id.toString().includes(term) ||
        user.lastName.toLowerCase().includes(term) ||
        user.firstName.toLowerCase().includes(term) ||
        (user.middleName && user.middleName.toLowerCase().includes(term)) ||
        user.email.toLowerCase().includes(term) ||
        user.formatted_date.includes(term),
    )

    currentPage = 1 // Сброс на первую страницу при новом поиске
  }

  // Отображение пользователей
  const renderUsers = () => {
    const startIndex = (currentPage - 1) * usersPerPage
    const endIndex = startIndex + usersPerPage
    const usersToShow = filteredUsers.slice(startIndex, endIndex)

    usersGrid.innerHTML = ""

    if (usersToShow.length === 0) {
      usersGrid.innerHTML = '<p class="empty-message"><i class="fas fa-search"></i> Пользователи не найдены</p>'
      return
    }

    usersToShow.forEach((user, index) => {
      const userCard = document.createElement("div")
      userCard.className = `user-card-admin ${user.isBlocked ? "blocked-user" : ""}`
      userCard.style.animation = `fadeIn 0.5s ease-out forwards ${index * 0.1}s`
      userCard.style.opacity = "0"

      userCard.innerHTML = `
          <div class="user-avatar-container">
            <img src="${user.avatar_path || "images/default-avatar.png"}" alt="Аватар" 
                 class="user-avatar-admin" onerror="this.src='images/default-avatar.png'">
          </div>
          <div class="user-info-admin">
            <p><strong>ID:</strong> ${user.id}</p>
            <p><strong>ФИО:</strong> ${user.lastName} ${user.firstName} ${user.middleName || ""}</p>
            <p><strong>Email:</strong> ${user.email}</p>
            <p><strong>Дата регистрации:</strong> ${user.formatted_date}</p>
            <div>
              <span class="user-role ${user.role}" style="margin-top: 10px;">
                ${user.role === "admin" ? "Администратор" : user.role === "helper" ? "Поддержка" : "Пользователь"}
              </span>
              <span class="user-status ${user.isBlocked ? "blocked" : "active"}">
                ${user.isBlocked ? "Заблокирован" : "Активен"}
              </span>
            </div>
          </div>
          <div class="user-actions">
            <button class="view-profile-btn" data-user-id="${user.id}">
              Перейти <i class="fas fa-arrow-right"></i>
            </button>
            ${
              user.role !== "admin"
                ? `
              ${
                !user.isBlocked
                  ? `
                <button class="user-action-btn block" data-user-id="${user.id}" data-user-email="${user.email}" data-user-name="${user.lastName} ${user.firstName}">
                  <i class="fas fa-ban"></i> Блокировать
                </button>
              `
                  : `
                <button class="user-action-btn unblock" data-user-id="${user.id}" data-user-email="${user.email}">
                  <i class="fas fa-unlock"></i> Разблокировать
                </button>
              `
              }
              <button class="user-action-btn delete" data-user-id="${user.id}" data-user-name="${user.lastName} ${user.firstName}">
                <i class="fas fa-trash-alt"></i> Удалить
              </button>
            `
                : ""
            }
          </div>
        `
      usersGrid.appendChild(userCard)
    })

    // Обновление информации о странице
    const totalPages = Math.ceil(filteredUsers.length / usersPerPage)
    pageInfo.textContent = `Страница ${currentPage} из ${totalPages || 1}`

    // Блокировка кнопок навигации
    prevPageBtn.disabled = currentPage === 1
    nextPageBtn.disabled = currentPage >= totalPages

    // Добавляем обработчики для кнопок блокировки и удаления
    addActionButtonHandlers()
  }

  // Добавление обработчиков для кнопок действий
  const addActionButtonHandlers = () => {
    // Обработчики для кнопок блокировки
    document.querySelectorAll(".user-action-btn.block").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation()
        currentUserId = btn.dataset.userId
        currentUserEmail = btn.dataset.userEmail
        currentUserFullName = btn.dataset.userName

        blockUserName.textContent = currentUserFullName
        blockReason.value = ""
        blockUserModal.style.display = "block"
      })
    })

    // Обработчики для кнопок разблокировки
    document.querySelectorAll(".user-action-btn.unblock").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation()
        const userId = btn.dataset.userId
        const userEmail = btn.dataset.userEmail

        if (confirm("Вы уверены, что хотите разблокировать этого пользователя?")) {
          unblockUser(userId, userEmail)
        }
      })
    })

    // Обработчики для кнопок удаления
    document.querySelectorAll(".user-action-btn.delete").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.stopPropagation()
        currentUserId = btn.dataset.userId
        currentUserFullName = btn.dataset.userName

        deleteUserName.textContent = currentUserFullName
        deleteUserModal.style.display = "block"
      })
    })
  }

  // Функция блокировки пользователя
  const blockUser = async (userId, userEmail, reason) => {
    try {
      const response = await fetch("block-user.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userId,
          userEmail: userEmail,
          reason: reason,
          adminId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Пользователь успешно заблокирован")
        blockUserModal.style.display = "none"
        loadUsers(userSearch.value) // Перезагружаем список пользователей
      } else {
        alert(`Ошибка: ${data.error || "Не удалось заблокировать пользователя"}`)
      }
    } catch (error) {
      console.error("Ошибка блокировки пользователя:", error)
      alert("Произошла ошибка при блокировке пользователя")
    }
  }

  // Функция разблокировки пользователя
  const unblockUser = async (userId, userEmail) => {
    try {
      const response = await fetch("unblock-user.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userId,
          userEmail: userEmail,
          adminId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Пользователь успешно разблокирован")
        loadUsers(userSearch.value) // Перезагружаем список пользователей
      } else {
        alert(`Ошибка: ${data.error || "Не удалось разблокировать пользователя"}`)
      }
    } catch (error) {
      console.error("Ошибка разблокировки пользователя:", error)
      alert("Произошла ошибка при разблокировке пользователя")
    }
  }

  // Функция удаления пользователя
  const deleteUser = async (userId) => {
    try {
      const response = await fetch("delete-user.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: userId,
          adminId: authData.user.id,
        }),
      })

      const data = await response.json()

      if (data.success) {
        alert("Пользователь успешно удален")
        deleteUserModal.style.display = "none"
        loadUsers(userSearch.value) // Перезагружаем список пользователей
      } else {
        alert(`Ошибка: ${data.error || "Не удалось удалить пользователя"}`)
      }
    } catch (error) {
      console.error("Ошибка удаления пользователя:", error)
      alert("Произошла ошибка при удалении пользователя")
    }
  }

  // Обработчики событий
  userSearch.addEventListener("input", (e) => {
    filterUsers(e.target.value)
    renderUsers()
  })

  prevPageBtn.addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--
      renderUsers()
    }
  })

  nextPageBtn.addEventListener("click", () => {
    if (currentPage * usersPerPage < filteredUsers.length) {
      currentPage++
      renderUsers()
    }
  })

  // Делегирование событий для кнопок перехода
  usersGrid.addEventListener("click", (e) => {
    if (e.target.closest(".view-profile-btn")) {
      const userId = e.target.closest(".view-profile-btn").dataset.userId

      // Добавляем анимацию при клике
      const button = e.target.closest(".view-profile-btn")
      button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Переход...'
      button.style.pointerEvents = "none"

      setTimeout(() => {
        window.location.href = `profile.html?userId=${userId}`
      }, 300)
    }
  })

  // Обработчики для модальных окон
  if (confirmBlockBtn) {
    confirmBlockBtn.addEventListener("click", () => {
      const reason = blockReason.value.trim()
      if (!reason) {
        alert("Пожалуйста, укажите причину блокировки")
        return
      }
      blockUser(currentUserId, currentUserEmail, reason)
    })
  }

  if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener("click", () => {
      deleteUser(currentUserId)
    })
  }

  // Закрытие модальных окон
  document.querySelectorAll(".close-modal, .cancel-btn").forEach((element) => {
    element.addEventListener("click", () => {
      blockUserModal.style.display = "none"
      deleteUserModal.style.display = "none"
    })
  })

  // Закрытие модальных окон при клике вне их области
  window.addEventListener("click", (event) => {
    if (event.target === blockUserModal) {
      blockUserModal.style.display = "none"
    }
    if (event.target === deleteUserModal) {
      deleteUserModal.style.display = "none"
    }
  })

  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      // Добавляем анимацию при выходе
      logoutBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'

      setTimeout(() => {
        sessionStorage.removeItem("auth")
        window.location.href = "index.html"
      }, 300)
    })
  }

  // Загрузка пользователей при старте
  loadUsers()
})
