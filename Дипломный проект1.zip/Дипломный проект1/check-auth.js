document.addEventListener('DOMContentLoaded', function() {
    // Проверяем авторизацию при загрузке страницы
    checkAuth();
});

function checkAuth() {
    // Проверяем данные в sessionStorage
    const authData = JSON.parse(sessionStorage.getItem('auth') || '{}');
    
    // Если в sessionStorage нет данных об авторизации, проверяем сессию на сервере
    if (!authData.isAuthenticated) {
        fetch('check-session.php', {
            method: 'GET',
            credentials: 'include' // Важно для работы с сессиями
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.isAuthenticated) {
                // Если пользователь авторизован на сервере, но не в sessionStorage,
                // обновляем данные в sessionStorage
                const newAuthData = {
                    isAuthenticated: true,
                    user: data.user
                };
                sessionStorage.setItem('auth', JSON.stringify(newAuthData));
            } else if (!data.isAuthenticated && window.location.pathname !== '/index.html' && window.location.pathname !== '/') {
                // Если пользователь не авторизован и находится не на странице входа,
                // перенаправляем на страницу входа
                window.location.href = 'index.html';
            }
        })
        .catch(error => {
            console.error('Ошибка при проверке авторизации:', error);
        });
    }
}