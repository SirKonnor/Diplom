<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'chat_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;
$isAdmin = false;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    
    // Проверяем роль пользователя
    if (isset($_SESSION['role']) && ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'administrator')) {
        $isAdmin = true;
    }
    
    logError("Authenticated via user_id: " . $userId . ", isAdmin: " . ($isAdmin ? "true" : "false"));
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    
    // Проверяем роль пользователя
    if (isset($_SESSION['user']['role']) && ($_SESSION['user']['role'] === 'admin' || $_SESSION['user']['role'] === 'administrator')) {
        $isAdmin = true;
    }
    
    logError("Authenticated via user.id: " . $userId . ", isAdmin: " . ($isAdmin ? "true" : "false"));
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    
    // Проверяем роль пользователя
    if (isset($_SESSION['auth']['user']['role']) && ($_SESSION['auth']['user']['role'] === 'admin' || $_SESSION['auth']['user']['role'] === 'administrator')) {
        $isAdmin = true;
    }
    
    logError("Authenticated via auth.user.id: " . $userId . ", isAdmin: " . ($isAdmin ? "true" : "false"));
}

// Если пользователь не авторизован, возвращаем ошибку с кодом 200 вместо 401
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'conversations' => [],
        'debug' => [
            'session' => $_SESSION
        ]
    ]);
    exit;
}

// Если пользователь не администратор, возвращаем ошибку с кодом 200 вместо 403
if (!$isAdmin) {
    logError("Access denied. User is not admin. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Доступ запрещен. Требуются права администратора.',
        'conversations' => []
    ]);
    exit;
}

try {
    // Проверяем существование таблицы messages
    $tableCheckStmt = $pdo->query("SHOW TABLES LIKE 'messages'");
    if ($tableCheckStmt->rowCount() === 0) {
        // Таблица не существует, возвращаем пустой список
        echo json_encode(['success' => true, 'conversations' => []]);
        exit;
    }
    
    // Получаем все беседы для администратора
    $query = "SELECT 
        u.id as user_id,
        CONCAT(u.firstName, ' ', u.lastName) as user_name,
        u.avatar_path,
        (SELECT text FROM messages 
         WHERE (sender_id = u.id AND receiver_id = :adminId)
         OR (receiver_id = u.id AND sender_id = :adminId)
         ORDER BY created_at DESC LIMIT 1) as last_message,
        (SELECT created_at FROM messages 
         WHERE (sender_id = u.id AND receiver_id = :adminId)
         OR (receiver_id = u.id AND sender_id = :adminId)
         ORDER BY created_at DESC LIMIT 1) as last_message_time,
        COUNT(CASE WHEN m.is_read = 0 AND m.receiver_id = :adminId THEN 1 END) as unread_count
        FROM user u
        LEFT JOIN messages m ON (m.sender_id = u.id OR m.receiver_id = u.id)
        WHERE (m.sender_id = :adminId OR m.receiver_id = :adminId)
        AND u.id != :adminId
        GROUP BY u.id
        ORDER BY MAX(m.created_at) DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':adminId' => $userId]);
    
    $conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'conversations' => $conversations
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'conversations' => []
    ]);
}
?>
