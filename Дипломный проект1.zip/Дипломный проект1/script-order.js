// Функция для загрузки последнего заказа с улучшенной обработкой ошибок
async function loadLastOrder() {
  const ordersInfo = document.getElementById("ordersInfo")
  if (!ordersInfo) return

  const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
  if (!authData.isAuthenticated || !authData.user || !authData.user.id) {
    ordersInfo.innerHTML = "<p>Необходимо авторизоваться для просмотра заказов</p>"
    return
  }

  try {
    // Показываем индикатор загрузки
    ordersInfo.innerHTML = `
      <div class="loading-indicator">
        <i class="fas fa-spinner fa-spin"></i>
        <span>Загрузка информации о заказах...</span>
      </div>
    `

    const response = await fetch("get-last-order.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: authData.user.id,
      }),
    })

    // Проверяем статус ответа
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`)
    }

    // Пробуем распарсить JSON
    let data
    try {
      const text = await response.text()
      data = JSON.parse(text)
    } catch (parseError) {
      console.error("Failed to parse JSON:", parseError)
      throw new Error("Сервер вернул некорректный ответ. Пожалуйста, обратитесь к администратору.")
    }

    if (data.success && data.order) {
      displayLastOrder(data.order)

      // Если был новый заказ, очищаем флаг
      if (sessionStorage.getItem("newOrder") === "true") {
        sessionStorage.removeItem("newOrder")
      }
    } else if (data.success) {
      ordersInfo.innerHTML = `
        <div class="empty-orders">
          <i class="fas fa-inbox"></i>
          <p>У вас пока нет заказов</p>
          <a href="index.html#fuel-section" class="btn-main">Заказать топливо</a>
        </div>
      `
    } else {
      throw new Error(data.error || "Неизвестная ошибка при загрузке заказов")
    }
  } catch (error) {
    console.error("Ошибка загрузки последнего заказа:", error)

    // Проверяем, связана ли ошибка со структурой таблицы
    if (error.message && error.message.includes("Unknown column")) {
      ordersInfo.innerHTML = `
        <div class="error-message">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Ошибка структуры таблицы: ${error.message}</p>
          <p>Пожалуйста, обратитесь к администратору для исправления структуры базы данных.</p>
        </div>
      `
    } else {
      ordersInfo.innerHTML = `
        <div class="error-message">
          <i class="fas fa-exclamation-triangle"></i>
          <p>Не удалось загрузить информацию о заказах: ${error.message}</p>
          <button onclick="loadLastOrder()" class="retry-btn">
            <i class="fas fa-sync-alt"></i> Попробовать снова
          </button>
        </div>
      `
    }
  }
}

// Функция для отображения последнего заказа в улучшенном формате
function displayLastOrder(order) {
  const ordersInfo = document.getElementById("ordersInfo")
  if (!ordersInfo) return

  // Определяем, какое поле даты использовать
  const dateField =
    order["created_at"] || order["date_created"] || order["order_date"] || order["date"] || order["timestamp"]

  // Форматируем дату, если она существует
  let formattedDate = "Не указана"
  let formattedTime = ""
  if (dateField) {
    const orderDate = new Date(dateField)
    formattedDate = orderDate.toLocaleDateString("ru-RU")
    formattedTime = orderDate.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
  }

  // Форматируем цены
  const pricePerLiter = Number.parseFloat(order.price_per_liter || 0)
  const totalPrice = Number.parseFloat(order.total_price || 0)
  const quantity = Number.parseInt(order.quantity || 0)

  const formattedPrice = pricePerLiter.toFixed(2).replace(".", ",")
  const formattedTotal = totalPrice.toFixed(2).replace(".", ",")

  // Получаем класс и текст статуса
  const statusInfo = getStatusInfo(order.status)

// Создаем улучшенное отображение заказа
  ordersInfo.innerHTML = `
    <div class="order-card ${order.status === "PENDING" ? "new-order" : ""}">
      <div class="order-header">
        <h4><i class="fas fa-file-invoice"></i> Заказ <span class="order-id">#${order.id}</span></h4>
        <span class="order-status ${statusInfo.class}">
          <i class="${statusInfo.icon}"></i> ${statusInfo.text}
        </span>
        <span class="order-status ${order.is_paid ? "confirmed" : "cancelled"}">
          <i class="fas ${order.is_paid ? "fa-check-circle" : "fa-times-circle"}"></i>
          ${order.is_paid ? "Оплачен" : "Не оплачен"}
        </span>
      </div>
      <div class="order-details">
        <div class="order-info">
          <p><i class="fas fa-calendar-alt"></i> <span>Дата:</span> ${formattedDate} ${formattedTime}</p>
          <p><i class="fas fa-gas-pump"></i> <span>Топливо:</span> ${order.fuel_type || "Не указано"}</p>
          <p><i class="fas fa-tint"></i> <span>Количество:</span> ${quantity} л</p>
          <p><i class="fas fa-ruble-sign"></i> <span>Цена за литр:</span> ${formattedPrice} ₽</p>
          <p><i class="fas fa-coins"></i> <span>Сумма заказа:</span> ${formattedTotal} ₽</p>
          <p><i class="fas fa-map-marker-alt"></i> <span>Адрес:</span> ${order.address || "Не указан"}</p>
        </div>
        <div class="customer-info">
          <h5><i class="fas fa-user"></i> Информация о клиенте</h5>
          <p><i class="fas fa-signature"></i> <span>Имя:</span> ${order.customer_name || "Не указано"}</p>
          <p><i class="fas fa-phone"></i> <span>Телефон:</span> ${order.customer_phone || "Не указано"}</p>
        </div>
      </div>
      <div class="order-actions">
        <button class="btn-secondary" onclick="статусOrderDetails(${order.id})">
          <i class="fas fa-eye"></i> Подробнее
        </button>
      </div>
    </div>
  `
}

// Функция для получения информации о статусе заказа
function getStatusInfo(status) {
  switch (status) {
    case "PENDING":
      return {
        class: "pending",
        text: "Ожидает подтверждения",
        icon: "fas fa-hourglass-half",
      }
    case "CONFIRMED":
      return {
        class: "confirmed",
        text: "Подтвержден",
        icon: "fas fa-check-circle",
      }
    case "IN_DELIVERY":
      return {
        class: "in-delivery",
        text: "В доставке",
        icon: "fas fa-truck",
      }
    case "DELIVERED":
      return {
        class: "delivered",
        text: "Доставлен",
        icon: "fas fa-check-double",
      }
    case "CANCELLED":
      return {
        class: "cancelled",
        text: "Отменен",
        icon: "fas fa-times-circle",
      }
    default:
      return {
        class: "unknown",
        text: "Неизвестный статус",
        icon: "fas fa-question-circle",
      }
  }
}

// Функция для отмены заказа
async function cancelOrder(orderId) {
  if (!confirm("Вы уверены, что хотите отменить заказ?")) {
    return
  }

  try {
    const response = await fetch("cancel-order.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        orderId: orderId,
      }),
    })

    const data = await response.json()

    if (data.success) {
      alert("Заказ успешно отменен")
      loadLastOrder() // Перезагружаем информацию о заказе
    } else {
      alert("Ошибка при отмене заказа: " + data.error)
    }
  } catch (error) {
    console.error("Ошибка при отмене заказа:", error)
    alert("Произошла ошибка при отмене заказа")
  }
}

// Загружаем последний заказ при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("ordersInfo")) {
    loadLastOrder()
  }
})

// Функции для работы с модальным окном заказа
document.addEventListener("DOMContentLoaded", () => {
  // Получаем элементы модального окна
  const modal = document.getElementById("orderModal")

  // Проверяем, существует ли модальное окно на странице
  if (!modal) {
    console.warn("Модальное окно заказа не найдено на странице")
    return // Прекращаем выполнение скрипта, если модального окна нет
  }

  const closeBtn = modal.querySelector(".close-modal")
  const cancelBtn = document.getElementById("cancelOrder")
  const orderForm = document.getElementById("orderForm")
  const quantityInput = document.getElementById("quantity")
  const orderMessage = document.getElementById("orderMessage")

  // Флаг для отслеживания отправки формы
  let isSubmitting = false

  // Устанавливаем минимальную дату доставки (завтра), но только если элемент существует
  const deliveryDateInput = document.getElementById("delivery_date")
  if (deliveryDateInput) {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    deliveryDateInput.min = tomorrow.toISOString().split("T")[0]
  } else {
    console.warn("Элемент delivery_date не найден на странице")
  }

  // Обработчики событий для закрытия модального окна
  if (closeBtn) {
    closeBtn.addEventListener("click", window.closeOrderModal)
  }

  if (cancelBtn) {
    cancelBtn.addEventListener("click", window.closeOrderModal)
  }

  // Закрытие модального окна при клике вне его содержимого
  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      window.closeOrderModal()
    }
  })

  // Обновление итоговой стоимости при изменении количества
  if (quantityInput) {
    quantityInput.addEventListener("input", () => {
      const fuelPriceInput = document.getElementById("fuel_price")
      if (!fuelPriceInput) return

      const priceText = fuelPriceInput.value
      const price = Number.parseFloat(priceText.replace(" ₽/л", ""))
      window.calculateTotalPrice(price)
    })
  }

  // Обработка отправки формы
  if (orderForm) {
    // Удаляем все существующие обработчики событий с формы
    const newOrderForm = orderForm.cloneNode(true)
    orderForm.parentNode.replaceChild(newOrderForm, orderForm)

    // Получаем новую ссылку на форму
    const refreshedOrderForm = document.getElementById("orderForm")

    refreshedOrderForm.addEventListener("submit", async (event) => {
      event.preventDefault()

      // Проверяем, не отправляется ли уже форма
      if (isSubmitting) {
        console.log("Форма уже отправляется, повторная отправка заблокирована")
        return false
      }

      // Устанавливаем флаг отправки
      isSubmitting = true

      // Получаем кнопку отправки
      const submitButton = refreshedOrderForm.querySelector('button[type="submit"]')
      if (submitButton) {
        submitButton.disabled = true
        submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Обработка...'
      }

      try {
        // Получаем данные формы
        const formData = new FormData(refreshedOrderForm)

        // Добавляем уникальный идентификатор запроса для предотвращения дублирования
        formData.append("request_id", Date.now().toString() + Math.random().toString(36).substr(2, 9))

        // Отправляем данные на сервер
        const response = await fetch("process-order.php", {
          method: "POST",
          body: formData,
        })

        const data = await response.json()

        if (!orderMessage) return

        if (data.success) {
          // Показываем сообщение об успешном оформлении заказа
          orderMessage.textContent = data.message
          orderMessage.className = "order-message success"
          orderMessage.style.display = "block"

          // Добавляем уведомление о новом заказе
          addOrderNotification()

          // Закрываем модальное окно через 3 секунды
          setTimeout(window.closeOrderModal, 3000)
        } else {
          // Показываем сообщение об ошибке
          orderMessage.textContent = data.message || "Произошла ошибка при оформлении заказа"
          orderMessage.className = "order-message error"
          orderMessage.style.display = "block"

          // Разблокируем кнопку отправки в случае ошибки
          if (submitButton) {
            submitButton.disabled = false
            submitButton.innerHTML = "Оформить заказ"
          }

          // Сбрасываем флаг отправки
          isSubmitting = false
        }
      } catch (error) {
        console.error("Ошибка:", error)
        if (orderMessage) {
          orderMessage.textContent = "Произошла ошибка при отправке данных"
          orderMessage.className = "order-message error"
          orderMessage.style.display = "block"
        }

        // Разблокируем кнопку отправки в случае ошибки
        if (submitButton) {
          submitButton.disabled = false
          submitButton.innerHTML = "Оформить заказ"
        }

        // Сбрасываем флаг отправки
        isSubmitting = false
      }
    })
  }

  // Функция для добавления уведомления о новом заказе
  function addOrderNotification() {
    // Получаем текущие данные пользователя
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")

    if (authData.isAuthenticated) {
      // Добавляем уведомление
      const userIcon = document.getElementById("user-icon")
      if (userIcon) {
        // Удаляем существующий значок, если есть
        const existingBadge = userIcon.querySelector(".notification-badge")
        if (existingBadge) {
          existingBadge.remove()
        }

        // Добавляем новый значок
        const badge = document.createElement("div")
        badge.className = "notification-badge"
        badge.textContent = "1"
        userIcon.appendChild(badge)
      }

      // Сохраняем информацию о новом заказе в sessionStorage
      sessionStorage.setItem("newOrder", "true")
    }


  // Проверяем, существует ли модальное окно на странице
  if (!modal) {
    console.warn("Модальное окно заказа не найдено на странице")
    return // Прекращаем выполнение скрипта, если модального окна нет
  }

  const closeBtn = modal.querySelector(".close-modal")
  const cancelBtn = document.getElementById("cancelOrder")
  const orderForm = document.getElementById("orderForm")
  const quantityInput = document.getElementById("quantity")
  const orderMessage = document.getElementById("orderMessage")

  // Устанавливаем минимальную дату доставки (завтра), но только если элемент существует
  const deliveryDateInput = document.getElementById("delivery_date")
  if (deliveryDateInput) {
    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    deliveryDateInput.min = tomorrow.toISOString().split("T")[0]
  } else {
    console.warn("Элемент delivery_date не найден на странице")
  }

  // Обработчики событий для закрытия модального окна
  if (closeBtn) {
    closeBtn.addEventListener("click", window.closeOrderModal)
  }

  if (cancelBtn) {
    cancelBtn.addEventListener("click", window.closeOrderModal)
  }

  // Закрытие модального окна при клике вне его содержимого
  window.addEventListener("click", (event) => {
    if (event.target === modal) {
      window.closeOrderModal()
    }
  })

  // Обновление итоговой стоимости при изменении количества
  if (quantityInput) {
    quantityInput.addEventListener("input", () => {
      const fuelPriceInput = document.getElementById("fuel_price")
      if (!fuelPriceInput) return

      const priceText = fuelPriceInput.value
      const price = Number.parseFloat(priceText.replace(" ₽/л", ""))
      window.calculateTotalPrice(price)
    })
  }

  // Обработка отправки формы
  if (orderForm) {
    orderForm.addEventListener("submit", (event) => {
      event.preventDefault()

      // Получаем данные формы
      const formData = new FormData(orderForm)

      // Отправляем данные на сервер
      fetch("process-order.php", {
        method: "POST",
        body: formData,
      })
        .then((response) => response.json())
        .then((data) => {
          if (!orderMessage) return

          if (data.success) {
            // Показываем сообщение об успешном оформлении заказа
            orderMessage.textContent = data.message
            orderMessage.className = "order-message success"
            orderMessage.style.display = "block"

            // Добавляем уведомление о новом заказе
            addOrderNotification()

            // Закрываем модальное окно через 3 секунды
            setTimeout(window.closeOrderModal, 3000)
          } else {
            // Показываем сообщение об ошибке
            orderMessage.textContent = data.message || "Произошла ошибка при оформлении заказа"
            orderMessage.className = "order-message error"
            orderMessage.style.display = "block"
          }
        })
        .catch((error) => {
          console.error("Ошибка:", error)
          if (orderMessage) {
            orderMessage.textContent = "Произошла ошибка при отправке данных"
            orderMessage.className = "order-message error"
            orderMessage.style.display = "block"
          }
        })
    })
  }

  // Функция для добавления уведомления о новом заказе
  function addOrderNotification() {
    // Получаем текущие данные пользователя
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")

    if (authData.isAuthenticated) {
      // Добавляем уведомление
      const userIcon = document.getElementById("user-icon")
      if (userIcon) {
        // Удаляем существующий значок, если есть
        const existingBadge = userIcon.querySelector(".notification-badge")
        if (existingBadge) {
          existingBadge.remove()
        }

        // Добавляем новый значок
        const badge = document.createElement("div")
        badge.className = "notification-badge"
        badge.textContent = "1"
        userIcon.appendChild(badge)
      }

      // Сохраняем информацию о новом заказе в sessionStorage
      sessionStorage.setItem("newOrder", "true")
    }
  }
}
})

