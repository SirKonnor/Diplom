<?php
header("Content-Type: application/json");
require_once 'config.php';

// Получение данных из запроса
$data = json_decode(file_get_contents('php://input'), true);
$userId = isset($data['userId']) ? $data['userId'] : null;
$userEmail = isset($data['userEmail']) ? $data['userEmail'] : null;
$adminId = isset($data['adminId']) ? $data['adminId'] : null;

// Проверка наличия необходимых данных
if (!$userId || !$userEmail || !$adminId) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Отсутствуют необходимые данные'
    ]);
    exit;
}

try {
    // Удаляем пользователя из черного списка
    $stmt = $pdo->prepare("DELETE FROM blacklist WHERE email = ?");
    $stmt->execute([$userEmail]);

    echo json_encode([
        'success' => true,
        'message' => 'Пользователь успешно разблокирован'
    ]);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных: ' . $e->getMessage()
    ]);
}
?>
