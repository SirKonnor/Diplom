<?php
header("Content-Type: application/json");
require_once 'config.php';

session_start();

// Включаем отображение всех ошибок для отладки
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Функция для логирования ошибок
function logError($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . PHP_EOL, 3, 'chat_errors.log');
}

// Логируем информацию о сессии для отладки
logError("Session data: " . json_encode($_SESSION));

// Проверяем авторизацию
$isAuthenticated = false;
$userId = null;

// Проверяем различные варианты хранения ID пользователя в сессии
if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user_id'];
    logError("Authenticated via user_id: " . $userId);
} 
elseif (isset($_SESSION['user']) && !empty($_SESSION['user']) && isset($_SESSION['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['user']['id'];
    logError("Authenticated via user.id: " . $userId);
}
elseif (isset($_SESSION['auth']) && !empty($_SESSION['auth']) && isset($_SESSION['auth']['user']['id'])) {
    $isAuthenticated = true;
    $userId = $_SESSION['auth']['user']['id'];
    logError("Authenticated via auth.user.id: " . $userId);
}

// Если пользователь не авторизован, возвращаем ошибку с кодом 200 вместо 401
if (!$isAuthenticated || !$userId) {
    logError("Authentication failed. Session: " . json_encode($_SESSION));
    echo json_encode([
        'success' => false, 
        'error' => 'Пользователь не авторизован',
        'count' => 0,
        'debug' => [
            'session' => $_SESSION
        ]
    ]);
    exit;
}

try {
    // Проверяем существование таблицы messages
    $tableCheckStmt = $pdo->query("SHOW TABLES LIKE 'messages'");
    if ($tableCheckStmt->rowCount() === 0) {
        // Таблица не существует, возвращаем 0 непрочитанных сообщений
        echo json_encode(['success' => true, 'count' => 0]);
        exit;
    }
    
    // Проверяем структуру таблицы messages
    $columnCheckStmt = $pdo->query("SHOW COLUMNS FROM messages LIKE 'is_read'");
    $hasIsReadColumn = $columnCheckStmt->rowCount() > 0;
    
    if (!$hasIsReadColumn) {
        // Колонка is_read не существует, возвращаем 0 непрочитанных сообщений
        echo json_encode(['success' => true, 'count' => 0]);
        exit;
    }
    
    // Получаем количество непрочитанных сообщений для пользователя
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM messages 
                          WHERE receiver_id = :userId 
                          AND is_read = 0");
    
    $stmt->execute([':userId' => $userId]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'count' => (int)$result['count']
    ]);
    
} catch (PDOException $e) {
    logError("Database error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage(),
        'count' => 0
    ]);
}
?>