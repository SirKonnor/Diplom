// Проверяем авторизацию при загрузке страницы
document.addEventListener("DOMContentLoaded", () => {
    const authData = JSON.parse(sessionStorage.getItem("auth") || "{}")
    const userIcon = document.getElementById("user-icon")
  
    if (authData.isAuthenticated) {
      userIcon.href = "profile.html"
      userIcon.innerHTML = '<i class="fas fa-user-check"></i>'
  
      if (authData.user && authData.user.id) {
        checkUnreadMessages(authData.user.id)
      }
    }
  
    // Анимация при прокрутке
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible")
          }
        })
      },
      {
        threshold: 0.1,
        rootMargin: "0px 0px -50px 0px",
      },
    )
  
    document.querySelectorAll(".hidden").forEach((element) => {
      observer.observe(element)
    })
  
    // Анимация счетчиков
    animateCounters()
  
    // Эффект параллакса при прокрутке
    window.addEventListener("scroll", () => {
      const scrollPosition = window.scrollY
  
      // Эффект для плавающих элементов
      const floatingElements = document.querySelectorAll(".floating-element")
      floatingElements.forEach((element, index) => {
        const speed = 0.05 + (index * 0.02)
        element.style.transform = `translateY(${scrollPosition * speed}px) rotate(${scrollPosition * 0.02}deg)`
      })
  
      // Эффект для шапки при прокрутке
      const header = document.querySelector(".header-container")
      if (header) {
        if (scrollPosition > 50) {
          header.classList.add("scrolled")
        } else {
          header.classList.remove("scrolled")
        }
      }
      
      // Эффект для временной шкалы
      const timelineItems = document.querySelectorAll(".timeline-item")
      timelineItems.forEach((item) => {
        const itemTop = item.getBoundingClientRect().top
        if (itemTop < window.innerHeight * 0.8) {
          item.classList.add("visible")
        }
      })
    })
    
    // Анимация для карточек команды
    const teamMembers = document.querySelectorAll(".team-member")
    teamMembers.forEach((member, index) => {
      setTimeout(() => {
        member.classList.add("visible")
      }, 300 * index)
    })
    
    // Анимация для карточек ценностей
    const valueItems = document.querySelectorAll(".value-item")
    valueItems.forEach((item, index) => {
      setTimeout(() => {
        item.classList.add("visible")
      }, 200 * index)
    })
})

// Функция анимации счетчиков
function animateCounters() {
  const counters = document.querySelectorAll(".stat-number")
  
  const animateCounter = (counter) => {
    const target = parseInt(counter.getAttribute("data-target"))
    const duration = 2000 // 2 секунды
    const increment = target / (duration / 16) // 60 FPS
    let current = 0
    
    const updateCounter = () => {
      if (current < target) {
        current += increment
        counter.textContent = Math.floor(current)
        requestAnimationFrame(updateCounter)
      } else {
        counter.textContent = target
      }
    }
    
    updateCounter()
  }
  
  // Запускаем анимацию счетчиков при появлении в области видимости
  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const counter = entry.target
          if (!counter.classList.contains("animated")) {
            counter.classList.add("animated")
            setTimeout(() => animateCounter(counter), 500)
          }
        }
      })
    },
    { threshold: 0.5 }
  )
  
  counters.forEach((counter) => {
    counterObserver.observe(counter)
  })
}

// Функция для проверки непрочитанных сообщений
async function checkUnreadMessages(userId) {
  try {
    const response = await fetch("get-unread-messages-count.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        userId: userId,
      }),
    })

    const data = await response.json()

    if (data.success) {
      updateNotificationBadges(data.count)
    }
  } catch (error) {
    console.error("Ошибка получения непрочитанных сообщений:", error)
  }
}

// Функция для обновления значков уведомлений
function updateNotificationBadges(count) {
  const userIcon = document.getElementById("user-icon")

  if (userIcon) {
    const existingBadge = userIcon.querySelector(".notification-badge")
    if (existingBadge) {
      existingBadge.remove()
    }

    if (count > 0) {
      const badge = document.createElement("div")
      badge.className = "notification-badge"
      badge.textContent = count > 9 ? "9+" : count
      userIcon.appendChild(badge)
    }
  }
}

// Плавная прокрутка для якорных ссылок
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute('href'))
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      })
    }
  })
})

// Анимация для элементов при прокрутке
function animateOnScroll() {
  const elements = document.querySelectorAll('.about-features .feature, .timeline-item, .team-member, .value-item')
  
  elements.forEach(element => {
    const elementTop = element.getBoundingClientRect().top
    const elementBottom = element.getBoundingClientRect().bottom
    
    if (elementTop < window.innerHeight * 0.8 && elementBottom > 0) {
      element.classList.add('visible')
    }
  })
}

// Запускаем анимацию при прокрутке
window.addEventListener('scroll', animateOnScroll)
window.addEventListener('load', animateOnScroll)