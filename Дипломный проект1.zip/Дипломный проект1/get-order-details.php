<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['orderId']) || empty($data['orderId'])) {
        throw new Exception('Order ID is required');
    }
    
    $orderId = $data['orderId'];
    
    // Get user ID from request or session
    if (isset($data['userId'])) {
        $userId = $data['userId'];
    } else {
        // Get user ID from session
        $authData = isset($_SESSION['auth']) ? $_SESSION['auth'] : null;
        if (!$authData || !isset($authData['user']) || !isset($authData['user']['id'])) {
            throw new Exception('User not authenticated');
        }
        $userId = $authData['user']['id'];
    }
    
    // Check if user is admin
    $isAdmin = isset($data['isAdmin']) ? $data['isAdmin'] : false;
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Get order details
try {
    // Check if orders table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'orders'");
    if ($stmt->rowCount() === 0) {
        throw new Exception('Orders table does not exist');
    }
    
    // Check if the reason column exists in the orders table
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'reason'");
    $reasonColumnExists = $stmt->rowCount() > 0;
    
    // If reason column doesn't exist, add it
    if (!$reasonColumnExists) {
        $pdo->exec("ALTER TABLE orders ADD COLUMN reason TEXT");
    }
    
    // Get the order
    $stmt = $pdo->prepare("SELECT *, is_paid FROM orders WHERE id = :orderId");
    $stmt->execute(['orderId' => $orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception('Order not found');
    }
    
    // Check if the order belongs to the user or if user is admin
    if ($order['user_id'] != $userId && !$isAdmin) {
        throw new Exception('You do not have permission to view this order');
    }
    
    // If admin, get user data
    $userData = null;
    if ($isAdmin) {
        // Check if users table exists
        $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
        if ($stmt->rowCount() > 0) {
            // Get user data with more fields
            $stmt = $pdo->prepare("SELECT id, firstName, lastName, email, phone, address, role, date_registration FROM users WHERE id = :userId");
            $stmt->execute(['userId' => $order['user_id']]);
            $userData = $stmt->fetch(PDO::FETCH_ASSOC);
        }
    
        // If user data not found in users table, try to get from user table (alternative name)
        if (!$userData) {
            $stmt = $pdo->query("SHOW TABLES LIKE 'user'");
            if ($stmt->rowCount() > 0) {
                $stmt = $pdo->prepare("SELECT id, firstName, lastName, email, phone, address, role, date_registration FROM user WHERE id = :userId");
                $stmt->execute(['userId' => $order['user_id']]);
                $userData = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }
    
        // If still no user data, at least return the user_id
        if (!$userData) {
            $userData = ['id' => $order['user_id'], 'note' => 'Limited user information available'];
        }
    }
    
    echo json_encode([
        'success' => true,
        'order' => $order,
        'userData' => $userData
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
