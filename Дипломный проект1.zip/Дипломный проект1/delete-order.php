<?php
// Ensure we're always returning JSON
header('Content-Type: application/json');

// Turn off error display in the output
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Start the session
session_start();

// Try to include the config file
try {
    if (!file_exists('config.php')) {
        throw new Exception('Configuration file not found');
    }
    require_once 'config.php';
    
    // Check if $pdo is defined in config.php
    if (!isset($pdo) || !($pdo instanceof PDO)) {
        throw new Exception('Database connection not properly initialized in config.php');
    }
} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Configuration error: ' . $e->getMessage()
    ]);
    exit;
}

// Validate request method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Get and validate input data
try {
    $input = file_get_contents('php://input');
    if (!$input) {
        throw new Exception('No input data provided');
    }
    
    $data = json_decode($input, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON: ' . json_last_error_msg());
    }
    
    if (!isset($data['orderId']) || empty($data['orderId'])) {
        throw new Exception('Order ID is required');
    }
    
    $orderId = $data['orderId'];
    
    // Check if user is admin
    $isAdmin = isset($data['isAdmin']) ? $data['isAdmin'] : false;
    
    // Get the user ID from the request
    $userId = isset($data['userId']) ? $data['userId'] : null;

    // Check if the order belongs to the user or if user is admin
    if (!$isAdmin && !$userId) {
        throw new Exception('User ID is required for non-admin users');
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Input error: ' . $e->getMessage()]);
    exit;
}

// Delete the order
try {
    // First check if the order exists
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = :orderId");
    $stmt->execute(['orderId' => $orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        throw new Exception('Order not found');
    }
    
    // If not admin, check if the order belongs to the user
    if (!$isAdmin && $order['user_id'] != $userId) {
        throw new Exception('You can only delete your own orders');
    }

    // Check if the order can be deleted (only PENDING or CONFIRMED orders can be deleted by regular users)
    if (!$isAdmin && $order['status'] !== 'PENDING' && $order['status'] !== 'CONFIRMED') {
        throw new Exception('This order cannot be deleted because it is already ' . strtolower($order['status']));
    }
    
    // Delete the order
    $stmt = $pdo->prepare("DELETE FROM orders WHERE id = :orderId");
    $stmt->execute(['orderId' => $orderId]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Order deleted successfully'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>
