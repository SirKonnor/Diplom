/**
 * Универсальная система отслеживания статуса пользователей
 * Автоматически управляет статусами: Online, Away, Offline
 * Подключается одним файлом ко всем страницам
 */

class UserStatusManager {
  constructor() {
    this.config = {
      // Интервалы обновления (в миллисекундах)
      statusUpdateInterval: 15000, // Обновление статуса каждые 15 сек
      activityCheckInterval: 30000, // Проверка активности каждые 30 сек
      awayTimeout: 300000, // Неактивность 5 минут = Away

      // API endpoints
      updateStatusUrl: "update-user-status.php",

      // Настройки отслеживания
      trackMouseMovement: true,
      trackClicks: true,
      trackScroll: true,
      trackKeyboard: true,
      trackVisibility: true,
    }

    this.state = {
      currentStatus: "offline",
      lastActivity: Date.now(),
      isPageVisible: true,
      isInitialized: false,
      userId: null,
      intervals: {
        statusUpdate: null,
        activityCheck: null,
      },
    }

    this.activityEvents = ["mousedown", "mousemove", "keypress", "scroll", "touchstart", "click", "focus", "blur"]

    // Автоматическая инициализация
    this.init()
  }

  /**
   * Инициализация системы
   */
  async init() {
    try {
      // Получаем ID пользователя из sessionStorage
      const authData = this.getAuthData()
      if (!authData || !authData.isAuthenticated) {
        console.log("StatusManager: Пользователь не авторизован")
        return
      }

      this.state.userId = authData.user.id
      console.log("StatusManager: Инициализация для пользователя ID:", this.state.userId)

      // Настраиваем отслеживание активности
      this.setupActivityTracking()

      // Настраиваем отслеживание видимости страницы
      this.setupVisibilityTracking()

      // Устанавливаем статус "онлайн"
      await this.updateStatus("online")

      // Запускаем интервалы
      this.startIntervals()

      // Обработчики закрытия страницы
      this.setupUnloadHandlers()

      this.state.isInitialized = true
      console.log("StatusManager: Инициализация завершена")

      // Уведомляем о готовности системы
      this.dispatchEvent("statusManagerReady", { userId: this.state.userId })
    } catch (error) {
      console.error("StatusManager: Ошибка инициализации:", error)
    }
  }

  /**
   * Получение данных авторизации
   */
  getAuthData() {
    try {
      return JSON.parse(sessionStorage.getItem("auth") || "{}")
    } catch (error) {
      console.error("StatusManager: Ошибка получения данных авторизации:", error)
      return null
    }
  }

  /**
   * Настройка отслеживания активности пользователя
   */
  setupActivityTracking() {
    // Отслеживаем различные события активности
    this.activityEvents.forEach((eventType) => {
      document.addEventListener(
        eventType,
        () => {
          this.recordActivity()
        },
        { passive: true },
      )
    })

    // Дополнительное отслеживание для мобильных устройств
    if ("ontouchstart" in window) {
      document.addEventListener(
        "touchmove",
        () => {
          this.recordActivity()
        },
        { passive: true },
      )
    }

    console.log("StatusManager: Отслеживание активности настроено")
  }

  /**
   * Настройка отслеживания видимости страницы
   */
  setupVisibilityTracking() {
    // Page Visibility API
    document.addEventListener("visibilitychange", () => {
      this.state.isPageVisible = !document.hidden

      if (this.state.isPageVisible) {
        console.log("StatusManager: Страница стала видимой")
        this.recordActivity()
        this.updateStatus("online")
      } else {
        console.log("StatusManager: Страница скрыта")
        this.updateStatus("away")
      }
    })

    // Отслеживание фокуса окна
    window.addEventListener("focus", () => {
      this.state.isPageVisible = true
      this.recordActivity()
      this.updateStatus("online")
    })

    window.addEventListener("blur", () => {
      this.state.isPageVisible = false
      this.updateStatus("away")
    })

    console.log("StatusManager: Отслеживание видимости настроено")
  }

  /**
   * Запись активности пользователя
   */
  recordActivity() {
    const now = Date.now()
    this.state.lastActivity = now

    // Если пользователь был неактивен, возвращаем статус "онлайн"
    if (this.state.currentStatus === "away" && this.state.isPageVisible) {
      this.updateStatus("online")
    }
  }

  /**
   * Проверка активности и обновление статуса
   */
  checkActivityAndUpdateStatus() {
    if (!this.state.isInitialized || !this.state.userId) return

    const now = Date.now()
    const timeSinceLastActivity = now - this.state.lastActivity
    const isPageVisible = this.state.isPageVisible

    let newStatus = this.state.currentStatus

    if (!isPageVisible) {
      // Страница не видна - статус "away"
      newStatus = "away"
    } else if (timeSinceLastActivity > this.config.awayTimeout) {
      // Долгое время неактивности - статус "away"
      newStatus = "away"
    } else {
      // Активен и страница видна - статус "online"
      newStatus = "online"
    }

    // Обновляем статус только если он изменился
    if (newStatus !== this.state.currentStatus) {
      this.updateStatus(newStatus)
    }
  }

  /**
   * Обновление статуса пользователя на сервере
   */
  async updateStatus(status) {
    if (!this.state.userId) return

    try {
      const response = await fetch(this.config.updateStatusUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: this.state.userId,
          status: status,
        }),
      })

      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          const oldStatus = this.state.currentStatus
          this.state.currentStatus = status

          // Логируем изменение статуса
          if (oldStatus !== status) {
            console.log(`StatusManager: Статус изменен с "${oldStatus}" на "${status}"`)

            // Уведомляем о смене статуса
            this.dispatchEvent("statusChanged", {
              userId: this.state.userId,
              oldStatus: oldStatus,
              newStatus: status,
              timestamp: Date.now(),
            })
          }
        }
      }
    } catch (error) {
      console.error("StatusManager: Ошибка обновления статуса:", error)
    }
  }

  /**
   * Запуск интервалов обновления
   */
  startIntervals() {
    // Интервал регулярного обновления статуса
    this.state.intervals.statusUpdate = setInterval(() => {
      if (this.state.currentStatus === "online") {
        this.updateStatus("online")
      }
    }, this.config.statusUpdateInterval)

    // Интервал проверки активности
    this.state.intervals.activityCheck = setInterval(() => {
      this.checkActivityAndUpdateStatus()
    }, this.config.activityCheckInterval)

    console.log("StatusManager: Интервалы запущены")
  }

  /**
   * Остановка интервалов
   */
  stopIntervals() {
    Object.values(this.state.intervals).forEach((interval) => {
      if (interval) {
        clearInterval(interval)
      }
    })

    this.state.intervals = {
      statusUpdate: null,
      activityCheck: null,
    }

    console.log("StatusManager: Интервалы остановлены")
  }

  /**
   * Настройка обработчиков закрытия страницы
   */
  setupUnloadHandlers() {
    // Обработчик закрытия страницы
    window.addEventListener("beforeunload", () => {
      this.handlePageUnload()
    })

    // Обработчик для мобильных устройств
    window.addEventListener("pagehide", () => {
      this.handlePageUnload()
    })

    // Обработчик изменения URL (для SPA)
    window.addEventListener("popstate", () => {
      this.recordActivity()
    })
  }

  /**
   * Обработка закрытия страницы
   */
  handlePageUnload() {
    console.log("StatusManager: Страница закрывается")

    // Останавливаем интервалы
    this.stopIntervals()

    // Устанавливаем статус "offline" синхронно
    if (this.state.userId) {
      // Используем sendBeacon для надежной отправки при закрытии страницы
      const data = JSON.stringify({
        userId: this.state.userId,
        status: "offline",
      })

      if (navigator.sendBeacon) {
        navigator.sendBeacon(this.config.updateStatusUrl, data)
      } else {
        // Fallback для старых браузеров
        const xhr = new XMLHttpRequest()
        xhr.open("POST", this.config.updateStatusUrl, false) // синхронный запрос
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(data)
      }
    }
  }

  /**
   * Отправка пользовательских событий
   */
  dispatchEvent(eventName, detail) {
    const event = new CustomEvent(`userStatus:${eventName}`, {
      detail: detail,
      bubbles: true,
    })
    document.dispatchEvent(event)
  }

  /**
   * Получение текущего статуса
   */
  getCurrentStatus() {
    return {
      status: this.state.currentStatus,
      userId: this.state.userId,
      lastActivity: this.state.lastActivity,
      isPageVisible: this.state.isPageVisible,
      isInitialized: this.state.isInitialized,
    }
  }

  /**
   * Принудительное обновление статуса
   */
  async forceUpdateStatus(status) {
    if (["online", "away", "offline"].includes(status)) {
      await this.updateStatus(status)
      return true
    }
    return false
  }

  /**
   * Уничтожение экземпляра
   */
  destroy() {
    console.log("StatusManager: Уничтожение экземпляра")

    // Останавливаем интервалы
    this.stopIntervals()

    // Устанавливаем статус offline
    if (this.state.userId) {
      this.updateStatus("offline")
    }

    // Удаляем обработчики событий
    this.activityEvents.forEach((eventType) => {
      document.removeEventListener(eventType, this.recordActivity)
    })

    this.state.isInitialized = false
  }
}

// Глобальная инициализация
let userStatusManager = null

// Автоматический запуск при загрузке DOM
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeStatusManager)
} else {
  initializeStatusManager()
}

function initializeStatusManager() {
  // Предотвращаем множественную инициализацию
  if (userStatusManager) {
    console.log("StatusManager: Уже инициализирован")
    return
  }

  userStatusManager = new UserStatusManager()

  // Делаем доступным глобально для отладки
  window.UserStatusManager = userStatusManager
}

// API для внешнего использования
window.StatusManagerAPI = {
  /**
   * Получить текущий статус
   */
  getStatus: () => {
    return userStatusManager ? userStatusManager.getCurrentStatus() : null
  },

  /**
   * Принудительно установить статус
   */
  setStatus: (status) => {
    return userStatusManager ? userStatusManager.forceUpdateStatus(status) : false
  },

  /**
   * Записать активность
   */
  recordActivity: () => {
    if (userStatusManager) {
      userStatusManager.recordActivity()
    }
  },

  /**
   * Проверить инициализацию
   */
  isReady: () => {
    return userStatusManager ? userStatusManager.state.isInitialized : false
  },
}

// Экспорт для модульных систем
if (typeof module !== "undefined" && module.exports) {
  module.exports = UserStatusManager
}

console.log("StatusManager: Скрипт загружен")
