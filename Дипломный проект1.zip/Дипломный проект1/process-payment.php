<?php
header('Content-Type: application/json');
session_start();

require_once 'config.php';
require_once 'payment-config.php';

// Класс для работы с платежными системами
class PaymentProcessor {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    // Получение информации о заказе
    public function getOrderInfo($orderId) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM orders WHERE id = :orderId");
            $stmt->execute(['orderId' => $orderId]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return false;
        }
    }
    
    // Создание платежа через ЮKassa
    public function createYuKassaPayment($order, $returnUrl) {
        $data = [
            'amount' => [
                'value' => number_format($order['total_price'], 2, '.', ''),
                'currency' => PAYMENT_CURRENCY
            ],
            'confirmation' => [
                'type' => 'redirect',
                'return_url' => $returnUrl
            ],
            'capture' => true,
            'description' => "Оплата заказа #{$order['id']} - {$order['fuel_name']} ({$order['quantity']} л)",
            'metadata' => [
                'order_id' => $order['id'],
                'user_id' => $order['user_id']
            ]
        ];
        
        $headers = [
            'Authorization: Basic ' . base64_encode(YUKASSA_SHOP_ID . ':' . YUKASSA_SECRET_KEY),
            'Content-Type: application/json',
            'Idempotence-Key: ' . uniqid('', true)
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, YUKASSA_API_URL . 'payments');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $result = json_decode($response, true);
            if ($result && isset($result['confirmation']['confirmation_url'])) {
                // Сохраняем ID платежа в базе данных
                $this->savePaymentId($order['id'], $result['id'], 'yukassa');
                return [
                    'success' => true,
                    'payment_url' => $result['confirmation']['confirmation_url'],
                    'payment_id' => $result['id']
                ];
            }
        }
        
        error_log("YuKassa payment creation failed: " . $response);
        return ['success' => false, 'error' => 'Ошибка создания платежа в ЮKassa'];
    }
    
    // Создание платежа через Сбербанк
    public function createSberbankPayment($order, $returnUrl) {
        $data = [
            'userName' => SBERBANK_USERNAME,
            'password' => SBERBANK_PASSWORD,
            'orderNumber' => 'ORDER_' . $order['id'] . '_' . time(),
            'amount' => intval($order['total_price'] * 100), // В копейках
            'currency' => '643', // RUB
            'returnUrl' => $returnUrl,
            'failUrl' => PAYMENT_FAIL_URL,
            'description' => "Заказ #{$order['id']} - {$order['fuel_name']} ({$order['quantity']} л)"
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, SBERBANK_API_URL . 'register.do');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if ($result && isset($result['formUrl']) && $result['errorCode'] === 0) {
            // Сохраняем ID платежа в базе данных
            $this->savePaymentId($order['id'], $result['orderId'], 'sberbank');
            return [
                'success' => true,
                'payment_url' => $result['formUrl'],
                'payment_id' => $result['orderId']
            ];
        }
        
        error_log("Sberbank payment creation failed: " . $response);
        return ['success' => false, 'error' => 'Ошибка создания платежа в Сбербанке'];
    }
    
    // Создание платежа через Тинькофф
    public function createTinkoffPayment($order, $returnUrl) {
        $data = [
            'TerminalKey' => TINKOFF_TERMINAL_KEY,
            'Amount' => intval($order['total_price'] * 100), // В копейках
            'OrderId' => 'ORDER_' . $order['id'] . '_' . time(),
            'Description' => "Заказ #{$order['id']} - {$order['fuel_name']} ({$order['quantity']} л)",
            'SuccessURL' => $returnUrl,
            'FailURL' => PAYMENT_FAIL_URL,
            'NotificationURL' => PAYMENT_NOTIFICATION_URL
        ];
        
        // Генерируем токен
        $data['Token'] = $this->generateTinkoffToken($data);
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, TINKOFF_API_URL . 'Init');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $result = json_decode($response, true);
        
        if ($result && $result['Success'] && isset($result['PaymentURL'])) {
            // Сохраняем ID платежа в базе данных
            $this->savePaymentId($order['id'], $result['PaymentId'], 'tinkoff');
            return [
                'success' => true,
                'payment_url' => $result['PaymentURL'],
                'payment_id' => $result['PaymentId']
            ];
        }
        
        error_log("Tinkoff payment creation failed: " . $response);
        return ['success' => false, 'error' => 'Ошибка создания платежа в Тинькофф'];
    }
    
    // Генерация токена для Тинькофф
    private function generateTinkoffToken($data) {
        $data['Password'] = TINKOFF_SECRET_KEY;
        ksort($data);
        $values = array_values($data);
        return hash('sha256', implode('', $values));
    }
    
    // Сохранение ID платежа в базе данных
    private function savePaymentId($orderId, $paymentId, $paymentSystem) {
        try {
            // Проверяем, есть ли колонка payment_id в таблице orders
            $stmt = $this->pdo->query("SHOW COLUMNS FROM orders LIKE 'payment_id'");
            if ($stmt->rowCount() === 0) {
                // Добавляем колонки для платежной информации
                $this->pdo->exec("ALTER TABLE orders ADD COLUMN payment_id VARCHAR(255) DEFAULT NULL");
                $this->pdo->exec("ALTER TABLE orders ADD COLUMN payment_system VARCHAR(50) DEFAULT NULL");
                $this->pdo->exec("ALTER TABLE orders ADD COLUMN payment_status VARCHAR(50) DEFAULT 'pending'");
            }
            
            $stmt = $this->pdo->prepare("UPDATE orders SET payment_id = :payment_id, payment_system = :payment_system, payment_status = 'pending' WHERE id = :order_id");
            $stmt->execute([
                'payment_id' => $paymentId,
                'payment_system' => $paymentSystem,
                'order_id' => $orderId
            ]);
            
            return true;
        } catch (PDOException $e) {
            error_log("Error saving payment ID: " . $e->getMessage());
            return false;
        }
    }
    
    // Обновление статуса оплаты
    public function updatePaymentStatus($orderId, $status) {
        try {
            $isPaid = ($status === 'succeeded' || $status === 'paid') ? 1 : 0;
            $stmt = $this->pdo->prepare("UPDATE orders SET is_paid = :is_paid, payment_status = :status WHERE id = :order_id");
            $stmt->execute([
                'is_paid' => $isPaid,
                'status' => $status,
                'order_id' => $orderId
            ]);
            return true;
        } catch (PDOException $e) {
            error_log("Error updating payment status: " . $e->getMessage());
            return false;
        }
    }
}

// Обработка запроса
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Неверный метод запроса']);
    exit;
}

// Получаем данные запроса
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!isset($data['orderId']) || empty($data['orderId'])) {
    echo json_encode(['success' => false, 'message' => 'Не указан ID заказа']);
    exit;
}

if (!isset($data['paymentSystem']) || empty($data['paymentSystem'])) {
    echo json_encode(['success' => false, 'message' => 'Не выбрана платежная система']);
    exit;
}

$orderId = $data['orderId'];
$paymentSystem = $data['paymentSystem'];
$returnUrl = isset($data['returnUrl']) ? $data['returnUrl'] : PAYMENT_SUCCESS_URL;

// Создаем экземпляр процессора платежей
$processor = new PaymentProcessor($pdo);

// Получаем информацию о заказе
$order = $processor->getOrderInfo($orderId);

if (!$order) {
    echo json_encode(['success' => false, 'message' => 'Заказ не найден']);
    exit;
}

// Проверяем, не оплачен ли уже заказ
if ($order['is_paid']) {
    echo json_encode(['success' => false, 'message' => 'Заказ уже оплачен']);
    exit;
}

// Создаем платеж в зависимости от выбранной системы
$result = ['success' => false, 'message' => 'Неподдерживаемая платежная система'];

switch ($paymentSystem) {
    case 'yukassa':
        $result = $processor->createYuKassaPayment($order, $returnUrl);
        break;
        
    case 'sberbank':
        $result = $processor->createSberbankPayment($order, $returnUrl);
        break;
        
    case 'tinkoff':
        $result = $processor->createTinkoffPayment($order, $returnUrl);
        break;
        
    default:
        $result = ['success' => false, 'message' => 'Неподдерживаемая платежная система: ' . $paymentSystem];
        break;
}

echo json_encode($result);
?>
