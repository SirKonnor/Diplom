document.addEventListener("DOMContentLoaded", () => {
  // Password visibility toggle
  const togglePassword = document.querySelector(".toggle-password")
  const passwordInput = document.getElementById("password")

  if (togglePassword && passwordInput) {
    togglePassword.addEventListener("click", function () {
      // Toggle the type attribute
      const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
      passwordInput.setAttribute("type", type)

      // Toggle the icon
      this.classList.toggle("fa-eye")
      this.classList.toggle("fa-eye-slash")
    })
  }

  const loginForm = document.getElementById("loginForm")
  const errorMessage = document.getElementById("errorMessage")

  // Проверка авторизации при загрузке страницы
  if (sessionStorage.getItem("auth")) {
    window.location.href = "profile.html"
  }

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault()
    errorMessage.style.display = "none"

    const email = document.getElementById("email").value.trim()
    const password = document.getElementById("password").value.trim()

    // Базовая валидация на клиенте
    if (!email || !password) {
      showError("Заполните все поля")
      return
    }

    try {
      const response = await fetch("login.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
      })

      const data = await response.json()

      if (!response.ok) {
        // Обработка HTTP ошибок
        throw new Error(data.error || "Ошибка сервера")
      }

      if (!data.success) {
        // Обработка ошибок авторизации
        handleAuthError(data.error_code, data.error)
        return
      }

      // Сохраняем данные авторизации
      sessionStorage.setItem(
        "auth",
        JSON.stringify({
          isAuthenticated: true,
          user: {
            id: data.user.id,
            firstName: data.user.first_name,
            lastName: data.user.last_name,
            email: data.user.email,
            phone: data.user.phone,
            address: data.user.address,
            date_registration: data.user.date_registration,
            role: data.user.role,
            avatar_path: data.user.avatar_path,
          },
        }),
      )

      // Перенаправляем на главную
      window.location.href = "index.html"
    } catch (error) {
      showError(error.message || "Ошибка при авторизации")
      console.error("Ошибка:", error)
    }
  })

  function handleAuthError(errorCode, errorMessage) {
    // Обработка различных типов ошибок авторизации
    switch (errorCode) {
      case "EMAIL_NOT_FOUND":
        showError("Пользователь с такой почтой не найден")
        highlightField("email")
        break
      case "INVALID_PASSWORD":
        showError("Неверный пароль")
        highlightField("password")
        break
      case "ACCOUNT_DISABLED":
        showError("Аккаунт заблокирован. Обратитесь в поддержку")
        break
      case "TOO_MANY_ATTEMPTS":
        showError("Слишком много попыток входа. Попробуйте позже")
        break
      default:
        showError(errorMessage || "Ошибка авторизации")
    }
  }

  function showError(message) {
    errorMessage.textContent = message
    errorMessage.style.display = "block"

    // Добавляем анимацию встряхивания
    errorMessage.classList.remove("shake")
    void errorMessage.offsetWidth // Сброс анимации
    errorMessage.classList.add("shake")
  }

  function highlightField(fieldId) {
    const field = document.getElementById(fieldId)
    if (field) {
      field.classList.add("error-field")

      // Удаляем класс ошибки через некоторое время
      setTimeout(() => {
        field.classList.remove("error-field")
      }, 3000)

      // Фокусируемся на поле с ошибкой
      field.focus()
    }
  }
})
