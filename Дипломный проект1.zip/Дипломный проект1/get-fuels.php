<?php
require_once 'config.php';

function getFuels() {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM fuels");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        return [];
    }
}
?>
