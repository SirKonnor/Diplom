<?php
// Улучшенный скрипт для получения курсов валют с автоматическим обновлением
header('Content-Type: application/json; charset=utf-8');

// Отключаем вывод ошибок в браузер
ini_set('display_errors', 0);
error_reporting(0);

try {
    // Подключение к базе данных
    require_once 'config.php';

    // Проверяем подключение к базе данных
    if (!isset($pdo)) {
        throw new Exception('Ошибка подключения к базе данных');
    }

    // Получаем курсы валют из базы данных
    $stmt = $pdo->prepare("
        SELECT 
            currency_code,
            current_rate,
            previous_rate,
            rate_change,
            change_percentage,
            trend,
            last_updated,
            TIMESTAMPDIFF(MINUTE, last_updated, NOW()) as minutes_since_update
        FROM currency_rates 
        WHERE currency_code IN ('USD', 'EUR')
        ORDER BY currency_code
    ");
    
    $stmt->execute();
    $rates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Проверяем, нужно ли обновить данные (если прошло больше 10 минут)
    $needsUpdate = false;
    if (empty($rates)) {
        $needsUpdate = true;
    } else {
        foreach ($rates as $rate) {
            if ($rate['minutes_since_update'] > 10) {
                $needsUpdate = true;
                break;
            }
        }
    }
    
    // Если нужно обновление, запускаем его
    if ($needsUpdate) {
        // Запускаем обновление в фоне (не блокируем ответ)
        $updateUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/update_currency_rates.php';
        
        // Асинхронный запрос для обновления
        $context = stream_context_create([
            'http' => [
                'timeout' => 1, // Короткий таймаут, чтобы не блокировать
                'ignore_errors' => true
            ]
        ]);
        
        // Запускаем обновление, но не ждем результата
        @file_get_contents($updateUrl, false, $context);
    }
    
    if (empty($rates)) {
        // Если данных все еще нет, создаем базовые записи
        $defaultRates = [
            ['code' => 'USD', 'rate' => 92.50],
            ['code' => 'EUR', 'rate' => 102.30]
        ];
        
        foreach ($defaultRates as $rate) {
            $insertStmt = $pdo->prepare("
                INSERT INTO currency_rates (currency_code, current_rate, previous_rate, rate_change, change_percentage, trend) 
                VALUES (?, ?, ?, 0.0000, 0.00, 'neutral')
                ON DUPLICATE KEY UPDATE
                    current_rate = VALUES(current_rate),
                    last_updated = CURRENT_TIMESTAMP
            ");
            $insertStmt->execute([$rate['code'], $rate['rate'], $rate['rate']]);
        }
        
        // Повторно получаем данные
        $stmt->execute();
        $rates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Форматируем данные для фронтенда
    $formattedRates = [];
    foreach ($rates as $rate) {
        $formattedRates[strtolower($rate['currency_code'])] = [
            'rate' => number_format($rate['current_rate'], 2, '.', ''),
            'change' => number_format($rate['rate_change'], 2, '.', ''),
            'percentage' => number_format($rate['change_percentage'], 2, '.', ''),
            'trend' => $rate['trend'],
            'last_updated' => $rate['last_updated'],
            'minutes_since_update' => $rate['minutes_since_update'] ?? 0
        ];
    }
    
    // Если все еще нет данных, используем значения по умолчанию
    if (empty($formattedRates)) {
        $formattedRates = [
            'usd' => [
                'rate' => '92.50',
                'change' => '0.00',
                'percentage' => '0.00',
                'trend' => 'neutral',
                'last_updated' => date('Y-m-d H:i:s'),
                'minutes_since_update' => 0
            ],
            'eur' => [
                'rate' => '102.30',
                'change' => '0.00',
                'percentage' => '0.00',
                'trend' => 'neutral',
                'last_updated' => date('Y-m-d H:i:s'),
                'minutes_since_update' => 0
            ]
        ];
    }
    
    // Возвращаем успешный ответ
    echo json_encode([
        'success' => true,
        'data' => $formattedRates,
        'timestamp' => date('Y-m-d H:i:s'),
        'auto_updated' => $needsUpdate
    ], JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    // Ошибка базы данных
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Ошибка базы данных',
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    // Общая ошибка
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
        'timestamp' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
}
?>
